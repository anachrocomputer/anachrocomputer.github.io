#ifdef RCS_ID
static char RCSid[] = "$Header: hardterm.c,v 1.7 86/11/12 11:37:30 arnold Exp $";
#endif

#include "terms.h"
#include "keys.h"
#include "ascii.h"

#define NORMAL       0
#define INVERSE      1
#define UNDERLINE    2
#define BOLD         4

struct Screen {
   unsigned char ch;
   unsigned char hue;
};

string Smachine = "HardTerm";

static int Colours[20] = {
   NORMAL,
   NORMAL,        /* Text                       */
   NORMAL,        /* Bar                        */
   NORMAL,        /* Command line               */
   NORMAL,        /* Line one                   */
   NORMAL,        /* Line $                     */
   NORMAL,        /* Status line                */
   BOLD,          /* Messages on status line    */
   NORMAL,        /* Line numbers               */
   NORMAL,        /* Mark column                */
   NORMAL,        /* Current line               */
   NORMAL,        /* Help messages              */
   NORMAL,        /* Dashes in 'split-screen'   */
   NORMAL,        /* Prompts                    */
   BOLD,          /* Unprintable characters     */
   NORMAL,        /* MS-DOS shell               */
   INVERSE,       /* Source-code comments       */
   BOLD,          /* reserved words             */
   NORMAL,        /* Source-code strings        */
   UNDERLINE      /* Source-code pre-proc cmds  */
};


static int Term_type = NOTERM;   /* Terminal type                  */
static int Tspeed;               /* Terminal speed in chars/second */
static int Currow;               /* Vertical cursor coordinate     */
static int Curcol;               /* Horizontal cursor coordinate   */
static int Curhue = NORMAL;
static struct Screen Screen_image[MAXROWS][MAXCOLS];
static struct Screen Blanks[MAXCOLS];


#if NO_PROTOTYPES
static int decode_mnemonic ();
static int strbsr ();
static void senddelay ();
static void sendch ();
static void sethue ();
static void clear_to_eol ();
static void sbeecoord ();
static void cgcoord ();
static void b200coord ();
static void uhcm ();
static void uabspos ();
static void outdec ();
#else
static int decode_mnemonic (const char *str);
static int strbsr (const char *stab, int tsize, int esize, const char *str);
static void senddelay (int n);
static void sendch (int chr);
static void sethue (int hue);
static void clear_to_eol (int row, int col, int zone);
static void sbeecoord (int coord);
static void cgcoord (int i);
static void b200coord (int coord);
static void uhcm (int col);
static void uabspos (int ch, int row, int col);
static void outdec (int n);
#endif


/* addspos --- position cursor to (row, col) on ADDS Consul 980 */

static void addspos (row, col)
int row, col;
{
   int ntabs, where;

   if (Currow != row || col < Curcol - 7) {
      t1ou (VT);
      t1ou ('@' + row);
      Currow = row;
      Curcol = 0;
   }

   if (col > Curcol + 2) {
      ntabs = (col + 2) / 5;  /* from beginning */
      where = ntabs * 5;
      ntabs -= Curcol / 5;    /* from Curcol */
      if (ntabs + abs (where - col) <= 4) {
         for (; ntabs > 0; ntabs--)
            t1ou (TAB);
         Curcol = where;
      }
   }

   if (col > Curcol + 4) {
      where = col - Curcol;
      t1ou (ESC);
      t1ou (ENQ);
      t1ou ('0' + (where / 10));
      t1ou ('0' + (where % 10));
      Curcol = col;
   }

   uhcm (col);
}


/* admpos --- position cursor to (row, col) on ADM-3A and ADM-31 terminals */

static void admpos (row, col)
int row, col;
{
   int dist;

   dist = col - Curcol;
   if (dist < 0)
      dist = -dist;

   if (row == Currow && dist < 4) { /* 4 chars for abs. position */
      uhcm (col);
   }
   else {
      uabspos ('=', row, col);
      Currow = row;
      Curcol = col;
   }
}


/* ansipos --- position cursor on ANSI X something-or-other terminals */

static void ansipos (row, col)
register int row, col;
{
#if 0
   register int dist;

   char absseq[20], relseq[50];
   int absp = 0;
   register int relp = 0;
   register int trow, tcol;

   /*** Build relative positioning string--handle row first ***/
   trow = Currow;
   tcol = Curcol;
   if (row >= trow && row <= trow + 3)
      for (; trow < row; trow++)
         relseq[relp++] = LF;
   else if (row < trow && row >= trow - 1)
      for (; trow > row; trow--) {
         relseq[relp++] = ESC;
         relseq[relp++] = 'M';
      }
   else if (row >= trow) {
      relseq[relp++] = ESC;
      relseq[relp++] = '[';
      dist = row - trow;
      if (dist >= 10)
         relseq[relp++] = '0' + dist / 10;
      relseq[relp++] = '0' + dist % 10;
      relseq[relp++] = 'B';
      trow = row;
   }
   else {   /* row < trow */
      relseq[relp++] = ESC;
      relseq[relp++] = '[';
      dist = trow - row;
      if (dist >= 10)
         relseq[relp++] = '0' + dist / 10;
      relseq[relp++] = '0' + dist % 10;
      relseq[relp++] = 'A';
      trow = row;
   }

   /*** Now do the column part of relative positioning ***/
   if (col >= tcol - 2 && col <= tcol + 2)
      ;       /* skip coarse positioning -- just do the fine stuff */
   else {
      if (col <= 4) {
         relseq[relp++] = CR;
         tcol = 0;
      }
      dist = col - tcol;
      if (col < 72 && dist > 2
          && dist < 8 && (col + 1) % 8 <= 2) {
         relseq[relp++] = TAB;
         tcol = ((tcol + 8) / 8) * 8;
      }
   }
   dist = col - tcol;

   if (dist < 0)
      dist = -dist;

   if (dist == 0)
      ;
   else if (dist < 4) {    /* 4 chars for abs. position */
      while (tcol < col) {
         relseq[relp++] = Screen_image[trow][tcol].ch;
         tcol++;
      }

      while (tcol > col) {
         relseq[relp++] = BS;
         tcol--;
      }
   }
   else if (col >= tcol) {
      relseq[relp++] = ESC;
      relseq[relp++] = '[';
      if (dist >= 10)
         relseq[relp++] = '0' + dist / 10;
      relseq[relp++] = '0' + dist % 10;
      relseq[relp++] = 'C';
      tcol = col;
   }
   else {   /* if (col < tcol) */
      relseq[relp++] = ESC;
      relseq[relp++] = '[';
      if (dist >= 10)
         relseq[relp++] = '0' + dist / 10;
      relseq[relp++] = '0' + dist % 10;
      relseq[relp++] = 'D';
      tcol = col;
   }

   /*** If relative positioning will do it, forget absolute ***/
   if (relp <= 5)
      twrite (relseq, relp);
   else {
      absseq[absp++] = ESC;
      absseq[absp++] = '[';
      if (row >= 9)
         absseq[absp++] = '0' + (row + 1) / 10;
      absseq[absp++] = '0' + (row + 1) % 10;
      absseq[absp++] = ';';
      if (col >= 9)
         absseq[absp++] = '0' + (col + 1) / 10;
      absseq[absp++] = '0' + (col + 1) % 10;
      absseq[absp++] = 'H';
      if (absp >= relp)
         twrite (relseq, relp);
      else
         twrite (absseq, absp);
   }
#endif

   Curcol = col;
   Currow = row;
}


/* vt100pos --- position cursor on DEC VT100 series */

static void vt100pos (row, col)
int row, col;
{
   t1ou (ESC);
   t1ou ('[');
   outdec (row + 1);
   t1ou (';');
   outdec (col + 1);
   t1ou ('H');

   Curcol = col;
   Currow = row;
}


/* ibmpcpos --- position cursor IBM PC via ANSI.SYS driver */

static void ibmpcpos (row, col)
register int row, col;
{
   /* Needn't worry about speed... */
   t1ou (ESC);
   t1ou ('[');
   outdec (row + 1);
   t1ou (';');
   outdec (col + 1);
   t1ou ('f');

   Curcol = col;
   Currow = row;
}


/* perqpos --- position cursor on PERQ running PNX */

static void perqpos (row, col)
int row, col;
{
   if (Currow != row) {
      t1ou (ESC);
      t1ou ('Y');
      t1ou (row + 32);
      Currow = row;
   }
   
   if (Curcol != col) {
      t1ou (ESC);
      t1ou ('X');
      t1ou (col + 32);
      Curcol = col;
   }
}


/* anppos --- position cursor on Allen & Paul model 1 */

static void anppos (row, col)
int row, col;
{
   if (row == Currow) {    /* if close, just sneak right or left */
      if (col == Curcol + 1)
         t1ou (TAB);
      else if (col == Curcol + 2) {
         t1ou (TAB);
         t1ou (TAB);
      }
      else if (col == Curcol - 1)
         t1ou (BS);
      else if (col == Curcol - 2) {
         t1ou (BS);
         t1ou (BS);
      }
      else {
         t1ou (ESC);
         t1ou ('C');
         t1ou (col + ' ');
      }
   }
   else if (col == Curcol) {  /* if close, sneak up or down */
      if (row == Currow + 1)
         t1ou (LF);
      else if (row == Currow + 2) {
         t1ou (LF);
         t1ou (LF);
      }
      else if (row == Currow - 1)
         t1ou (VT);
      else if (row == Currow - 2) {
         t1ou (VT);
         t1ou (VT);
      }
      else
      /* Because of bug in anp software, abs row pos is not working.
       * We use absolute pos instead */
         uabspos ('P', row, col);
   }
   else    /* resort to absolute positioning */
      uabspos ('P', row, col);

   Currow = row;
   Curcol = col;
}


/* beepos --- position cursor on Beehive terminal */

static void beepos (row, col)
int row, col;
{
   if (row == Currow + 1 && col == 0 && Term_type != SBEE) {
      t1ou (CR);
      t1ou (LF);
      Curcol = 0;
      Currow++;
   }
   else if (row == 0 && col == 0) {   /* home cursor */
      t1ou (ESC);
      t1ou ('H');
      Currow = Curcol = 0;
   }
   else if (row == Currow && col > Curcol && col <= Curcol + 4)
      while (Curcol != col) {
         t1ou (Screen_image[Currow][Curcol].ch);
         Curcol++;
      }
   else if (row == Currow && col < Curcol && col >= Curcol - 4)
      while (Curcol != col) {
         t1ou (BS);
         Curcol--;
      }
   else {     /* resort to absolute addressing */
      t1ou (ESC);
      t1ou ('F');
      if (Term_type == BEE200 || Term_type == SOL) {
         b200coord (row);
         b200coord (col);
      }
      else if (Term_type == BEE150) {
         t1ou (row + ' ');
         t1ou (col + ' ');
      }
      else {     /* is superbee */
         sbeecoord (col);
         sbeecoord (row);
      }

      Currow = row;
      Curcol = col;
   }
}


/* cgpos --- position cursor on Chromatics CG */

static void cgpos (row, col)
int row, col;
{
   char i, j;

   if (row == Currow + 1 && col == 0) {
      t1ou (CR);
      t1ou (LF);
      Curcol = 0;
      Currow++;
   }
   else if (row == 0 && col == 0) {   /* home cursor */
      t1ou (FS);
      Currow = Curcol = 0;
   }
   else if (row == Currow && col > Curcol && col <= Curcol + 7)
      while (Curcol != col) {
         t1ou (GS);
         Curcol++;
      }
   else if (row == Currow && col < Curcol && col >= Curcol - 7)
      while (Curcol != col) {
         t1ou (BS);
         Curcol--;
      }
   else {
      /* resort to absolute addressing */
      t1ou (SOH);
      t1ou ('U');
      i = 511 - (10 * row);
      j = 6 * col;
      cgcoord (j);
      cgcoord (i);
      Currow = row;
      Curcol = col;
   }
}


/* gt40pos --- position cursor on DEC GT40 with Waugh software */

static void gt40pos (row, col)
int row, col;
{
   if (row != Currow && col != Curcol) {   /* absolute positioning */
      t1ou (ESC);
      t1ou (row + ' ');
      t1ou (col + ' ');
      Currow = row;
      Curcol = col;
   }
   else if (row != Currow)    /* col must = Curcol */
   {                /* vertical positioning */
      t1ou (ACK);
      t1ou (row + ' ');
      Currow = row;
   }
   else if (abs (col - Curcol) < 2)
      uhcm (col);
   else {
      t1ou (NAK);
      t1ou (col + ' ');
      Curcol = col;
   }
}


/* h19pos --- position cursor on Heath H19 (DEC VT52 compatible, supposedly) */

static void h19pos (row, col)
int row, col;
{
   int dist;
   dist = col - Curcol;
   if (dist < 0)
      dist = -dist;
   if (row == Currow && dist < 4) { /* 4 chars for abs. position */
      uhcm (col);
   }
   else {
      uabspos ('Y', row, col);
      Currow = row;
      Curcol = col;
   }
}


/* hp21pos --- position cursor on HP 2621 terminal */

static void hp21pos (row, col)
int row, col;
{
   int units, tens;

   if (row == Currow && col == 0) {
      t1ou (CR);
      t1ou (LF);
      Curcol = 0;
      Currow++;
   }
   else if (row == 0 && col == 0) {   /* home cursor */
      t1ou (ESC);
      t1ou ('H');
      Currow = Curcol = 0;
   }
   else if (row == Currow && col > Curcol && col <= Curcol + 4)
      while (Curcol != col) {
         t1ou (Screen_image[Currow][Curcol].ch);
         Curcol++;
      }
   else if (row == Currow && col < Curcol && col >= Curcol - 4)
      while (Curcol != col) {
         t1ou (BS);
         Curcol--;
      }
   else if (2 * abs (Currow - row) + abs (Curcol - col) <= 7) {
      while (Currow < row) {
         t1ou (ESC);
         t1ou ('B');
         Currow++;
      }
      while (Currow > row) {
         t1ou (ESC);
         t1ou ('A');
         Currow--;
      }
      uhcm (col);
   }
   else {
      /* resort to absolute addressing */
      char c;

      t1ou (ESC);
      t1ou ('&');
      t1ou ('a');
      units = row % 10;
      tens = row / 10;
      if (tens != 0)
         t1ou (tens + '0');

      t1ou (units + '0');
      t1ou ('y');
      units = col % 10;
      tens = col / 10;
      if (tens != 0)
         t1ou (tens + '0');

      t1ou (units + '0');
      t1ou ('C');
      Currow = row;
      Curcol = col;
   }
}


/* hazpos --- position cursor on Hazeltine 1510 */

static void hazpos (row, col)
int row, col;
{
   int dist;

   dist = col - Curcol;
   if (dist < 0)
      dist = -dist;

   if (row == Currow && dist < 4) { /* 4 chars for abs. position */
      uhcm (col);
   }
   else {
      t1ou (ESC);
      t1ou (DC1);
      t1ou (col);
      t1ou (row);
      Currow = row;
      Curcol = col;
   }
}


/* ibmpos --- position cursor on IBM 3101 terminal */

static void ibmpos (row, col)
int row, col;
{
   int dist;

   dist = col - Curcol;
   if (dist < 0)
      dist = -dist;

   if (row == Currow && dist < 4) {   /* 4 chars for abs pos */
      uhcm (col);
   }
   else {
      uabspos ('Y', row, col);
      Currow = row;
      Curcol = col;
   }
}


/* iscpos --- position cursor on ISC 8001 color terminal */

static void iscpos (row, col)
int row, col;
{
   if (row == 0 && col == 0)
      t1ou (BS);
   else {
      t1ou (ETX);
      t1ou (row);
      t1ou (col);
   }

   Currow = row;
   Curcol = col;
}


/* netpos --- position cursor on Netron terminal */

static void netpos (row, col)
int row, col;
{
   uabspos ('=', row, col);
   Currow = row;
   Curcol = col;
}


/* pepos --- position cursor on Perkin-Elmer 550 & 1100 terminals */

static void pepos (row, col)
int row, col;
{
   /* get on correct row first */
   if (Currow == row)
      ;          /* already on correct row; nothing to do */
   else if (row == Currow - 1) {
      t1ou (ESC);    /* cursor up */
      t1ou ('A');
      Currow--;
   }
   else if (row == Currow + 1) {
      t1ou (ESC);    /* cursor down */
      t1ou ('B');
      Currow++;
   }
   else {
      /* vertical absolute positioning */
      t1ou (ESC);
      t1ou ('X');
      t1ou (row + ' ');
      Currow = row;
   }

   /* now perform horizontal motion */
   if (abs (col - Curcol) > 3) {   /* do absolute horizontal position */
      t1ou (ESC);
      t1ou ('Y');
      t1ou (col + ' ');
      Curcol = col;
   }
   else
      uhcm (col);
}


/* trspos --- position cursor on TRS80 Model 1 */

static void trspos (row, col)
int row, col;
{
   while (Currow != row) {
      if (Currow > row) {
         t1ou (ESC);
         Currow--;
      }
      else {
         t1ou (SUB);
         Currow++;
      }
   }

   if (Curcol != col) {
      if (col > Curcol)
         while (col > Curcol) {
            t1ou (EM);
            Curcol++;
         }
      else if (col < Curcol / 2) {
         t1ou (GS);
         Curcol = 0;
         while (Curcol < col) {
            t1ou (EM);
            Curcol++;
         }
      }
      else
         while (col < Curcol) {
            t1ou (CAN);
            Curcol--;
         }
   }
}


/* tvtpos --- position cursor on Allen's TV Typewriter II */

static void tvtpos (row, col)
int row, col;
{
   register int horirel, horiabs, vertrel, vertabs;

   horirel = col - Curcol;
   if (horirel < 0)
      horirel = -horirel;

   horiabs = col;

   if (row <= Currow)
      vertrel = Currow - row;
   else
      vertrel = Nrows - (row - Currow);

   if (row == 0)
      vertabs = 0;
   else
      vertabs = Nrows - row;

   if (1 + horiabs + vertabs <= horirel + vertrel) {
      t1ou (FF);
      Currow = Curcol = 0;
   }

   while (Currow != row) {
      t1ou (VT);
      Currow--;
      if (Currow < 0)
         Currow = Nrows - 1;
   }

   if (Curcol > col)
      for (; Curcol != col; Curcol--)
         t1ou (BS);
   else
      for (; Curcol != col; Curcol++)
         t1ou (TAB);
}


/* regentpos --- position cursor on ADDS Regent 100 */

static void regentpos (row, col)
int row, col;
{
   int dist;

   dist = col - Curcol;
   if (dist < 0)
      dist = -dist;

   if (dist > 4 || Currow != row) {
      uabspos ('Y', row, col);
      Currow = row;
      Curcol = col;
   }
   else {
      while (row < Currow) {
         t1ou (SUB);  /* SUB, cursor up */
         Currow--;
      }
      while (row > Currow) {
         t1ou (LF);
         Currow++;
         Curcol = 1;
      }
      if (col > Curcol)
         while (col != Curcol) {
            t1ou (Screen_image[Currow][Curcol].ch);
            Curcol++;
         }
      else if ((Curcol - col) * 2 >= Ncols)
         while (col != Curcol) {
            t1ou (ACK);  /* ACK, cursor right */
            if (Curcol == Ncols)
               Curcol = 1;
            else
               Curcol++;
         }
      else
         while (col != Curcol) {
            t1ou (BS);
            Curcol--;
         }
   }
}


/* vipos --- position cursor on Visual 200 & 50 */

static void vipos (row, col)
register int row, col;
{
   register int dist;

   if (row == Currow + 1 && col < 3) {
      t1ou (CR);
      t1ou (LF);
      Currow++;
      Curcol = 0;
   }

   dist = col - Curcol;

   if (Term_type == VI200 && row == Currow && col < 72 && dist > 2
       && dist < 8 && (col + 1) % 8 < 2) {
      t1ou (TAB);
      Curcol = ((Curcol + 7) / 8) * 8;
      dist = col - Curcol;
   }

   if (dist < 0)
      dist = -dist;

   if (row == Currow && dist < 4) { /* 4 chars for abs. position */
      uhcm (col);
   }
   else {
      uabspos ('Y', row, col);
      Currow = row;
      Curcol = col;
   }
}


/* vcpos --- position cursor Volker-Craig 4404 (ADM3A mode) */

static void vcpos (row, col)
int row, col;
{
   int dist;

   dist = col - Curcol;
   if (dist < 0)
      dist = -dist;
   if (row == Currow && dist < 4) { /* 4 chars for abs. position */
      uhcm (col);
   }
   else {
      uabspos ('=', row, col);
      Currow = row;
      Curcol = col;
   }
}


/* espritpos --- position cursor on Hazeltine Esprit */

static void espritpos (row, col)
int row, col;
{
   int dist;

   dist = col - Curcol;
   if (dist < 0)
      dist = -dist;
   if (row == Currow && dist < 4) {  /* 4 chars for abs. position */
      uhcm (col);
   }
   else {
      t1ou (ESC);
      t1ou (DC1);
      t1ou (col >= 32 ? col : col + '`');
      t1ou (row >= 32 ? row : row + '`');
      Currow = row;
      Curcol = col;
   }
}


/* senddelay --- send NULs to delay n milliseconds */

static void senddelay (n)
int n;
{
   register int q;

   q = (long) n * Tspeed / 1000l;

   while (q > 0) {
      t1ou (NUL);
      q--;
   }
}


/* decode_mnemonic --- decode a terminal type mnemonic */

static int decode_mnemonic (str)
const char *str;
{
   int i;
   static struct {
      char *s;
      int t;
   } stab[] = {
      "950",      TVI950,
      "adm31",    ADM31,
      "adm3a",    ADM3A,
      "anp",      ANP,
      "b150",     BEE150,
      "b200",     BEE200,
      "cg",       CG,
      "consul",   ADDS980,
      "esprit",   ESPRIT,
      "fox",      FOX,
      "gt40",     GT40,
      "h19",      H19,
      "haz",      HAZ1510,
      "hp21",     HP21,
      "hz1510",   HAZ1510,
      "ibm",      IBM,
      "ibmpc",    PCANSI,
      "isc",      ISC8001,
      "netron",   NETRON,
      "perq",     PERQ_PNX,
      "regent",   ADDS100,
      "regent40", ADDS100,   /* kludge */
      "sbee",     SBEE,
      "sol",      SOL,
      "trs80",    TRS80,
      "ts1",      TS1,
      "tvt",      TVT,
      "vc4404",   VC4404,
      "vi200",    VI200,
      "vi300",    VI300,
      "vi50",     VI50,
      "vt100",    VT100,
      "vt220",    VT200,
      "vt240",    VT200,
      "vt320",    VT300,
      "xterm",    VT100,
   };

   i = strbsr ((char *)stab, sizeof (stab), sizeof (stab[0]), str);
   if (i == EOF)
      return (ERR);
   else
      return (stab[i].t);
}


/* sendch --- send a printable character, predict cursor position */

static void sendch (chr)
register int chr;
{
   if (Currow == Nrows - 1 && Curcol == Ncols - 1)
      return;    /* anything in corner causes scroll... */

   t1ou (chr);

   if (Curcol == Ncols - 1) {
      if (Term_type != TVT && Term_type != NETRON
          && Term_type != ESPRIT && Term_type != VI300
          && Term_type != VT100 && Term_type != VT200
          && Term_type != VT300) {
         Curcol = 0;
         Currow++;
      }
   }
   else       /* cursor not at extreme right */
      Curcol++;
}


/* clrscreen --- clear entire screen */

void clrscreen ()
{
   Curcol = Currow = 0;
   /* clearing screen homes cursor to upper left corner */
   /* on all terminals */

   switch (Term_type) {
   case ADDS980:
   case ADDS100:
   case GT40:
   case CG:
   case ISC8001:
   case ANP:
   case NETRON:
      t1ou (FF);
      break;
   case FOX:
   case PERQ_PNX:
      t1ou (ESC);    /* Clear display and all tabs */
      t1ou ('K');
      break;
   case TVT:
      t1ou (FF);          /* Home, erase to end of screen */
      t1ou (SI);
      break;
   case BEE150:
   case BEE200:
   case SBEE:
   case SOL:
   case H19:
      t1ou (ESC);
      t1ou ('E');
      break;
   case HAZ1510:
   case ESPRIT:
      t1ou (ESC);
      t1ou (FS);
      break;
   case ADM3A:
   case VC4404:
   case TVI950:
      t1ou (SUB);
      break;
   case TS1:
      t1ou (ESC);
      t1ou ('*');
      break;
   case ADM31:
      t1ou (ESC);
      t1ou ('+');
      break;
   case IBM:
      t1ou (ESC);
      t1ou ('L');
      break;
   case HP21:
      t1ou (ESC);    /* home cursor, erase to end of screen */
      t1ou ('H');
      t1ou (ESC);
      t1ou ('J');
      break;
   case TRS80:
      t1ou (FS);
      t1ou (US);
      break;
   case VI200:
      t1ou (ESC);
      t1ou ('v');
      break;
   case VI300:
      t1ou (ESC);
      t1ou ('[');
      t1ou ('H');
      t1ou (ESC);
      t1ou ('[');
      t1ou ('J');
      break;
   case PCANSI:
   case VT100:
   case VT200:
   case VT300:
      t1ou (ESC);
      t1ou ('[');
      t1ou ('H');
      t1ou (ESC);
      t1ou ('[');
      t1ou ('2');
      t1ou ('J');
      break;
   case VI50:
      t1ou (ESC);
      t1ou ('v');
      senddelay (30);
      break;
   }

   if (Term_type != PCANSI)
      senddelay (20);
}


/* position_cursor --- position terminal's cursor to (row, col) */

void position_cursor (row, col)
int row, col;
{
   if (row < Nrows && row >= 0        /* within vertical range? */
       && col < Ncols && col >= 0     /* within horizontal range? */
       && (row != Currow || col != Curcol)) { /* not already there? */
      switch (Term_type) {
      case ADDS980:
         addspos (row, col);
         break;
      case ADDS100:
         regentpos (row, col);
         break;
      case HP21:
         hp21pos (row, col);
         break;
      case FOX:
         pepos (row, col);
         break;
      case PERQ_PNX:
         perqpos (row, col);
         break;
      case TVT:
         tvtpos (row, col);
         break;
      case GT40:
         gt40pos (row, col);
         break;
      case BEE150:
      case BEE200:
      case SBEE:
      case SOL:
         beepos (row, col);
         break;
      case VC4404:
         vcpos (row, col);
         break;
      case HAZ1510:
         hazpos (row, col);
         break;
      case ESPRIT:
         espritpos (row, col);
         break;
      case CG:
         cgpos (row, col);
         break;
      case ISC8001:
         iscpos (row, col);
         break;
      case ADM3A:
      case ADM31:
      case TS1:
      case TVI950:
         admpos (row, col);
         break;
      case IBM:
         ibmpos (row, col);
         break;
      case PCANSI:
         ibmpcpos (row, col);
         break;
      case ANP:
         anppos (row, col);
         break;
      case NETRON:
         netpos (row, col);
         break;
      case H19:
         h19pos (row, col);
         break;
      case TRS80:
         trspos (row, col);
         break;
      case VI200:
      case VI50:
         vipos (row, col);
         break;
      case VI300:
         ansipos (row, col);
         break;
      case VT100:
      case VT200:
      case VT300:
         vt100pos (row, col);
         break;
      }
   }
}


/* mdvd_init --- initialise this module */

void mdvd_init ()
{
   register int row, col;

   /* Initialise array of blanks */
   for (col = 0; col < MAXCOLS; col++) {
      Blanks[col].ch = ' ';
      Blanks[col].hue = Colours[TEXT_ZONE];
   }
   
   /* Clear virtual screen array */
   for (row = 0; row < MAXROWS; row++)       /* now clear virtual screen */
      for (col = 0; col < MAXCOLS; col++) {
         Screen_image[row][col].ch = ' ';
         Screen_image[row][col].hue = NORMAL;
      }
}


/* inslines --- insert 'n' lines on the screen at 'row' */

void inslines (row, n)
int row, n;
{
   register int i;
   int delay;

   position_cursor (row, 0);

   if (Term_type == VI300 || Term_type == VT100 ||
       Term_type == VT200 || Term_type == VT300) {
      t1ou (ESC);
      t1ou ('[');
      if (n > 1)
         outdec (n);
      t1ou ('L');
      delay = 0;
   }
   else
      for (i = 0; i < n; i++) {
         switch (Term_type) {
         case VI200:
            t1ou (ESC);
            t1ou ('L');
            delay = 0;
            break;
         case VI50:
         case H19:
            t1ou (ESC);
            t1ou ('L');
            delay = 32;
            break;
         case ESPRIT:
            t1ou (ESC);
            t1ou (SUB);
            delay = 32;
            break;
         case TS1:
         case TVI950:
            t1ou (ESC);
            t1ou ('E');
            delay = 0;
            break;
         case ADDS100:
            t1ou (ESC);
            t1ou ('M');
            delay = 96;
            break;
         default:
            error (YES, "in inslines: shouldn't happen");
         }

         if (delay != 0)
            senddelay (delay);
      }

   for (i = Nrows - 1; i - n >= Currow; i--)
      memcpy (Screen_image[i], Screen_image[i - n], Ncols * sizeof (struct Screen));

   for (; i >= Currow; i--)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (struct Screen));
}


/* dellines --- delete 'n' lines beginning at 'row' */

void dellines (row, n)
int row, n;
{
   register int i;
   int delay;

   position_cursor (row, 0);

   if (Term_type == VI300 || Term_type == VT100 ||
       Term_type == VT200 || Term_type == VT300) {
      t1ou (ESC);
      t1ou ('[');
      if (n > 1)
         outdec (n);
      t1ou ('M');
      delay = 0;
   }
   else
      for (i = 0; i < n; i++) {
         switch (Term_type) {
         case VI200:
            t1ou (ESC);
            t1ou ('M');
            delay = 0;
            break;
         case VI50:
         case H19:
            t1ou (ESC);
            t1ou ('M');
            delay = 32;
            break;
         case TS1:
         case TVI950:
            t1ou (ESC);
            t1ou ('R');
            delay = 0;
            break;
         case ESPRIT:
            t1ou (ESC);
            t1ou (DC3);
            delay = 32;
            break;
         case ADDS100:
            t1ou (ESC);
            t1ou ('l');
            delay = 96;
            break;
         default:
            error (YES, "in dellines: shouldn't happen");
         }

         if (delay != 0)
            senddelay (delay);
      }

   for (i = Currow; i + n < Nrows; i++)
      memcpy (Screen_image[i], Screen_image[i + n], Ncols * sizeof (struct Screen));

   for (; i < Nrows; i++)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (struct Screen));
}


/* clear_to_eol --- clear screen to end-of-line */

static void clear_to_eol (row, col, zone)
int row, col;
int zone;
{
   register int c;
   register bool flag;
   register bool hardware = NO;

   switch (Term_type) {
   case BEE200:
   case BEE150:
   case FOX:
   case SBEE:
   case ADDS100:
   case HP21:
   case IBM:
   case PCANSI:
   case ANP:
   case NETRON:
   case H19:
   case TS1:
   case TRS80:
   case ADM31:
   case VI200:
   case VI300:
   case VI50:
   case VT100:
   case VT200:
   case VT300:
   case VC4404:
   case ESPRIT:
   case TVI950:
      hardware = YES;
      break;
   default:
      hardware = (Term_type == ADDS980 && row < Nrows - 1)
            || (Term_type == TVT && row > 0);
   }

   flag = NO;

   for (c = col; c < Ncols; c++)
      if (Screen_image[row][c].ch != ' ' || Screen_image[row][c].hue != Colours[zone]) {
         Screen_image[row][c].ch = ' ';
         Screen_image[row][c].hue = Colours[zone];
         if (hardware)
            flag = YES;
         else {
            position_cursor (row, c);
            sethue (Colours[zone]);
            sendch (' ');
         }
      }

   if (flag) {
      position_cursor (row, col);
      sethue (Colours[zone]);
      switch (Term_type) {
      case BEE200:
      case BEE150:
      case SBEE:
      case ADDS100:
      case HP21:
      case H19:
      case VC4404:
      case TS1:
      case TVI950:
      case VI50:
         t1ou (ESC);
         t1ou ('K');
         break;
      case FOX:
      case IBM:
         t1ou (ESC);
         t1ou ('I');
         break;
      case ADDS980:
         t1ou (LF);
         Currow++;
         Curcol = 0;
         break;
      case ANP:
         t1ou (ESC);
         t1ou ('L');
         break;
      case NETRON:
         t1ou (ENQ);
         break;
      case TRS80:
         t1ou (RS);
         break;
      case ADM31:
         t1ou (ESC);
         t1ou ('T');
         break;
      case VI200:
         t1ou (ESC);
         t1ou ('x');
         break;
      case VI300:
      case VT100:
      case VT200:
      case VT300:
      case PCANSI:
         t1ou (ESC);
         t1ou ('[');
         t1ou ('K');
         break;
      case ESPRIT:
         t1ou (ESC);
         t1ou (SI);
         break;
      case TVT:
         t1ou (VT);
         t1ou (LF);
         break;
      } /* end switch */
   } /* end if (flag == YES) */
}


/* set_term --- initialise terminal parameters and actual capabilities */

int set_term (type, hwinsdel, r, c)
const uchar *type;
bool *hwinsdel;
int *r, *c;
{
   int rows, cols;
   
   if (type == NULL)
      error (NO, "terminal type not available");

   if (type[0] == EOS)
      error (NO, "in set_term: can't happen.");

#if UNIX | LINUX
   Tspeed = getspeed (1);   /* Speed of 'stdout' in cps */
#else
   Tspeed = 960;
#endif
   
   if ((Term_type = decode_mnemonic (type)) == ERR)
      error (NO, "could not find terminal in internal database");

   rows = cols = -1;
   
   switch (Term_type) {
   case ADDS980:
   case FOX:
   case PERQ_PNX:
   case HAZ1510:
   case ADDS100:
   case BEE150:
   case ADM3A:
   case IBM:
   case HP21:
   case H19:
   case ADM31:
   case VI200:
   case VC4404:
   case ESPRIT:
   case TS1:
   case TVI950:
   case VI50:
   case VI300:
   case VT100:
   case VT200:
   case VT300:
      rows = 24;
      cols = 80;
      break;
   case ANP:
      rows = 24;
      cols = 96;
      break;
   case SOL:
   case NETRON:
   case TRS80:
      rows = 16;
      cols = 64;
      break;
   case TVT:
      rows = 16;
      cols = 63;
      break;
   case GT40:
      rows = 32;
      cols = 73;
      break;
   case CG:
      rows = 51;
      cols = 85;
      break;
   case ISC8001:
      rows = 48;
      cols = 80;
      break;
   case BEE200:
   case SBEE:
   case PCANSI:
      rows = 25;
      cols = 80;
      break;
   }

   switch (Term_type) {
   case VT100:
   case VT200:
   case VT300:
   case VI300:
   case VI200:
   case VI50:
   case ESPRIT:
   case H19:
   case TS1:
   case TVI950:
   case ADDS100:
      *hwinsdel = YES;
      break;
   default:
      *hwinsdel = NO;
      break;
   }

   *r = rows;
   *c = cols;
   
   return (OK);
}


/* strbsr --- binary search stab for an entry equal to str */

static int strbsr (stab, tsize, esize, str)
const char *stab;
int tsize, esize;
const char *str;
{
   /* stab should have been declared like this:

   static struct {
      char *s;
      ...
   } stab[] = {
      "string1",      ...
      "string2",      ...
      ...   ...
   };

   The call to strbsr should look like this:

   i = strbsr (stab, sizeof (stab), sizeof (stab[0]), str);
   */

   register int i, j, k, x;

   i = 0;
   j = tsize / esize - 1;
   do {
      k = (i + j) / 2;
      if ((x = strcmp (str, *(char **)(stab + esize * k))) < 0)
         j = k - 1;    /* GREATER */
      else if (x == 0)
         return (k);   /* EQUAL */
      else
         i = k + 1;    /* LESS */
   } while (i <= j);

   return (EOF);
}


/* load --- load a character into the screen image */

void load (ch, row, col, zone)
register int ch;
register int row, col;
int zone;
{
   struct Screen chz;
   
#if MSDOS | MSWIN32
   if (ch < ' ' || ch == DEL) {
#else
   if (ch < ' ' || ch > '~') {
#endif
      chz.ch = Unprintable;
      chz.hue = Colours[UPRT_ZONE];
   }
   else {
      chz.ch = ch;
      chz.hue = Colours[zone];
   }

/* if (Screen_image[row][col] != chz) { */
   if (Screen_image[row][col].ch != chz.ch || Screen_image[row][col].hue != chz.hue) {
      position_cursor (row, col);
      sethue (chz.hue);
      sendch (chz.ch);
      Screen_image[row][col] = chz;
   }
}


/* loadstr --- load a string into a field of the screen */

void loadstr (str, row, stcol, endcol, zone)
register const uchar *str;
int row, stcol, endcol;
int zone;
{
   struct Screen chz;
   register int p, c, limit;

   if (row >= 0 && row < Nrows && stcol >= 0) {
      for (p = 0, c = stcol; str[p] != EOS && c < Ncols; p++, c++) {
#if MSDOS | MSWIN32
         if (str[p] < ' ' || str[p] == DEL) {
#else
         if (str[p] < ' ' || str[p] > '~') {
#endif
            chz.ch = Unprintable;
            chz.hue = Colours[UPRT_ZONE];
         }
         else {
            chz.ch = str[p];
            chz.hue = Colours[zone];
         }

         if (Screen_image[row][c].ch != chz.ch || Screen_image[row][c].hue != chz.hue) {
            position_cursor (row, c);
            sethue (chz.hue);
            sendch (chz.ch);
            Screen_image[row][c] = chz;
         }
      }

      if (endcol >= Ncols - 1 && c < Ncols - 1)
         clear_to_eol (row, c, zone);
      else {
         chz.ch = ' ';
         chz.hue = Colours[zone];
         
         limit = (endcol < Ncols - 1) ? endcol : Ncols - 1;

         for (; c <= limit; c++)
            if (Screen_image[row][c].ch != chz.ch || Screen_image[row][c].hue != chz.hue) {
               position_cursor (row, c);
               sethue (chz.hue);
               sendch (chz.ch);
               Screen_image[row][c] = chz;
            }
      }
   }
}


/* cprow --- copy from one row to another for append */

void cprow (from, to)
register int from, to;
{
   register int col;

   for (col = 0; col < Ncols; col++)
      load (Screen_image[from][col].ch, to, col, TEXT_ZONE);
}


/* shape_cursor --- set cursor shape or size */

void shape_cursor (size)
int size;
{
}


/* ringbell --- generate bleeping noises */

void ringbell (type)
int type;
{
   if (!Quiet)
      t1ou (BEL);
}


/* mvinch --- return character at (r,c) */

int mvinch (r, c)
int r, c;
{
   return (Screen_image[r][c].ch);
}


/* setcolr --- set a zone colour in the colour map */

void setcolr (zone, fg, bg)
int zone;
int fg, bg;
{
   Colours[zone] = fg;
}


/* restore_screen --- screen has been garbaged - fix it */

void restore_screen ()
{
   int r, c;
   
   clrscreen ();
   
   for (r = 0; r < Nrows; r++) {
      for (c = 0; c < Ncols; c++)
         if (Screen_image[r][c].ch != ' ' ||
             Screen_image[r][c].hue != NORMAL) {
            position_cursor (r, c);
            sethue (Screen_image[r][c].hue);
            sendch (Screen_image[r][c].ch);
         }
   }
         
   msgstr (SNULL, REMARK_MSG);
}


/* shellcolr --- set the colour of the shell */

void shellcolr()
{
}


/* sethue --- set video attributes on or off */

static void sethue (hue)
int hue;
{
   if (Curhue != hue) {
#if 0
      /* Set inverse video... */
      if (Inverse_ok) {
         if (Curhue & INVERSE)
            tputs (SE, 1, outc);

         if (hue & INVERSE)
            tputs (SO, 1, outc);
      }

      /* Set underlining... */
      if (Uline_ok) {
         if (Curhue & UNDERLINE)
            tputs (UE, 1, outc);
         
         if (hue & UNDERLINE)
            tputs (US, 1, outc);
      }
         
      /* Set bold... */
      if (Bold_ok) {
         if (Curhue & BOLD)
            tputs (ME, 1, outc);
      
         if (hue & BOLD)
            tputs (MD, 1, outc);
      }
#endif
         
      Curhue = hue;
   }
}


/* term_name --- return the name of the terminal */

uchar *term_name ()
{
   return ((uchar *)"HardTerm");
}


/* readkey --- read a single keystroke */

int readkey (israw)
bool israw;
{
   int key;
   
   /* Flush any buffered output before reading */
   tflush ();

   if (israw) {
      key = t1in ();
   }
   else {
      key = t1in ();
      
#ifdef DB
      printf ("t1in returns %d\r\n", key);
#endif
      
      if (key < ' ')
         key = -key;
      else if (key == DEL)
         key = CDELETE;
   }
   
   return (key);
}


/* term_init --- send start-up sequence to terminal */

void term_init ()
{
   switch (Term_type) {
   case VT100:
   case VT200:
   case VT300:
      break;
   }
}


/* term_exit --- send close-down sequence to terminal */

void term_exit ()
{
   switch (Term_type) {
   case VT100:
   case VT200:
   case VT300:
      break;
   }
}


/* sbeecoord --- transmit a coordinate for Superbee terminal */

static void sbeecoord (coord)
int coord;
{
   t1ou ((coord / 10) + ' ');
   t1ou ((coord % 10) + ' ');
}


/* cgcoord --- output a decimal coordinate for Chromatics CG */

static void cgcoord (i)
int i;
{
   int units, tens, hundreds;

   units = i % 10;
   i /= 10;
   tens = i % 10;
   i /= 10;
   hundreds = i % 10;

   t1ou (hundreds + 16 + ' ');
   t1ou (tens + 16 + ' ');
   t1ou (units + 16 + ' ');
}


/* b200coord --- transmit a coordinate for Beehive 200 cursor addressing */

static void b200coord (coord)
int coord;
{
   char acc;
   int tens, units;

   tens = coord / 10;
   units = coord - 10 * tens;
   acc = units + 16 * tens;

   t1ou (acc);
}


/* uhcm --- universal horizontal cursor motion */

static void uhcm (col)
int col;
{
   while (Curcol < col) {
      t1ou (Screen_image[Currow][Curcol].ch);
      Curcol++;
   }

   while (Curcol > col) {
      t1ou (BS);
      Curcol--;
   }
}


/* uabspos --- universal absolute cursor positioning */

static void uabspos (ch, row, col)
int ch;
int row, col;
{
   t1ou (ESC);
   t1ou (ch);
   t1ou (row + ' ');
   t1ou (col + ' ');
}


/* outdec --- output a decimal number for VT100 series */

static void outdec (n)
register int n;
{
   int units, tens, hundreds;

   units = n % 10;
   n /= 10;
   tens = n % 10;
   n /= 10;
   hundreds = n % 10;

   if (hundreds != 0)
      t1ou (hundreds + '0');

   if (hundreds != 0 || tens != 0)
      t1ou (tens + '0');

   t1ou (units + '0');
}
