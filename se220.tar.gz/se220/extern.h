/*
 * $Header: extern.h,v 1.2 86/07/14 16:44:30 arnold Exp $
 */

/*
 * $Log:        extern.h,v $
 * Revision 1.2  86/07/14  16:44:30  arnold
 * Removed stuff that was Georgia Tech specific.
 *
 * Revision 1.1  86/05/06  13:36:05  osadr
 * Initial revision
 *
 *
 */

/*
** extern.h
**
** external data definitions
** for the screen editor
*/

/* Concerning line numbers: */
extern Lnum Line1;               /* first line number on command */
extern Lnum Line2;               /* second line number on command */
extern int Nlines;               /* number of line numbers specified */
extern Lnum Curln;               /* current line; value of dot */
extern Lnum Lastln;              /* last line; value of dollar */
extern Lnum Topln;               /* line number of first line on screen */
extern Lnum First_affected;      /* number of first line affected by cmd */
extern uchar Savknm;             /* saved mark name for < and > */


/* Concerning patterns: */
extern Pattern Pat;             /* Saved pattern as SWT pattern */
extern uchar Savpat[MAXLINE];   /* Saved pattern as ASCII */
extern uchar Tlpat[MAXPAT];     /* Saved character list for y/t command */
extern uchar Tabstr[MAXLINE];   /* String representation of tab stops   */


/* Concerning the 'undo' command: */
#ifdef OLD_SCRATCH
extern LINEDESC *Free;           /* Head of free list                 */
extern LINEDESC *Limbo;          /* Head of limbo list for undo      */
#else
extern int Limbo;                /* Index of first limbo line in Buf */
#endif                           
extern int Limcnt;               /* Number of lines in limbo         */
extern int Lost_lines;           /* Number of garbage lines in scratch file */


/* Concerning file names: */
extern uchar Dirsep;             /* Directory separator character   */
extern uchar Filsep;             /* File suffix separator character */


/* Concerning line descriptors: */
extern LINEDESC Buf[MAXBUF];
extern LINEDESC *Line0;         /* head of list of line descriptors */


/* Concerning miscellaneous variables */
extern bool Buffer_changed;     /* YES if buffer changed since last write */
extern int Errcode;             /* cause of most recent error */
extern int Saverrcode;          /* cause of previous error */
extern bool Peekc;              /* push a SKIP_RIGHT if adding delimiters */


/* Concerning options: */
extern int Ddir;                 /* delete direction                     */
extern bool Compress;            /* Compress/expand tabs on read/write   */
extern bool Tabstops[MAXLINE];   /* Array of tab stops */
extern uchar Unprintable;        /* Char to print for unprintable chars */
extern bool Absnos;              /* Use absolute numbers in margin */
extern int Nchoise;              /* Choice of line number for cont. display */
extern bool Patchoise;           /* Display saved search pattern ?      */
extern int Overlay_col;          /* Initial cursor column for 'v' command */
extern int Warncol;              /* Where to turn on column warning */
extern int Firstcol;             /* Leftmost column to display */
extern int Indent;               /* Indent col; 0=same as previous line */
extern bool Notify;              /* Notify user if he has mail in mail file */
extern bool Globals;             /* Substitutes in a global don't fail */
extern bool No_hardware;         /* Never use hardware insert/delete */
extern bool Subsys;              /* Working in 'Subsystem' mode */
extern bool View;                /* Working in 'Read-only' mode */
extern bool Quiet;               /* To BEEP or not to BEEP      */
extern bool Use_script;          /* Flag for reading from a script                    */
extern FILE *Scriptfp;           /* Stream for script file                            */
extern bool Src_mode;            /* Source-code mode */
extern uchar Ot[];               /* Open tag */
extern uchar Ct[];               /* Close tag */
extern uchar Q1;                 /* Two types of quote */
extern uchar Q2;
extern uchar Oc1[];              /* Open comment 1 */
extern uchar Cc1[];              /* Close comment 1 */
extern uchar Oc2[];              /* Open comment 2 */ 
extern uchar Cc2[];              /* Close comment 2 */
extern uchar Op[];               /* Open pre-processor directive */
extern uchar Cp[];               /* Close pre-processor directive */
extern bool Casematch;           /* Case sensitive matching */
extern bool Show_ok;             /* Display 'changed' message */
extern bool Crypting;           /* doing file encryption? */
extern char Key[KEYSIZE];       /* encryption key */


/* Concerning the screen format: */
extern int Nrows;               /* number of rows on screen */
extern int Ncols;               /* number of columns on screen */
extern bool Terminsdel;         /* TRUE if terminal can do ins/del line */
extern int Toprow;              /* top row of window field on screen */
extern int Botrow;              /* bottom row of window field on screen */
extern int Cmdrow;              /* row number of command line */
extern bool Insert_mode;        /* flag to specify character insertion */
extern bool Invert_case;        /* flag to specify case mapping on input */
extern int Rel_a;               /* char to use for first alpha line number */
extern int Rel_z;               /* char to use for last alpha line number */
extern int Scline[MAXROWS];     /* lines currently on screen (rel to Sctop) */
extern int Sctop;               /* first line currently on screen */
extern int Sclen;               /* number of lines currently on screen */
