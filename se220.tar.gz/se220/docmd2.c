#ifdef RCS_ID
static char RCSid[] = "$Header: docmd2.c,v 2.0 87/10/26 19:00:00 BJ Exp $";
#endif

/*
 * $Log:        docmd2.c,v $
 * Revision 2.10 91/12/16  01:00:00  BJ
 * Changed TERM_ code for 'getcmd ()'
 *
 * Revision 2.09 89/12/19  17:00:00  BJ
 * Added 'GetLength' macro calls
 *
 * Revision 2.0  87/10/26  19:00:00  BJ
 * Removed code in 'dooverlay ()' that allowed '0v' to work
 * Moved many functions to other modules
 *
 * Revision 1.3  86/07/17  17:20:29  arnold
 * Some general code cleaning up.
 *
 * Revision 1.2  86/07/11  15:11:04  osadr
 * Removed Georgia Tech specific code.
 *
 * Revision 1.1  86/05/06  13:36:57  osadr
 * Initial revision
 *
 *
 */

/*
 * docmd2.c
 *
 * routines to actually execute commands
 */

#include "se.h"
#include "extern.h"


/* append --- append lines after "line" */

int append (line, str)
int line;
const uchar *str;
{
   uchar lin[MAXLINE];
   int term;         /* Termination code from 'getcmd ()' */
   int ret;
   int len;
   register int i;
   int row;          /* Row where we call 'getcmd ()' */

   Curln = line;

   if (str[0] == INLINE)      /* Text to be added is in the command line */
      ret = injectln (&str[1], Curln);
   else {
      row = Toprow + (Curln - Topln) + 1; /* 1 below Curln */

      if (Indent > 0 || line <= 0)
         len = max (0, Indent - 1);
      else {                              /* Do auto indent */
         get_txt (line, lin);
         for (len = 0; lin[len] == ' '; len++)
            ;
      }

      lin[0] = EOS;

      for (ret = NOSTATUS; ret == NOSTATUS; ) {
         if (! hwinsdel ()) {       /* Do it the old, slow way */
            if (row > Botrow) {
               row = Toprow + 1;
               cprow (Botrow, Toprow);
               adjust_window (Curln, Curln);
               if (First_affected > Topln)
                  First_affected = Topln;
            }

            clrrow (row);

            if (row < Botrow)
               clrrow (row + 1);
         }
         else {      /* Try to be smart about it */
            if (row > Botrow) {
               row--;
               dellines (Toprow, 1);
               inslines (row, 1);
               Topln++;
            }
            else {
               dellines (Botrow, 1);
               inslines (row, 1);
            }
         }

         prompt (APD_PRMT, row);       /* Display append prompt */

         do
            term = getcmd (row, lin, Firstcol, &len);
         while (!(term == TERM_SAME || term == TERM_FUNNY));

         /* Let the bracket-matcher have a look */
         bracket_match (lin);
         
         /* Look for dot to indicate end of append mode */
         for (i = 0; lin[i] == ' '; i++)
            ;

         if (lin[i] == ENDAPPEND && lin[i + 1] == NEWLINE &&
             lin[i + 2] == EOS) {
            if (hwinsdel()) {
               dellines (row, 1);
               inslines (Botrow, 1);
            }
            ret = OK;
         }
         else if (injectln (lin, Curln) == ERR)
            ret = ERR;
         else                       /* Inject occured OK */ 
            prompt (NUL_PRMT, row);    /* Erase append prompt */

         row++;       
         if (term != TERM_FUNNY) {
            if (Indent > 0)      /* Do indent */
               len = Indent - 1;
            else                 /* Do auto indent */
               for (len = 0; lin[len] == ' '; len++)
                  ;

            lin[0] = EOS;
         }
      }

      if (hwinsdel ()) {   /* Since we take control of the screen, */
         Sctop = Topln;    /* we're sure it's still OK             */

         for (i = 0; i < Sclen; i++)
            Scline[i] = Sctop + i <= Lastln ? i : -1;
      }
   }

   if (Curln == 0 && Lastln > 0)   /* for 0a or 1i followed by "." */
      Curln = 1;

   if (First_affected > line)
      First_affected = line;

   tflush ();
   return (ret);
}


/* copy --- copy line1 through line2 after line3 */

int copy (line3)
int line3;
{
   uchar lin[MAXLINE];
   register int i;
   int ret;
   register LINEDESC *k;
#ifdef OLD_SCRATCH
   register LINEDESC *ptr3, *after3; 
#endif

   ret = ERR;

#ifdef OLD_SCRATCH
   ptr3 = getind (line3);
   after3 = ptr3 -> Nextline;
#endif

   if (Line1 <= 0)
      Errcode = EORANGE;
   else {
      ret = OK;
      Curln = line3;
      k = getind (Line1);
      for (i = Line1; i <= Line2; i++) {
         gtxt (k, lin);
         if (injectln (lin, Curln) == ERR || intrpt ()) {
            ret = ERR;
            break;
         }
#ifdef OLD_SCRATCH
         if (k == ptr3)     /* make sure we don't copy stuff */
            k = after3;     /* that's already been copied */
         else
            k = k -> Nextline;
#else
         if (Line1 < line3)
            k++;
         else
            k += 2;
         /*
          * 'injectln' calls blkmove, which will shift the
          * lines down one in the array, so we add two
          * instead of one to get to the next line.
          */
#endif
      }

      First_affected = min (First_affected, line3 + 1);
   }

   return (ret);
}


/* join --- join a group of lines into a single line */

int join (sub)
const uchar *sub;
{
   uchar new[MAXLINE];
   uchar txt[MAXLINE];
   register int l, line, sublen;
   int ret;
   register LINEDESC *k;

   ret = OK;
   if (Line1 <= 0) {
      Errcode = EORANGE;
      return (ERR);
   }

   sublen = strulen (sub) + 1;      /* Length of separator & EOS */
   line = Line1;

   k = get_txt (line, new);          /* Get first chunk */
   l = GetLength (k);

   for (line++; line <= Line2; line++) {
      if (intrpt ())
         return (ERR);

      if (new[l - 2] == NEWLINE) /* zap the NEWLINE */
         l--;

      k = NEXTLINE(k);   /* Get the next line */
      gtxt (k, txt);

      if (l + sublen - 1 + GetLength (k) - 1 > MAXLINE) {   /* Won't fit */ 
         Errcode = E2LONG;
         return (ERR);
      }

      memcpy (&new[l - 1], sub, sublen);       /* Insert separator string */
      l += sublen - 1;
      memcpy (&new[l - 1], txt, GetLength (k));  /* Move next line */
      l += GetLength (k) - 1;
   }

   /* All this will replace Line1 through Line2 */
   ret = injectln (new, Line2);        /* Inject the new line */
   if (ret == OK)
      ret = deleteln (Line1, Line2);   /* Delete old lines */

   Curln = Line1;

   if (First_affected > Curln)
      First_affected = Curln;

   return (ret);
}


/* move --- move line1 through line2 after line3 */

int move (line3)
int line3;
{
#ifdef OLD_SCRATCH
   register LINEDESC *k0, *k1, *k2, *k3, *k4, *k5;
#endif

   if (Line1 <= 0) {
      Errcode = EORANGE;
      return (ERR);
   }

   if (Line1 <= line3 && line3 <= Line2) {
      Errcode = EINSIDEOUT;
      return (ERR);
   }

#ifdef OLD_SCRATCH
   k0 = getind (prevln (Line1));
   k1 = k0 -> Nextline;
   k2 = getind (Line2);
   k3 = k2 -> Nextline;
   relink (k0, k3, k0, k3);
#else
   blkmove (Line1, Line2, line3);
#endif

   if (line3 > Line1) {
      Curln = line3;
#ifdef OLD_SCRATCH
      line3 -= Line2 - Line1 + 1;
#endif
   }
   else
      Curln = line3 + (Line2 - Line1 + 1);

#ifdef OLD_SCRATCH
   k4 = getind (line3);
   k5 = k4 -> Nextline;
   relink (k4, k1, k2, k5);
   relink (k2, k5, k4, k1);
#endif

   First_affected = min (First_affected, min (Line1, line3));

   return (OK);
}


/* dooverlay --- let user edit lines directly */

int dooverlay ()
{
   uchar savtxt[MAXLINE+2];   /* Need a bit of extra room on */
   uchar lin[MAXLINE+2];      /* these two buffers for NEWLINE & EOS */
   int term;               /* Termination code from 'getcmd ()' */
   int lng, vcol, lcurln;
   int row;
   LINEDESC *indx;

   if (Line1 == 0) {
      Errcode = EORANGE;
      return (ERR);
   }

   for (lcurln = Line1; lcurln <= Line2; lcurln++) {
      Curln = lcurln;
      vcol = Overlay_col - 1;
      do {
         adjust_window (Curln, Curln);
         updscreen ();
         row = Curln - Topln + Toprow;

         indx = get_txt (Curln, lin);
         lng = GetLength (indx);

         if (lin[lng - 2] == NEWLINE)    /* Clobber newline */
            lng--;

         if (vcol < 0)
            vcol = lng - 1;

         for (; lng - 1 < vcol; lng++)
            lin[lng - 1] = ' ';

         lin[lng - 1] = NEWLINE;
         lin[lng] = EOS;

         memcpy (savtxt, lin, lng + 1);   /* Make a copy of the line */
         term = getcmd (row, lin, Firstcol, &vcol);

         if (term == TERM_FUNNY) {
            if (First_affected > Curln)
               First_affected = Curln;

            return (OK);
         }

         if (strucmp (lin, savtxt) != 0) {   /* Was line changed? */
            /* Check those brackets! */
            bracket_match (lin);
            
            if (changeln (indx, lin, YES) == ERR)
               return (ERR);
         }
         else {            /* In case end-of-line is moved */
            /* Clear 'bracket mismatch' message */
            msgstr (SNULL, REMARK_MSG);
         }

         if (First_affected > Curln)
            First_affected = Curln;

         scroll_window (term);
      } while (!(term == TERM_SAME || term == TERM_FUNNY));
   }

   return (OK);
}


/* subst --- substitute "sub" for occurrences of pattern */

int subst (sub, gflag, glob)
const Pattern sub;
bool gflag, glob;
{
   uchar new[MAXLINE];
   uchar txt[MAXLINE];
   register int line, m, k, lastm;
   int j, ret;
   bool subbed;
   int tagbeg[MAXTAG], tagend[MAXTAG];
   register LINEDESC *inx;

   /* Should failed global substitutes continue ? */
   if (Globals && glob)
      ret = OK;
   else
      ret = ERR;

   if (Line1 <= 0) {
      Errcode = EORANGE;
      return (ERR);
   }

   /* the following code has been removed for your protection
      index() occasionally grabs newlines out of the character class
      counter in a pattern.  for example [0-9] doesn't work due to this

      if (cindex (Pat, NEWLINE) != -1) {  # never delete NEWLINE
         Errcode = EBADPAT;
         return (ERR);
      }
   */

   inx = getind (Line1);

   for (line = Line1; line <= Line2; line++, inx = NEXTLINE (inx)) {
      if (intrpt ())
         break;

      j = 0;
      subbed = NO;
      gtxt (inx, txt);
      lastm = -1;

      for (k = 0; txt[k] != EOS; ) {
         for (m = 1; m < MAXTAG; m++) {
            tagbeg[m] = -1;
            tagend[m] = -1;
         }

         if (gflag || !subbed)
            m = amatch (txt, k, Pat, &tagbeg[1], &tagend[1]);
         else
            m = -1;

         if (m > -1 && lastm != m) {     /* replace matched text */
            subbed = YES;
            tagbeg[0] = k;
            tagend[0] = m;
            catsub (txt, tagbeg, tagend, sub, new, &j, MAXLINE);
            lastm = m;
         }

         if (m == -1 || m == k)    /* no match or null match */
            addset (txt[k++], new, &j, MAXLINE);
         else
            k = m;  /* skip matched text */
      }

      if (subbed) {
         if (!addset (EOS, new, &j, MAXLINE)) {
            ret = ERR;
            Errcode = E2LONG;
            break;
         }

         Curln = line;
         ret = changeln (inx, new, line == Line2);

         if (First_affected > line)
            First_affected = line;

         if (ret == ERR)
            break;

         ret = OK;
      }
      else    /* !subbed */
         Errcode = ENOMATCH;
   }   /* of for (.. */

   return (ret);
}


/* dochange --- handle 'change' command */

int dochange (lin)
const uchar *lin;
{
   int ret;
   int line3;

   if (*lin != INLINE) {      /* Avoid updating with inline insertion */
      adjust_window (Line2, Line2);
      updscreen ();
   }

   First_affected = min (First_affected, Line1);

   if (*lin == INLINE) {   /* Use 'changeln' for speed */
      ret = changeln (getind (Line2), lin + 1, YES);
   }
   else {                  /* Show the user what's going on */
      warn_deleted (Line1, Line2);

      ret = append (Line2, lin);

      if (ret != ERR) {
         line3 = Curln;
         ret = deleteln (Line1, Line2);
         Curln = line3 - (Line2 - Line1 + 1);
         /* adjust for deleted lines */
      }
   }
   
   return (ret);
}
