/* pvem --- error messages                                  03/08/1987 */

#include "se.h"
#include "extern.h"

#define MAXMSG          130


static uchar *Msgbuf = NULL;
static uchar *Msgptr[MAXMSG];
static uchar Msgalloc[MAXCOLS];  /* Column allocation of status line */
static uchar Errmsg[10];         /* Emergency back-up personality */
static char Format[] = "MSG %d";


/* pvem_init --- initialise this module */

void pvem_init ()
{
   uchar path[MAXPATH];
   char errmsg[MAXLINE];
   uchar *p;
   FILE *fp;
   register int i;
   long int flen;          /* File length */
   unsigned int nb, len;
   extern uchar Sversion[];   /* Defined in 'MAIN.C' */
   
   /* Clear out status line */
   for (i = 0; i < MAXCOLS; i++)
      Msgalloc[i] = NOMSG;
      
   /* Fill 'Msgptr' with NULL pointers */
   for (i = 0; i < MAXMSG; i++)
      Msgptr[i] = NULL;
      
   /* Read in the message file */
   if (!getsefile (MESG_FILE, path))
      error (NO, "unable to locate message file");
   
   flen = getflen (path);

   if (flen == -1L) {
      sprintf (errmsg, "could not determine size of message file '%s'", path);
      error (NO, errmsg);
   }

   if (flen < 100L) {   /* Check for at least 100 bytes in the file */
      sprintf (errmsg, "message file '%s' is too short: %ld bytes", path, flen);
      error (NO, errmsg);
   }

   if ((fp = fopen ((char *)path, READ)) == NULL) {
      sprintf (errmsg, "found message file '%s'but could not open", path);
      error (NO, errmsg);
   }
   
   len = (unsigned int) flen;
   
   if ((Msgbuf = (uchar *)malloc (len)) == NULL) {
      fclose (fp);
      sprintf (errmsg, "insufficient memory to hold message file '%s'", path);
      error (NO, errmsg);
   }
   
   /* BUG: nb will always equal nb */
   if ((nb = fread (Msgbuf, sizeof (char), len, fp)) != nb) {
      fclose (fp);
      free (Msgbuf);
      Msgbuf = NULL;
      sprintf (errmsg, "opened message file '%s' but could not read in", path);
      error (NO, errmsg);
   }
   
   fclose (fp);

   for (i = 0, p = Msgbuf; i < MAXMSG && p < (Msgbuf + nb); i++) {
      Msgptr[i] = p;    /* Store address of start of line */

      while (*p != NEWLINE)   /* Skip text of line */
         p++;
         
      *p = EOS;   /* Zap NEWLINES to separate strings */
      
      p++;        /* Skip to start of next line */
   }
   
   /* Check version number of message file */
   if (strucmp (Msgptr[0], Sversion) != 0) {
      sprintf (errmsg, "wrong version of message file found in '%s'", path);
      error (NO, errmsg);
   }
}


/* pvem_close --- free message buffer memory on exit */

void pvem_close ()
{
   if (Msgbuf != NULL)
      free (Msgbuf);
}


/* printverboseerrormessage --- print verbose error message */

void printverboseerrormessage ()
{
   if (Errcode > MAXMSG || Msgptr[Errcode] == NULL) {
      sprintf ((char *)Errmsg, Format, Errcode);
      mesg (Errmsg, REMARK_MSG);
   }
   else
      mesg (Msgptr[Errcode], REMARK_MSG);

   Errcode = ENOERR;
}


/* getstring --- return a string from the resource file */

uchar *getstring (i)
register int i;
{
   if (i > MAXMSG || Msgptr[i] == NULL) {
      sprintf ((char *)Errmsg, Format, i);
      return (Errmsg);
   }
   else
      return (i == SNULL ? (uchar *)"" : Msgptr[i]);
}


/* msgstr --- display a string from the resource file */

void msgstr (i, t)
register int i;
register int t;
{
   if (i > MAXMSG || Msgptr[i] == NULL) {
      sprintf ((char *)Errmsg, Format, i);
      mesg (Errmsg, t);
   }
   else
      mesg (i == SNULL ? (uchar *)"" : Msgptr[i], t);
}


/* mesg --- display a message in the status row */

void mesg (s, t)
const uchar *s;         /* Message string */
register int t;         /* Message type   */  
{
   register int col;    /* Column counter                           */
   register int need;   /* No. of columns needed for string         */
   register int c;    
   register int first;  /* First column with given message type     */ 
   register int last;   /* Last column                              */            
   int ch;              /* Char read back in during garbage collect */

   /* Check for control-G in first char. */
   if (*s == BEL) {
      ringbell (ERR_BELL);
      s++;
      
      if (*s == EOS)
         return;
   }

   for (first = 0; first < Ncols; first++)
      if (Msgalloc[first] == t)
         break;

   for (last = first; last < Ncols; last++) {
      if (Msgalloc[last] != t)
         break;

      Msgalloc[last] = NOMSG;
   }

   for (; first > 0 && Msgalloc[first - 1] == NOMSG; first--)
      ;

   need = strulen (s) + 2; /* For characters either side of message */

   if (need > 2) {         /* non-empty message */
      if (need <= last - first)       /* fits in previous slot */
         col = first;                 /* keep it there */
      else                            /* needs a new slot */
         for (col = 0; col < Ncols - 1; col = c) {
            while (col < Ncols - 1 && Msgalloc[col] != NOMSG)
               col++;

            for (c = col; Msgalloc[c] == NOMSG; c++)
               if (c >= Ncols - 1)
                  break;

            if (c - col >= need)
               break;
         }

      /* Do we need to do a garbage collect ? */
      if (col + need >= Ncols) {
         for (col = 0, c = 0; c < Ncols; c++)
            if (Msgalloc[c] != NOMSG) {
               ch = mvinch (Nrows - 1, c);
               if (ch == STATL || ch == STATR)
                  load (ch, Nrows - 1, col, STAT_ZONE);        
               else
                  load (ch, Nrows - 1, col, MESG_ZONE);        
           
               Msgalloc[col] = Msgalloc[c];
               col++;
            }

         for (c = col; c < Ncols; c++)
            Msgalloc[c] = NOMSG;
      }

      /* Bracket message between STATL and STATR */
      load (STATL, Nrows - 1, col, STAT_ZONE);
      loadstr (s, Nrows - 1, col + 1, 0, MESG_ZONE);  
      load (STATR, Nrows - 1, col + need - 1, STAT_ZONE);      

      last = col + need - 1;
      if (last > Ncols - 1)
         last = Ncols - 1;

      /* Fill in allocation array */
      for (c = col; c <= last; c++)
         Msgalloc[c] = t;
   }

   /* Finally, tidy up unused space on status line */
   for (col = 0; col < Ncols; col++)
      if (Msgalloc[col] == NOMSG)
         load (STATSYM, Nrows - 1, col, STAT_ZONE);

   tflush ();
}
