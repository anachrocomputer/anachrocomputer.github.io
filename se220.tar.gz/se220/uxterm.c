#ifdef RCS_ID
static char RCSid[] = "$Header: term.c,v 1.7 86/11/12 11:37:30 arnold Exp $";
#endif

/*
 * $Log:   uxterm.c,v $
 * Revision 1.8  89/08/21  14:50:00  rob@inmos.co.uk
 * Completely re-hacked to become unixtty.c i.e. the Machine dep. video
 * driver for the unix tty interface
 *
 * Revision 1.7  86/11/12  11:37:30  arnold
 * Fixed winsize() to verify that cols and rows not 0 before assigning
 * them to Nrows and Ncols.
 *
 * Revision 1.6  86/10/14  11:10:36  arnold
 * Reorganization of window handling stuff. Added (untested) code for sun.
 *
 * Revision 1.5  86/10/07  14:50:48  arnold
 * Changed setterm to set_term, to avoid Unix/PC shared library conflict.
 * Fixed winsize() to set Nrows and Ncols on first call, as well.
 *
 * Revision 1.4  86/09/19  12:15:28  arnold
 * Fixes to BSD windowing for real 4.3, from BRL.
 *
 * Revision 1.3  86/07/17  17:23:19  arnold
 * Massive reorganization and cleaning up. Terminal initialization
 * stuff moved here, and homogenized.
 *
 * Revision 1.2  86/07/14  17:19:33  arnold
 * Added code that notices whether or not the window we are running in has
 * changed sizes. It definitely works on the Unix PC, and should work on
 * BRL Unix and 4.3 BSD.
 *
 * Revision 1.1  86/05/06  13:38:53  osadr
 * Initial revision
 *
 *
 */

/*
** uxterm.c
**
** provide terminal functions for se
**
*/

#include <signal.h>
#include "keys.h"

/* #define DB */

#if (BSD || S5R2) && (!AIX)
#define USE_TERMCAP     1
#else
#define USE_TERMCAP     0
#endif

/* UNIX file descriptors */
#define STDIN        (0)
#define STDOUT       (1)

/* Attribute bit-flags */
#if LINUX
#define NORMAL       (0)
#define BLACK        (0)
#define RED          (1)
#define GREEN        (2)
#define BLUE         (4)
#define BRIGHT       (8)
#define YELLOW       (RED | GREEN)
#define MAGENTA      (RED | BLUE)
#define CYAN         (GREEN | BLUE)
#define WHITE        (RED | GREEN | BLUE)
#define HUEMASK      (0xff)
#else
#define NORMAL       (0)
#define BOLD         (1)
#define UNDERLINE    (2)
#define INVERSE      (4)
#endif   /* LINUX */

#define META_BIT     (0x80)   /* Bit set by META key, if available */

#define MAXKSEQS     100   /* Actually use 94 */
#define MAXSEQ       20

struct Screen {
   unsigned char ch;
   unsigned char hue;
};

/* These two ASCII names clash with Termcap names... */
#undef SO
#undef US

#if USE_TERMCAP

string Smachine = "TermCap";

#define TGET_ROWS    tgetnum ("li");
#define TGET_COLS    tgetnum ("co");

/* Capabilities from termcap */
static int AutoMargin;  /* Automatic margins, i.e. wraps at column 80 */
static int KeyMeta;     /* Terminal has a META key that sets 0x80 bit */

static char *TI;   /* Terminal init -- whatever needed for screen ops */
static char *TE;   /* Terminal ops end                                */
static char *KS;   /* Keypad start -- application keypad mode         */
static char *KE;   /* Keypad end                                      */
static char *CM;   /* Cursor motion, used by tgoto()                  */
static char *CE;   /* Clear to end of line                            */
static char *al;   /* Hardware add (insert) single line               */
static char *AL;   /* Hardware add (insert) multiple lines            */
static char *BL;   /* Bell character                                  */
static char *dl;   /* Hardware delete single line                     */
static char *DL;   /* Hardware delete multiple lines                  */
static char *CL;   /* Clear screen                                    */
static char *ND;   /* Cursor right (unused at present)                */
static char *VS;   /* Visible cursor                                  */
static char *VE;   /* Normal cursor                                   */
static char *SO;
static char *SE;
static char *UE;
static char *US;
static char *MD;
static char *ME;

char PC;    /* Pad character, usually '\0'                     */
static char *pcstr;

extern char *tgoto (), *tgetstr ();     /* Termlib routines */

static char Caps[256];     /* Space for decoded capability strings */

#define TERMBUFSIZ      1024+1
static char termbuf[TERMBUFSIZ];

#else    /* USE_TERMCAP */

string Smachine = "TermInfo";

/*
 * Do NOT include <curses.h>, since it redefines
 * USG, ERR, and OK, to values inconsistent with what
 * we use.
 */

#include <termio.h>     /* fix a problem in /usr/include/term.h */
typedef struct termio SGTTY;
typedef char chtype;

#include <term.h>       /* should be all we really need */

#define TGET_ROWS    lines
#define TGET_COLS    columns

#define AutoMargin   auto_right_margin
#define KeyMeta      has_meta_key

#define TI     enter_ca_mode
#define TE     exit_ca_mode
#define KS     keypad_xmit
#define KE     keypad_local
/*      CM     cursor_position */
#define CE     clr_eol
#define al     insert_line
#define AL     parm_insert_line
#define BL     bell
#define dl     delete_line
#define DL     parm_delete_line
#define CL     clear_screen
/*      ND     ... */
#define VS     cursor_visible
#define VE     cursor_normal
#define SO     enter_standout_mode
#define SE     exit_standout_mode
#define UE     exit_underline_mode
#define US     enter_underline_mode
#define MD     enter_bold_mode
#define ME     exit_attribute_mode

#endif   /* USE_TERMCAP */

/* Deal with the windowing system, if there is one */
#ifdef SIGWSTS        /* PERQ */
#include <sgwin.h>

#define WINSIG       SIGWSTS
#define WINIOCTL     WIOCGETT       /* Get text display status */
#define WINSTRUCT    w_tstat
#define COLS(buf)    (buf.WTWidth)
#define ROWS(buf)    (buf.WTHeight)
#endif   /* SIGWSTS */

#ifdef SIGWIND        /* UNIX PC */
#include <sys/font.h>
#include <sys/window.h>

#define WINSIG       SIGWIND
#define WINIOCTL     WIOCGETD
#define WINSTRUCT    uwdata
#define COLS(buf)    (buf.uw_width / buf.uw_hs)
#define ROWS(buf)    (buf.uw_height / buf.uw_vs)
#endif   /* SIGWIND */

#ifdef SIGWINCH       /* 4.3 BSD and/or Sun 3.x */

#define WINSIG       SIGWINCH

#ifdef junk    /* Was #ifdef sun */

#include <sys/termios.h>

#define WINIOCTL     TIOCGSIZE
#define WINSTRUCT    ttysize
#define COLS(buf)    buf.ts_cols
#define ROWS(buf)    buf.ts_lines

#else    /* sun */

#include <sys/ioctl.h>

#define WINIOCTL     TIOCGWINSZ
#define WINSTRUCT    winsize
#define COLS(buf)    buf.ws_col
#define ROWS(buf)    buf.ws_row

#endif   /* sun */

#endif   /* SIGWINCH */


static int Colours[23] = {
   0,
#if LINUX
   WHITE,            /* Text                       */
   WHITE | BRIGHT,   /* Bar                        */
   WHITE,            /* Command line               */
   WHITE | BRIGHT,   /* Line one                   */
   WHITE | BRIGHT,   /* Line $                     */
   GREEN,            /* Status line                */
   GREEN | BRIGHT,   /* Messages on status line    */
   WHITE,            /* Line numbers               */
   WHITE,            /* Mark column                */
   WHITE | BRIGHT,   /* Current line               */
   WHITE | BRIGHT,   /* Help messages              */
   WHITE | BRIGHT,   /* Dashes in 'split-screen'   */
   RED | BRIGHT,     /* Prompts                    */
   YELLOW | BRIGHT,  /* Unprintable characters     */
   WHITE,            /* Shell escapes              */
   WHITE,            /* Source-code text           */
   GREEN,            /* Source-code code           */
   CYAN,             /* Source-code comments 1     */
   CYAN | BRIGHT,    /* Source-code comments 2     */
   GREEN | BRIGHT,   /* Source-code reserved words */
   MAGENTA | BRIGHT, /* Source-code strings        */
   RED | BRIGHT      /* Source-code pre-proc cmds. */
#else
   NORMAL,     /* Text                       */
   NORMAL,     /* Bar                        */
   NORMAL,     /* Command line               */
   NORMAL,     /* Line one                   */
   NORMAL,     /* Line $                     */
   NORMAL,     /* Status line                */
   BOLD,       /* Messages on status line    */
   NORMAL,     /* Line numbers               */
   NORMAL,     /* Mark column                */
   NORMAL,     /* Current line               */
   NORMAL,     /* Help messages              */
   NORMAL,     /* Dashes in 'split-screen'   */
   NORMAL,     /* Prompts                    */
   BOLD,       /* Unprintable characters     */
   NORMAL,     /* Shell escapes              */
   NORMAL,     /* Source-code text           */
   NORMAL,     /* Source-code code           */
   INVERSE,    /* Source-code comments 1     */
   INVERSE,    /* Source-code comments 2     */
   BOLD,       /* Source-code reserved words */
   NORMAL,     /* Source-code strings        */
   UNDERLINE   /* Source-code pre-proc cmds  */
#endif
};

static struct Screen Screen_image[MAXROWS][MAXCOLS];
static struct Screen Blanks[MAXCOLS];
static int Currow, Curcol;
static uchar *Term_type;
static int Curhue = NORMAL;
static bool Inverse_ok = NO;
static bool Uline_ok = NO;
static bool Bold_ok = NO;
static bool Colour_ok = NO;
static bool Set_term_called = NO;
static struct {            /* Table of cursor and function key sequences */
   uchar *seq;             /* Actual sequence */
   int ktok;               /* 'Se' key token for this key */
} Keytab[MAXKSEQS];

#if NO_PROTOTYPES
static void getdescrip ();
static void setcaps ();
static void addseq ();
static void sendch ();
static void clear_to_eol ();
static void sethue ();
static void winsize ();
static int raw_read ();
#else
static void getdescrip (void);
static void setcaps (const uchar *);
static void addseq (const uchar *seq, int kcode);
static void sendch (int);
static void clear_to_eol (int row, int col, int zone);
static void sethue (int);
static void winsize (int sig, ...);
static int raw_read (void);
#endif


/* load --- load a character into the screen image */

void load (ch, row, col, zone)
register int ch;
register int row, col;
int zone;
{
   struct Screen chz;
   
   if (ch < ' ' || ch > '~') {
      chz.ch = Unprintable;
      chz.hue = Colours[UPRT_ZONE];
   }
   else {
      chz.ch = ch;
      chz.hue = Colours[zone];
   }

/* if (Screen_image[row][col] != chz) { */
   if (Screen_image[row][col].ch != chz.ch || Screen_image[row][col].hue != chz.hue) {
      position_cursor (row, col);
      sethue (chz.hue);
      sendch (chz.ch);
      Screen_image[row][col] = chz;
   }
}


/* loadstr --- load a string into a field of the screen */

void loadstr (str, row, stcol, endcol, zone)
register const uchar *str;
int row, stcol, endcol;
int zone;
{
   struct Screen chz;
   register int p, c, limit;

   if (row >= 0 && row < Nrows && stcol >= 0) {
      for (p = 0, c = stcol; str[p] != EOS && c < Ncols; p++, c++) {
         if (str[p] < ' ' || str[p] > '~') {
            chz.ch = Unprintable;
            chz.hue = Colours[UPRT_ZONE];
         }
         else {
            chz.ch = str[p];
            chz.hue = Colours[zone];
         }

         if (Screen_image[row][c].ch != chz.ch || Screen_image[row][c].hue != chz.hue) {
            position_cursor (row, c);
            sethue (chz.hue);
            sendch (chz.ch);
            Screen_image[row][c] = chz;
         }
      }

      if (endcol >= Ncols - 1 && c < Ncols - 1)
         clear_to_eol (row, c, zone);
      else {
         chz.ch = ' ';
         chz.hue = Colours[zone];
         
         limit = (endcol < Ncols - 1) ? endcol : Ncols - 1;

         for (; c <= limit; c++)
            if (Screen_image[row][c].ch != chz.ch || Screen_image[row][c].hue != chz.hue) {
               position_cursor (row, c);
               sethue (chz.hue);
               sendch (chz.ch);
               Screen_image[row][c] = chz;
            }
      }
   }
}


/* cprow --- copy from one row to another for append */

void cprow (from, to)
register int from, to;
{
   register int col;

   for (col = 0; col < Ncols; col++)
      load (Screen_image[from][col].ch, to, col, TEXT_ZONE);
}


/* mdvd_init --- initialise this module */

void mdvd_init ()
{
   int i;
   
   for (i = 0; i < MAXCOLS; i++) {
      Blanks[i].ch = ' ';
      Blanks[i].hue = Colours[TEXT_ZONE];
   }
   
   for (i = 0; i < MAXKSEQS; i++) {
      Keytab[i].seq = NULL;
      Keytab[i].ktok = NOKEY;
   }
}


/* mvinch --- return character at (r,c) */

int mvinch (r, c)
int r, c;
{
   return (Screen_image[r][c].ch);
}


/* setcolr --- set a zone colour in the colour map */

void setcolr (zone, fg, bg)
int zone;
int fg, bg;
{
   Colours[zone] = fg;
}


/* restore_screen --- screen has been garbaged - fix it */

void restore_screen ()
{
   int r, c;
   
   clrscreen ();
   
   for (r = 0; r < Nrows; r++) {
      for (c = 0; c < Ncols; c++)
         if (Screen_image[r][c].ch != ' ' ||
             Screen_image[r][c].hue != NORMAL) {
            position_cursor (r, c);
            sethue (Screen_image[r][c].hue);
            sendch (Screen_image[r][c].ch);
         }
   }
         
   msgstr (SNULL, REMARK_MSG);
}


/* shellcolr --- set the colour of the shell */

void shellcolr()
{
}


#if USE_TERMCAP
/* Code for using BSD termlib -- getting capabilities, and writing them out. */

/* getdescrip --- get descriptions out of termcap entry */

static void getdescrip ()
{
   int i;
   static struct table {
      char name[3];
      char **ptr_to_cap;
   } outtab[] = {
      {"vs", &VS},      /* Make cursor extra-visible */
      {"ve", &VE},      /* Return cursor to normal   */
      {"ks", &KS},      /* Make keypad transmit      */
      {"ke", &KE},      /* Turn keypad off again     */
      {"ti", &TI},      /* Terminal initialise       */
      {"te", &TE},      /* Terminal exit             */
      {"cm", &CM},      /* Cursor motion             */
      {"ce", &CE},      /* Clear to end of line      */
      {"al", &al},      /* Insert single line        */
      {"AL", &AL},      /* Insert multiple lines     */
      {"bl", &BL},      /* Bell                      */
      {"dl", &dl},      /* Delete single line        */
      {"DL", &DL},      /* Delete multiple lines     */
      {"cl", &CL},      /* Clear screen              */
      {"nd", &ND},      /* Cursor right              */
      {"pc", &pcstr},   /* Pad character             */
      {"so", &SO},      /* Begin standout            */
      {"se", &SE},      /* End standout              */
      {"us", &US},      /* Begin underscore          */
      {"ue", &UE},      /* End underscore            */
      {"md", &MD},      /* Begin bold                */
      {"me", &ME}       /* End bold                  */
   };
   static struct intab {
      char tcname[3];
      int kcode;
   } intab[] = {
      {"kl",   CLEFT},
      {"kr",   CRIGHT},
      {"ku",   CUP},
      {"kd",   CDOWN},
      {"kI",   CINSERT},
      {"kN",   PDOWN},
      {"kP",   PUP},
      {"k1",   F1},
      {"k2",   F2},
      {"k3",   F3},
      {"k4",   F4},
      {"k5",   F5},
      {"k6",   F6},
      {"k7",   F7},
      {"k8",   F8},
      {"k9",   F9},
      {"k0",   F10},
      {"F1",   F11},
      {"F2",   F12},
      {"F3",   F13},
      {"F4",   F14},
      {"F5",   F15},
      {"F6",   F16},
      {"F7",   F17},
      {"F8",   F18},
      {"F9",   F19},
      {"FA",   F20},
      {"FB",   S_F1},
      {"FC",   S_F2},
      {"FD",   S_F3},
      {"FE",   S_F4},
      {"FF",   S_F5},
      {"FG",   S_F6},
      {"FH",   S_F7},
      {"FI",   S_F8},
      {"FJ",   S_F9},
      {"FK",   S_F10},
      {"FL",   S_F11},
      {"FM",   S_F12},
      {"FN",   S_F13},
      {"FO",   S_F14},
      {"FP",   S_F15},
      {"FQ",   S_F16},
      {"FR",   S_F17},
      {"FS",   S_F18},
      {"FT",   S_F19},
      {"FU",   S_F20}
   };
   char *p;          /* Pointer to input string (or NULL) */
   char *addr_caps;  /* Address of caps for relocation */

   addr_caps = Caps;

   AutoMargin = tgetflag ("am");      /* Auto-margin boolean */
   KeyMeta    = tgetflag ("km");      /* Meta-key boolean    */

   /* Get output string values */
   for (i = 0; i < (sizeof (outtab) / sizeof (outtab[0])); i++)
      *(outtab[i].ptr_to_cap) = tgetstr (outtab[i].name, &addr_caps);
      
   /* Get input strings */
   for (i = 0; i < (sizeof (intab) / sizeof (intab[0])); i++) {
      p = tgetstr (intab[i].tcname, &addr_caps);
      if (p != NULL)
         addseq ((uchar *)p, intab[i].kcode);
   }
}


/* setcaps --- get the capabilities from termcap file into termbuf */

static void setcaps (term)
const uchar *term;
{
   switch (tgetent (termbuf, (char *)term)) {
   case -1:
      error (NO, "couldn't open termcap file");

   case 0:
      error (NO, "no termcap entry for your terminal");

   case 1:
      getdescrip ();     /* Get terminal description */
      break;

   default:
      error (YES, "in setcaps: can't happen");
   }
}


#else    /* USE_TERMCAP */

/* Use the new terminfo package */

/* getdescrip --- pass input sequences to 'addseq' */

static void getdescrip ()
{
   int i;
   struct intab {
      char *tiname;
      int kcode;
   } intab[29];

   /* We can't simply initialise 'intab' because the TermInfo variables
    * don't evaluate to simple constants -- only constants can be used
    * as initialisers.  We've also got to check for NULL pointers */
   intab[0].tiname  = key_left;  intab[0].kcode  = CLEFT;
   intab[1].tiname  = key_right; intab[1].kcode  = CRIGHT;
   intab[2].tiname  = key_up;    intab[2].kcode  = CUP;
   intab[3].tiname  = key_down;  intab[3].kcode  = CDOWN;
   intab[4].tiname  = key_ic;    intab[4].kcode  = CINSERT;
   intab[5].tiname  = key_npage; intab[5].kcode  = PDOWN;
   intab[6].tiname  = key_ppage; intab[6].kcode  = PUP;
   intab[7].tiname  = key_f1;    intab[7].kcode  = F1;
   intab[8].tiname  = key_f2;    intab[8].kcode  = F2;
   intab[9].tiname  = key_f3;    intab[9].kcode  = F3;
   intab[10].tiname = key_f4;    intab[10].kcode = F4;
   intab[11].tiname = key_f5;    intab[11].kcode = F5;
   intab[12].tiname = key_f6;    intab[12].kcode = F6;
   intab[13].tiname = key_f7;    intab[13].kcode = F7;
   intab[14].tiname = key_f8;    intab[14].kcode = F8;
   intab[15].tiname = key_f9;    intab[15].kcode = F9;
   intab[16].tiname = key_f10;   intab[16].kcode = F10;
   intab[17].tiname = key_f11;   intab[17].kcode = F11;
   intab[18].tiname = key_f12;   intab[18].kcode = F12;
   intab[19].tiname = key_f13;   intab[19].kcode = F13;
   intab[20].tiname = key_f14;   intab[20].kcode = F14;
   intab[21].tiname = key_f15;   intab[21].kcode = F15;
   intab[22].tiname = key_f16;   intab[22].kcode = F16;
   intab[23].tiname = key_f17;   intab[23].kcode = F17;
   intab[24].tiname = key_f18;   intab[24].kcode = F18;
   intab[25].tiname = key_f19;   intab[25].kcode = F19;
   intab[26].tiname = key_f20;   intab[26].kcode = F20;
   intab[27].tiname = key_home;  intab[27].kcode = CHOME;
   intab[28].tiname = key_end;   intab[28].kcode = CEND;

   /* Read input strings */
   for (i = 0; i < (sizeof (intab) / sizeof (intab[0])); i++)
      if (intab[i].tiname != NULL)
         addseq ((uchar *)intab[i].tiname, intab[i].kcode);
}

/* setcaps --- get the capabilities from the terminfo database */

static void setcaps (term)
const uchar *term;
{
   int ret = 0;

   setupterm ((char *)term, STDOUT, &ret);

   if (ret != 1)
      error (NO, "no terminfo entry for your terminal");
      
   getdescrip ();
}


#endif   /* USE_TERMCAP */


/* addseq --- add an escape sequence to 'Keytab' */

static void addseq (seq, kcode)
const uchar *seq;
int kcode;
{
   static int freeseq = 0;
   
#ifdef DB
   int j;
   
   fprintf (stderr, "addseq (..., %d) <", kcode);

   for (j = 0; seq[j] != EOS; j++)
      if (seq[j] < 0x20 || seq[j] > 0x7e)
         fprintf (stderr, "%02x ", seq[j]);
      else
         fprintf (stderr, "%c ", seq[j]);

   fprintf (stderr, ">\n");
#endif   /* DB */

   if (freeseq < MAXKSEQS) {
      Keytab[freeseq].seq = (uchar *)malloc (strulen (seq) + 1);
      
      if (Keytab[freeseq].seq != NULL) {
         strucpy (Keytab[freeseq].seq, seq);
         Keytab[freeseq].ktok = kcode;
         freeseq++;
      }
   }
   else
      error (YES, "too many key sequences");
}  


/* winsize --- deal with the window size/position change signal */

static void winsize (sig)
int sig;
{
#ifdef WINSIG
   int i;
   static struct WINSTRUCT w;
   static struct Screen savestatus[MAXCOLS];
   int row, oldstatus = Nrows - 1;
   int cols, rows;

#if LINUX
   signal (WINSIG, winsize); /* arrange to catch the windowing signal */
#endif

   if (ioctl (STDIN, WINIOCTL, (char *)&w) == -1)
      return;
      
   cols = COLS(w);
   rows = ROWS(w);

   if (Ncols == cols && Nrows == rows) {  /* Only position changed */
#ifdef SIGWIND
      msgstr (SWINDPOS, REMARK_MSG);
#endif
      return;
   }
   
   /* Clip screen size to hardwired maxima */
   if (rows > MAXROWS)
      rows = MAXROWS;
      
   if (cols > MAXCOLS)
      cols = MAXCOLS;
   
   if ((cols != 0) && (rows != 0)) {
      Ncols = cols;     /* Write new size into 'Nrows' & 'Ncols' */
      Nrows = rows;
   }

   memcpy (savestatus, Screen_image[oldstatus], MAXCOLS * sizeof (struct Screen));
   clrscreen ();
   Toprow = 0;
   Botrow = Nrows - 3;
   Cmdrow = Botrow + 1;
   Sclen = -1;

   for (row = 0; row < Nrows; row++)       /* clear screen */
      memcpy (Screen_image[row], Blanks, MAXCOLS * sizeof (struct Screen));

   First_affected = Topln;
   adjust_window (Curln, Curln);
   updscreen ();   /* reload from buffer */

   for (i = 0; i < Ncols; i++)
      load (savestatus[i].ch, Nrows - 1, i, MESG_ZONE);
      
   msgstr (SWINDSIZE, REMARK_MSG);
#endif   /* WINSIG */
}


/* getscrsiz --- return screen size, with or without a window system */

static int getscrsiz (pr, pc)
int *pr, *pc;
{
   int rows, cols;
#ifdef WINSIG
   struct WINSTRUCT w;

   if (ioctl (STDIN, WINIOCTL, (char *)&w) == -1
       || ROWS(w) == 0 || COLS(w) == 0) {
      rows = TGET_ROWS;
      cols = TGET_COLS;
   }
   else {
      rows = ROWS(w);
      cols = COLS(w);
   }
#else
   rows = TGET_ROWS;          /* Will return -1 on error */
   cols = TGET_COLS;
#endif   /* WINSIG */

   if (rows == -1 || cols == -1)
      return (ERR);

   /* Clip screen size to hardwired maxima */
   if (rows > MAXROWS)
      rows = MAXROWS;
      
   if (cols > MAXCOLS)
      cols = MAXCOLS;
   
   *pr = rows;
   *pc = cols;

   return (OK);
}


/* term_init --- send start-up sequence to terminal */

void term_init ()
{
   if (Set_term_called) {
      /* Send the terminal initialisation strings */
      if (KS != NULL)
         tputs (KS, 1, t1ou);    /* Keypad mode */

      if (TI != NULL)       
         tputs (TI, 1, t1ou);    /* Terminal initializations */
   }
}


/* term_exit --- send close-down sequence to terminal */

void term_exit ()
{
   if (Set_term_called) {
      /* Terminal exit strings */
      if (TE != NULL)
         tputs (TE, 1, t1ou);    /* Terminal exit */

      if (KE != NULL)
         tputs (KE, 1, t1ou);    /* Keypad off again */
   }
}


/* shape_cursor --- set cursor shape or size */

void shape_cursor (size)
int size;
{
   switch (size) {
   case CUR_NORMAL:
      if (VE != NULL)
         tputs (VE, 1, t1ou);
         
      break;
      
   case CUR_INSERT:
      if (VS != NULL)
         tputs (VS, 1, t1ou);
         
      break;
   }
}


/* ringbell --- generate bleeping noises */

void ringbell (type)
int type;
{
   if (!Quiet && (BL != NULL))   /* Should fall back on '\007' */
      tputs (BL, 1, t1ou);
}


/* clrscreen --- clear physical screen */

void clrscreen ()
{
#if LINUX
   sethue (WHITE);
#else
   sethue (NORMAL);
#endif

   Curcol = Currow = 0;
   /* Clearing screen homes cursor to upper left corner */
   /* on all terminals */

   tputs (CL, 1, t1ou);
}


/* position_cursor --- position terminal's cursor to (row, col) */

void position_cursor (row, col)
int row, col;
{
   if (row < Nrows && row >= 0        /* within vertical range? */
       && col < Ncols && col >= 0     /* within horizontal range? */
       && (row != Currow || col != Curcol)) { /* not already there? */
      if (row == Currow && abs (Curcol - col) <= 4 && Curhue == NORMAL) {
         /* short motion in current line */
         if (Curcol < col)
            for (; Curcol != col; Curcol++)
               t1ou (Screen_image[Currow][Curcol].ch);
/*             tputs (ND, 1, t1ou); */ /* Cursor right */
         else
            for (; Curcol != col; Curcol--)
               t1ou ('\b');
      }
      else {
#if USE_TERMCAP
         tputs (tgoto (CM, col, row), 1, t1ou);
#else
         tputs (tparm (cursor_address, row, col), 1, t1ou);
#endif
         Currow = row;
         Curcol = col;
      }
   }
}


/* inslines --- insert 'n' lines on the screen at 'row' */

void inslines (row, n)
int row, n;
{
   register int i;

   position_cursor (row, 0);

   if (AL != NULL)
#if USE_TERMCAP
      tputs (tgoto (AL, 0, n), n, t1ou);
#else
      tputs (tparm (AL, n), n, t1ou);
#endif
   else {
      for (i = 0; i < n; i++)
         tputs (al, n, t1ou);
   }

   for (i = Nrows - 1; i - n >= Currow; i--)
      memcpy (Screen_image[i], Screen_image[i - n], Ncols * sizeof (struct Screen));

   for (; i >= Currow; i--)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (struct Screen));
}


/* dellines --- delete 'n' lines beginning at 'row' */

void dellines (row, n)
int row, n;
{
   register int i;

   position_cursor (row, 0);

   if (DL != NULL)
#if USE_TERMCAP
      tputs (tgoto (DL, 0, n), n, t1ou);
#else
      tputs (tparm (DL, n), n, t1ou);
#endif
   else {
      for (i = 0; i < n; i++)
         tputs (dl, n, t1ou);
   }

   for (i = Currow; i + n < Nrows; i++)
      memcpy (Screen_image[i], Screen_image[i + n], Ncols * sizeof (struct Screen));

   for (; i < Nrows; i++)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (struct Screen));
}


/* set_term --- initialise terminal parameters and actual capabilities */

int set_term (type, hwinsdel, pr, pc)
const uchar *type;
bool *hwinsdel;
int *pr, *pc;
{
   uchar seq[2];
   int i, alt;

   if (type == NULL)
      error (NO, "terminal type not available");

   if (type[0] == EOS)
      error (NO, "in set_term: can't happen");
   
   Term_type = (uchar *)type;

   setcaps (type);

#if USE_TERMCAP
   PC = pcstr ? pcstr[0] : '\0';

   if (*tgoto (CM, 0, 0) == 'O')   /* OOPS returned.. */
      error (NO, "terminal does not have cursor motion");
      
   if (CL == NULL)
      error (NO, "terminal cannot clear screen");
#else
   /* What do we do here */
#endif

   if (getscrsiz (pr, pc) == ERR)
      error (NO, "could not determine screen size");
   
#ifdef WINSIG
   signal (WINSIG, winsize); /* arrange to catch the windowing signal */
#endif

   /* Make sequences for all control chars */
   for (i = 1; i < ' '; i++) {
      seq[0] = i;
      seq[1] = EOS;
      addseq (seq, -i);    /* Relies on values of C_A .. C_Z */
   }

   /* Don't forget DEL */
   addseq ((uchar *)"\177", CDELETE);
   
   /* Set up alt-keys */
   for (i = 'a', alt = A_A; i <= 'z'; i++, alt--) {
      seq[0] = i | META_BIT;
      seq[1] = EOS;
      addseq (seq, alt);   /* Relies on values of A_A .. A_Z */
   }

   for (i = '0', alt = A_0; i <= '9'; i++, alt--) {
      seq[0] = i | META_BIT;
      seq[1] = EOS;
      addseq (seq, alt);   /* Relies on values of A_0 .. A_9 */
   }

   /* Can we do inverse/underline/bold attributes ? */
   Inverse_ok = (SO != NULL) && (SE != NULL);
   Uline_ok   = (US != NULL) && (UE != NULL);
   Bold_ok    = (MD != NULL) && (ME != NULL);
#if LINUX
   Colour_ok = YES;
#else
   Colour_ok = NO;
#endif
   
   /* Can we do hardware ins/del ? */
   *hwinsdel = ((al != NULL) && (dl != NULL)) ||
               ((AL != NULL) && (DL != NULL));
                
   /* Fron now on, it's safe to call TermCap/TermInfo functions */
   Set_term_called = YES;
   
   return (OK);
}


/* term_name --- return the name of the terminal */

uchar *term_name ()
{
   return (Term_type);
}


/* readkey --- read a single keystroke */

int readkey (israw)
bool israw;
{
   int key;
   int i, j;
   uchar seq[MAXSEQ];
   
   /* Flush any buffered output before reading */
   tflush ();

   if (israw) {
      key = raw_read ();
   }
   else {
      i = j = 0;
      seq[i] = raw_read ();
      
      if (seq[i] >= ' ' && seq[i] < DEL) {
         return (seq[i]);
      }
      
      for (;;) {
         for ( ; Keytab[j].seq != NULL; j++)
            if (Keytab[j].seq[i] == seq[i]) {
               if (Keytab[j].seq[++i] == EOS)
                  return (Keytab[j].ktok);
               else
                  break;
            }
               
         if (Keytab[j].seq == NULL)
            return (NOKEY);
#if 0
         seq[++i] = EOS;
         
         /* Look for complete sequence */
         for (j = 0; Keytab[j].seq != NULL; j++)
            if (strucmp (Keytab[j].seq, seq) == 0)
               return (Keytab[j].ktok);

         /* Look for initial substring */
         for (j = 0; Keytab[j].seq != NULL; j++)
            if (struncmp (Keytab[j].seq, seq, i) == 0)
               break;
               
         /* Bomb out if the sequence doesn't match */
         if (Keytab[j].seq == NULL)
            return (NOKEY);

#endif
         seq[i] = raw_read ();
      }
   }
   
   return (key);
}


/* raw_read --- read a single, raw, character */

static int raw_read ()
{
   char c;

   c = t1in ();

   if (KeyMeta)
      return (c & 0xff);    /* Code returned could be META */
   else                    
      return (c & 0x7f);    /* Code returned is ASCII */
}


/* sethue --- set video attributes on or off */

static void sethue (hue)
int hue;
{
   if (Curhue != hue) {
#if !LINUX
      /* Set inverse video... */
      if (Inverse_ok && ((Curhue & INVERSE) != (hue & INVERSE))) {
         if (hue & INVERSE)
            tputs (SO, 1, t1ou);
         else
            tputs (SE, 1, t1ou);
      }

      /* Set underlining... */
      if (Uline_ok && ((Curhue & UNDERLINE) != (hue & UNDERLINE))) {
         if (hue & UNDERLINE)
            tputs (US, 1, t1ou);
         else
            tputs (UE, 1, t1ou);
      }
         
      /* Set bold... */
      if (Bold_ok && ((Curhue & BOLD) != (hue & BOLD))) {
         if (hue & BOLD)
            tputs (MD, 1, t1ou);
         else {
            tputs (ME, 1, t1ou);    /* Turn off all modes... */

            if (Uline_ok && (hue & UNDERLINE))
               tputs (US, 1, t1ou); /* Turn underline back on */
               
            if (Inverse_ok && (hue & INVERSE))
               tputs (SO, 1, t1ou); /* Turn inverse back on */
         }
      }
#else
      if (Colour_ok && ((Curhue & HUEMASK) != (hue & HUEMASK))) {
         t1ou (0x1b);
         t1ou ('[');
         if (hue & BRIGHT)
            t1ou ('1');
         else
            t1ou ('0');

         t1ou (';');
         t1ou ('3');
         t1ou ('0' + (hue & 7));
         t1ou ('m');
      }
#endif   /* LINUX */
      
      Curhue = hue;
   }
}


/* sendch --- send a printable character, predict cursor position */

static void sendch (chr)
register int chr;
{
   if (Currow == Nrows - 1 && Curcol == Ncols - 1)
      return;    /* anything in corner causes scroll... */

   t1ou (chr);

   if (Curcol == Ncols - 1) {
      if (AutoMargin) {       /* terminal wraps when hits last column */
         Curcol = 0;
         Currow++;
      }
   }
   else       /* cursor not at extreme right */
      Curcol++;
}


/* clear_to_eol --- clear screen to end-of-line */

static void clear_to_eol (row, col, zone)
int row, col, zone;
{
   register int c;
   register bool flag;
   register bool hardware = NO;
   struct Screen chz;

   hardware = (CE != NULL);

   chz.ch = ' ';
   chz.hue = Colours[zone];
   sethue (chz.hue);
   
   flag = NO;

   for (c = col; c < Ncols; c++)
      if (Screen_image[row][c].ch != chz.ch || Screen_image[row][c].hue != chz.hue) {
         Screen_image[row][c] = chz;

         if (hardware)
            flag = YES;
         else {
            position_cursor (row, c);
            sendch (chz.ch);
         }
      }

   if (flag) {
      position_cursor (row, col);
      tputs (CE, 1, t1ou);
   }
}
