#ifdef RCS_ID
static char RCSid[] = "$Header: pat.c,v 1.2 86/07/11 15:24:44 osadr Exp $";
#endif

/*
 * $Log:        pat.c,v $
 * Revision 2.20  00/11/05  14:30:00  BJ
 * Once again removed SWT pattern characters
 *
 * Revision 2.08  89/06/02  14:30:00  BJ
 * Added ANSI prototypes
 *
 * Revision 2.07  88/06/02  14:30:00  BJ
 * Added 'Casematch' for case-insensitive pattern matching
 *
 * Revision 1.2  86/07/11  15:24:44  osadr
 * Removed Georgia Tech-ism of changeable pattern characters.
 *
 * Revision 1.1  86/05/06  13:32:49  osadr
 * Initial revision
 *
 *
 */

/*
 * pat.c
 *
 * Pattern matching subroutines for the 'se' screen editor.
 *
 * Routines declared 'static' are not necessary for the rest
 * of the editor, therefore make them invisible in the name
 * of modularity.
 */

#include "se.h"
#include "extern.h"


/* Definitions used only for pattern matching */

#define AND             '&'
#define CCL             '['
#define CCLEND          ']'
#define CHAR            'a'
#define CLOSIZE         1
#define CLOSURE         '*'
#define DASH            '-'
#define DITTO           0200     /* OK, who did this? */
#define EOL             '$'
#define NCCL            'n'
#define ANY             '.'
#define BOL             '^'
#define NOTINCCL        '^'
#define START_TAG       '('
#define STOP_TAG        ')'

#if NO_PROTOTYPES
static bool stop_tag ();
static bool start_tag ();
static void dodash ();
static void stclos ();
static int getccl ();
static int patsiz ();
static bool locate ();
static bool omatch ();
#else
static bool stop_tag (const uchar *, int *);
static bool start_tag (const uchar *, int *);  
static void dodash (const uchar *, const uchar *, int *, uchar [], int *, int);
static void stclos (uchar [], int *, int *);
static int getccl (const uchar *, int *, uchar *, int *);
static int patsiz (const uchar *);
static bool locate (int, const uchar *);
static bool omatch (const uchar *, const uchar **, const uchar *);
#endif   /* NO_PROTOTYPES */



/* Pattern matching subroutines: */

/* match --- find match anywhere on line */

bool match (lin, pat)
register const uchar *lin;
register const Pattern pat;
{
   int junk[MAXTAG];
   register int i;

   for (i = 0; lin[i] != EOS; i++)
      if (amatch (lin, i, pat, junk, junk) >= 0)
         return (YES);

   return (NO);
}


/* amatch --- (recursive) look for match starting at lin[from] */

int amatch (lin, from, pat, tagbeg, tagend)
const uchar *lin;
int from;
const Pattern pat;
int tagbeg[MAXTAG], tagend[MAXTAG];
{
   const uchar *ch;
   const uchar *lastc;
   register const uchar *ppat;
   int k = 0;

   lastc = lin + from;     /* Next unexamined input character */
   for (ppat = pat; *ppat != EOS; ppat += patsiz (ppat))
      if (*ppat == CLOSURE) {   /* A closure entry */
         ppat++;

         for (ch = lastc; *ch != EOS; )   /* Match as many as possible */
            if (!omatch (lin, &ch, ppat))
               break;
         /*
          * ch now points to character that made us fail
          * try to match rest of pattern against rest of input
          * shrink the closure by 1 after each failure
          */
         for (ppat += patsiz (ppat); ch >= lastc; ch--)
            /* successful match of rest of pattern */
            if ((k = amatch (lin, ch - (uchar *)lin, ppat, tagbeg, tagend)) >= 0)
               break;

         lastc = lin + k;   /* if k < 0, failure */
                            /* if k >= 0, success */
         break;
      }
      else if (*ppat == START_TAG)
         tagbeg[*(ppat + 1)] = lastc - (uchar *)lin;
      else if (*ppat == STOP_TAG)
         tagend[*(ppat + 1)] = lastc - (uchar *)lin;
         /* non-closure */
      else if (!omatch (lin, &lastc, ppat))
         return (-1);
      /* else
         omatch succeeded */
   return (lastc - (uchar *)lin);
}


/* omatch --- try to match a single pattern at ppat */

static bool omatch (lin, adplin, ppat)
const uchar *lin;
const uchar **adplin;
register const uchar *ppat;
{
   register const uchar *plin;
   register int bump;
   bool retval;
   uchar ch1;
   uchar ch2;

   plin = *adplin;
   retval = NO;
   if (*plin == EOS)
      return (retval);

   bump = -1;
   switch (*ppat) {
   case CHAR:
      if (Casematch) {
         if (*plin == *(ppat + 1))  /* Traditional case-sensitive */
            bump = 1;               /* pattern matching           */
      }
      else {
         ch1 = *plin;               /* New-fangled case-blind     */
         ch2 = *(ppat + 1);         /* pattern matching           */
         
         if (isupper (ch1))
            ch1 = tolower (ch1);
            
         if (isupper (ch2))
            ch2 = tolower (ch2);
            
         if (ch1 == ch2)
            bump = 1;
      }
      break;

   case BOL:
      if (plin == lin)
         bump = 0;
      break;

   case ANY:
      if (*plin != NEWLINE)
         bump = 1;
      break;

   case EOL:
      if (*plin == NEWLINE)
         bump = 0;
      break;

   case CCL:
      if (locate (*plin, ppat + 1) == YES)
         bump = 1;
      break;

   case NCCL:
      if (*plin != NEWLINE && locate (*plin, ppat + 1) == NO)
         bump = 1;
      break;

   default:
      error (YES, "in omatch: can't happen.");
   }

   if (bump >= 0) {
      *adplin += bump;
      retval = YES;
   } 

   return (retval);
}


/* locate --- look for c in char class at ppat */

static bool locate (c, ppat)         
register int c;
register const uchar *ppat;
{
   register const uchar *pclas;

   /* size of class is at ppat, characters follow */
   for (pclas = ppat + *ppat; pclas > ppat; pclas--)
      if (c == *pclas)
         return (YES);

   return (NO);
}


/* patsiz --- returns size of pattern entry at ppat */

static int patsiz (ppat)
register const uchar *ppat;
{
   switch (*ppat) {
   case CHAR:
   case START_TAG:
   case STOP_TAG:
      return (2);

   case BOL:
   case EOL:
   case ANY:
      return (1);

   case CCL:
   case NCCL:
      return (*(ppat + 1) + 2);

   case CLOSURE:
      return (CLOSIZE);
   }

   error (YES, "in patsiz: can't happen.");
   return (ERR);  /* Never reached */
}


/* makpat --- make pattern from arg[from], terminate at delim */

int makpat (arg, from, delim, pat)
const uchar *arg;
int from;
int delim;
Pattern pat;
{
   uchar ch;
   int argsub, lastsub, ls, patsub;
   int tag_nest, tag_num, tag_stack[MAXTAG];

   lastsub = patsub = 0;
   tag_num = -1;
   tag_nest = -1;
   for (argsub = from; arg[argsub] != delim && arg[argsub] != EOS;
       argsub++) {
      ls = patsub;
      if (arg[argsub] == ANY)
         addset (ANY, pat, &patsub, MAXPAT);
      else if (arg[argsub] == BOL && argsub == from)
         addset (BOL, pat, &patsub, MAXPAT);
      else if (arg[argsub] == EOL && arg[argsub + 1] == delim)
         addset (EOL, pat, &patsub, MAXPAT);
      else if (arg[argsub] == CCL) {
         if (getccl (arg, &argsub, pat, &patsub) == ERR)
            return (ERR);
      }
      else if (arg[argsub] == CLOSURE && argsub > from) {
         ls = lastsub;
         if (pat[ls] == BOL || pat[ls] == EOL ||
             pat[ls] == CLOSURE || pat[ls] == START_TAG ||
             pat[ls] == STOP_TAG)
            break;
         stclos (pat, &patsub, &lastsub);
      }
      else if (start_tag (arg, &argsub)) {
         if (tag_num >= (MAXTAG - 2))  /* Too many tagged sub-patterns */
            break;

         tag_num++;
         tag_nest++;
         tag_stack[tag_nest] = tag_num;
         addset (START_TAG, pat, &patsub, MAXPAT);
         addset (tag_num, pat, &patsub, MAXPAT);
      }
      else if (stop_tag (arg, &argsub) && tag_nest > -1) {
         addset (STOP_TAG, pat, &patsub, MAXPAT);
         addset (tag_stack[tag_nest], pat, &patsub, MAXPAT);
         tag_nest--;
      }
      else {
         addset (CHAR, pat, &patsub, MAXPAT);

         /* don't allow match of newline other than via $ */
         if ((ch = esc (arg, &argsub)) == NEWLINE)
            return (ERR);

         addset (ch, pat, &patsub, MAXPAT);
      }
      lastsub = ls;
   }

   if (arg[argsub] != delim)          /* terminated early */
      return (ERR);
   else if (addset (EOS, pat, &patsub, MAXPAT) == NO)      /* no room */
      return (ERR);
   else if (tag_nest != -1)
      return (ERR);
   else
      return (argsub);
}


/* getccl --- expand char class at arg[*pasub] into pat[*pindex] */

static int getccl (arg, pasub, pat, pindex)
const uchar *arg;
int *pasub;
uchar *pat;
int *pindex;
{
   int start;

   (*pasub)++;        /* skip over [ */
   if (arg[*pasub] == NOTINCCL) {
      addset (NCCL, pat, pindex, MAXPAT);
      (*pasub)++;
   }
   else
      addset (CCL, pat, pindex, MAXPAT);

   start = *pindex;
   addset (0, pat, pindex, MAXPAT); /* leave room for count */
   filset (CCLEND, arg, pasub, pat, pindex, MAXPAT);
   pat[start] = *pindex - start - 1;

   return ((arg[*pasub] == CCLEND) ? OK: ERR);
}


/* stclos --- insert closure entry at pat[*ppatsub] */

static void stclos (pat, ppatsub, plastsub)
uchar pat[];
int *ppatsub, *plastsub;
{
   int i, j;

   for (i = *ppatsub - 1; i >= *plastsub; i--) {   /* make a hole */
      j = i + CLOSIZE;
      addset (pat[i], pat, &j, MAXPAT);
   }
   *ppatsub += CLOSIZE;
   /* put closure in it */
   addset (CLOSURE, pat, plastsub, MAXPAT);
}


/* maksub --- make substitution string in sub */

int maksub (arg, from, delim, sub)
const uchar *arg;    
int from;      /* Index in 'arg' to begin at   */
int delim;     /* Delimiter character          */
Pattern sub;   /* Returned substitution string */
{
   int argsub, index;

   index = 0;
   for (argsub = from; arg[argsub] != delim && arg[argsub] != EOS;
       argsub++)
      if (arg[argsub] == AND) {
         addset (DITTO, sub, &index, MAXPAT);
         addset (0, sub, &index, MAXPAT);
      }
      else if (arg[argsub] == ESCAPE && isdigit (arg[argsub + 1])) {
         argsub++;
         addset (DITTO, sub, &index, MAXPAT);
         addset (arg[argsub] - '0', sub, &index, MAXPAT);
      }
      else
         addset (esc (arg, &argsub), sub, &index, MAXPAT);

   if (arg[argsub] != delim)          /* missing delimeter */
      return (ERR);
   else if (!addset (EOS, sub, &index, MAXPAT))       /* no room */
      return (ERR);
   else
      return (argsub);
}


/* catsub --- add replacement text to end of new */

void catsub (lin, from, to, sub, new, k, maxnew)
register const uchar *lin;
int from[], to[];
register const uchar *sub;
uchar *new;
int *k, maxnew;
{
   int ri;
   register int i, j;

   for (i = 0; sub[i] != EOS; i++)
      if ((sub[i] & 0xff) == DITTO) {
         ri = sub[++i];
         for (j = from[ri]; j < to[ri]; j++)
            addset (lin[j], new, k, maxnew);
      }
      else
         addset (sub[i], new, k, maxnew);
}


/* filset --- expand set at array[*pasub] into set[*pindex], stop at delim */

void filset (delim, array, pasub, set, pindex, maxset)
int delim;
const uchar *array;
int *pasub;
uchar *set;
int *pindex, maxset;
{
   static uchar upalf[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
   static uchar lowalf[] = "abcdefghijklmnopqrstuvwxyz";
   static uchar digits[] = "0123456789";
   
   for ( ; array[*pasub] != delim && array[*pasub] != EOS; (*pasub)++)
      if (array[*pasub] == ESCAPE)
         addset (esc (array, pasub), set, pindex, maxset);
      else if (array[*pasub] != DASH)   /* literal DASH */
         addset (array[*pasub], set, pindex, maxset);
      else if (*pindex <= 0 || array[*pasub + 1] == EOS ||
          array[*pasub + 1] == delim)
         addset (DASH, set, pindex, maxset);
      else if (isdigit(set[*pindex - 1]))
         dodash (digits, array, pasub, set, pindex, maxset);
      else if (islower(set[*pindex - 1]))
         dodash (lowalf, array, pasub, set, pindex, maxset);
      else if (isupper(set[*pindex - 1]))
         dodash (upalf, array, pasub, set, pindex, maxset);
      else
         addset (DASH, set, pindex, maxset);
}


/* dodash --- expand array[*pasub - 1]-array[*pasub + 1] into set[*pindex],
              from valid */

static void dodash (valid, array, pasub, set, pindex, maxset)
const uchar *valid, *array;
int *pasub;
uchar set[];
int *pindex, maxset;
{
   register int k, limit;

   (*pasub)++;
   (*pindex)--;

   limit = cindex (valid, esc (array, pasub));

   for (k = cindex (valid, set[*pindex]); k <= limit; k++)
      addset (valid[k], set, pindex, maxset);
}


/* addset --- put c in set[*pindex];  if it fits, increment *pindex */

bool addset (c, set, pindex, maxsiz)
int c;
uchar *set;
register int *pindex;
register int maxsiz;
{
   if (*pindex >= maxsiz)
      return (NO);
   else {
      set[(*pindex)++] = c;
      return (YES);
   }
}


/* esc --- map array[*pi] into escaped character if appropriate */

uchar esc (array, pi)
const uchar *array;
register int *pi;
{
   if (array[*pi] != ESCAPE)
      return (array[*pi]);
   else if (array[*pi + 1] == EOS)     /* ESCAPE not special at end */
      return (ESCAPE);
   else {
      (*pi)++;
      if (array[*pi] == 'n')
         return (NEWLINE);
      else if (array[*pi] == 't')
         return (TAB);
      else if (array[*pi] == 'b')
         return (BS);
      else
         return (array[*pi]);
   }
}


/* start_tag --- determine if we've seen the start of a tagged pattern */

static bool start_tag (arg, pi)
const uchar *arg;
int *pi;
{
   if (arg[*pi] == ESCAPE && arg[*pi + 1] == START_TAG) {
      (*pi)++;
      return (YES);
   }
   else
      return (NO);
}


/* stop_tag --- determine if we've seen the end of a tagged pattern */

static bool stop_tag (arg, pi)
const uchar *arg;
int *pi;
{
   if (arg[*pi] == ESCAPE && arg[*pi + 1] == STOP_TAG) {
      (*pi)++;
      return (YES);
   }
   else
      return (NO);
}
