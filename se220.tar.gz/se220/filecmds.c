/* filecmds --- file read/write commands                               */

#include "se.h"
#include "extern.h"

#include "cmds.h"       /* We need PIPECOM & WRITECOM */

#if UNIX
#include <sys/file.h>
#endif

#define TAB_WIDTH    8
#define MAXFILES     64
#define NO_FILE      (-1)

struct FileInfo {
   uchar *FileName;  /* Name of file (or NULL)                 */
   Lnum Curln;       /* Value of 'Curln' when file last in use */
   Lnum Topln;       /* Value of 'Topln' when file last in use */
};

static uchar Savfil[MAXPATH] = "";   /* Remembered file name */
static int Curfile = NO_FILE;
static struct FileInfo Filetab[MAXFILES];


#if NO_PROTOTYPES
static bool expand_env ();
static FILE *crypt_open ();
static void crypt_close ();

#if UNIX
extern char *getpass ();
#endif   /* UNIX */
#else
static bool expand_env (const uchar *, uchar *);
static FILE *crypt_open (const char *, const char *);
static void crypt_close (FILE *);

#if UNIX
char *getpass (const char *);
#endif   /* UNIX */
#endif   /* NO_PROTOTYPES */


/* file_init --- initialise this module */

void file_init ()
{
   int i;
   
   for (i = 0; i < MAXFILES; i++) {
      Filetab[i].FileName = NULL;
      Filetab[i].Curln = 0;
      Filetab[i].Topln = 0;
   }
}


/* doread --- read "file" after "line" */

int doread (line, file, tflag)
Lnum line;
const uchar *file;
bool tflag;
{
   register Lnum count;
   register LINEDESC *ptr;
   int len;
   register int i;
   int ret;
   uchar lin1[MAXLINE], lin2[MAXLINE];
   uchar fullname[MAXPATH];            /* File name after expansion */
   FILE *fp;

   if (Savfil[0] == EOS && file[0] != PIPECOM)
      set_filename (file);
   
   /* Expand environment variables in pathnames */
   if (expand_env (file, fullname) == NO) {
      Errcode = EFILEN;
      return (ERR);
   }
   
   if (fullname[0] == PIPECOM)
      fp = shell_open (&fullname[1], READ);
   else {
      if (Crypting)
         fp = crypt_open ((char *)fullname, READ);
      else
         fp = fopen ((char *)fullname, READ);
   }

   if (fp == NULL) {
      Errcode = ECANTREAD;
      return (ERR);
   }

   /* File opened OK, so start reading it... */
   First_affected = min (First_affected, line + 1);
   ptr = getind (line);
   ret = OK;
#ifndef OLD_SCRATCH
   Curln = line;
#endif
   msgstr (SREADING, REMARK_MSG);

   for (count = 0; fgets ((char *)lin1, MAXLINE, fp) != NULL; count++) {
      if (intrpt ()) {
         ret = ERR;
         break;
      }

      if (Compress || tflag) {   /* Expand <TAB>s */
         for (len = i = 0; lin1[i] != EOS && len < MAXLINE - 1; i++)
            if (lin1[i] != '\t')
               lin2[len++] = lin1[i];
            else
               do
                  lin2[len++] = ' ';
               while (len % TAB_WIDTH != 0 && len < MAXLINE - 1);

         lin2[len] = EOS;

         if (len >= MAXLINE) {
            ret = ERR;
            Errcode = ETRUNC;
         }

         ptr = sp_inject (lin2, len, ptr);
      }
      else     /* No expansion */
         ptr = sp_inject (lin1, strulen (lin1), ptr);

      if (ptr == NULL) {    /* Run out of room ? */
         ret = ERR;
         break;
      }
   }

   if (fullname[0] == PIPECOM) {
      if (shell_close (fp) != 0) {
         ret = ERR;
         Errcode = ESHELLERR;
      }
   }
   else {
      if (Crypting)
         crypt_close (fp);
      else
         fclose (fp);
   }

   saynum (count);
   Curln = line + count;
   svins (line, count);

   return (ret);
}


/* dowrit --- write "from" through "to" into file */

int dowrit (from, to, file, aflag, fflag, tflag)
Lnum from, to;       /* Range of lines to write     */
const uchar *file;   /* File name                   */
bool aflag;          /* Append instead of overwrite */
bool fflag;          /* Force overwrite             */
bool tflag;          /* Compress tabs               */
{
   FILE *fp;
   register Lnum line;
   register int i, j;
   uchar tabs[MAXLINE];
   uchar txt[MAXLINE];
   register LINEDESC *k;
   uchar fullname[MAXPATH];            /* File name after expansion */

   /* Expand environment variables in pathnames */
   if (expand_env (file, fullname) == NO) {
      Errcode = EFILEN;
      return (ERR);
   }
   
   if (from <= 0) {
      Errcode = EORANGE;
      return (ERR);
   }
   
   if (fullname[0] == PIPECOM)      /* Write via 'pipe' ? */
      fp = shell_open (&fullname[1], WRITE);
   else {
      if (aflag) {                  /* Append ? */
         if (Crypting)
            fp = crypt_open ((char *)fullname, APPEND);
         else
            fp = fopen ((char *)fullname, APPEND);
      }
      else if (strucmp (file, Savfil) == 0 || fflag
      || probation (WRITECOM) || file_exists (fullname) == NO) {
         if (Crypting)
            fp = crypt_open ((char *)fullname, WRITE);
         else
            fp = fopen ((char *)fullname, WRITE);
      }
      else {
         Errcode = EFEXISTS;
         return (ERR);
      }
   }

   if (fp == NULL) {
      Errcode = ECANTWRITE;
      return (ERR);
   }
   
   msgstr (SWRITING, REMARK_MSG);
   k = getind (from);

   for (line = from; line <= to; line++) {
      if (intrpt ())
         break;

      gtxt (k, txt);

      if (Compress || tflag) {   /* Compress spaces -> <TAB>s */
         for (i = 0; txt[i] == ' '; i++)
            ;

         for (j = 0; j < i / TAB_WIDTH; j++)
            tabs[j] = '\t';

         tabs[j] = EOS;

         if (fputs ((char *)tabs, fp) == EOF) {
            Errcode = EWRFAIL;
            break;
         }
            
         if (fputs ((char *)&txt[j * TAB_WIDTH], fp) == EOF) {
            Errcode = EWRFAIL;
            break;
         }
      }
      else        /* Leave spaces alone */
         if (fputs ((char *)txt, fp) == EOF) {
            Errcode = EWRFAIL;
            break;
         }

      k = NEXTLINE(k);
   }
   
   if (fullname[0] == PIPECOM) {
      if (shell_close (fp) != 0) {
         Errcode = ESHELLERR;
         return (ERR);
      }
   }
   else {
      commit_file (fp);    /* Make sure it's written */
      
      if (Crypting)
         crypt_close (fp);
      else
         fclose (fp);
   }

   sync_disk ();           /* Just in case the system crashes */

   if (line > to) {
      saynum (line - from);

      /* Did we write the entire file ? */
      if (from == 1 && line - 1 == Lastln)
         Buffer_changed = NO;
         
      /* Save if old name was null */
      if (Savfil[0] == EOS && file[0] != PIPECOM)
         set_filename (file);

      return (OK);
   }
   else
      return (ERR);  /* Write failed to complete */
}


/* doenter --- start an editing session with a file */

int doenter (file, tflag)
const uchar *file;
bool tflag;
{
   int ret;
   
   /* Remember where we were in the old file */
   if (Curfile != NO_FILE) {
      Filetab[Curfile].Curln = Curln;
      Filetab[Curfile].Topln = Topln;
   }
   
   clrbuf ();  /* Clear the old buffer... */
   mkbuf ();   /* ...make a new one       */ 

   /* Is it a binary file ? */
   if (dfltsopt (file) == ERR) {
      if (Errcode == EBINFILE) {
         Buffer_changed = NO;
         return (ERR);
      }
      else                    /* Errcode == ENOLANG   */
         Errcode = ENOERR;    /* No problem -- ignore */
   }
   
   if (file[0] == PIPECOM)
      set_filename ((uchar *)"");
   else
      set_filename (file);

   ret = doread ((Lnum)0, file, tflag);
   First_affected = 0;
   if (Curfile == NO_FILE) {
      Curln = min ((Lnum)1, Lastln);
      Topln = min ((Lnum)1, Lastln);
   }
   else {
      Curln = min (Filetab[Curfile].Curln, Lastln);
      Topln = min (Filetab[Curfile].Topln, Lastln);
   }

   if (Topln < 1)
      Topln = 1;
      
   Buffer_changed = NO;
   
   View = isreadonly (file);
   msgstr (View ? SVIEW : SNULL, VIEW_MSG);
   
   if (Src_mode)     /* Set up comment flags */
      fixcomments (1, YES);
      
   return (ret);
}


/* getfn --- get file name from lin[i]... */

int getfn (lin, i, file)
const uchar *lin;
int i;
uchar *file;
{
/* New Feature: must add filename history to this routine */
/* This may also be a good place to put filename syntax checking */
   register int j, k;
   int ret;

   ret = ERR;

   if (lin[i] == ' ') {
      j = i + 1;           /* Get new file name */
      SKIPBL (lin, j);

      for (k = 0; lin[j] != NEWLINE; k++, j++)
         file[k] = lin[j];

      file[k] = EOS;
      
      if (k > 0) {
         ret = OK;

         /* Trim off trailing blanks */
         while (--k > 0 && file[k] == ' ')
            file[k] = EOS;
      }
      else
         Errcode = EFILEN;    /* Filename syntax */
   }
   else if (lin[i] == NEWLINE && Savfil[0] != EOS) {
      strucpy (file, Savfil);    /* Or old name */
      ret = OK;
   }
   else
      if (lin[i] == NEWLINE)
         Errcode = ENOFN;     /* No saved file */
      else
         Errcode = EFILEN;    /* Filename syntax */

   return (ret);
}


/* add_filename --- add a filename to the table */

int add_filename (file)
const uchar *file;
{
   int i;
   int f;
   
   f = NO_FILE;
   
   /* Search table of known filenames */
   for (i = 0; (i < MAXFILES) && (Filetab[i].FileName != NULL); i++) {
      if (strucmp (file, Filetab[i].FileName) == 0)
         f = i;
   }

   if (i == MAXFILES) {    /* File table is full */
      Errcode = EFILETAB;
      return (ERR);
   }
   
   /* Is it a new filename? */
   if (f == NO_FILE) {
      Filetab[i].FileName = (uchar *)malloc (strulen (file) + 1);
      if (Filetab[i].FileName == NULL) {  /* No memory for filename */
         Errcode = EFILETAB;
         return (ERR);
      }

      strucpy (Filetab[i].FileName, file);
      Filetab[i].Curln = 1;
      Filetab[i].Topln = 1;
   }
   
   if (Savfil[0] == EOS)
      strucpy (Savfil, file);
   
   return (OK);
}


/* set_filename --- set the saved filename and display on status line */

void set_filename (file)
const uchar *file;
{
   int i;
   int f = NO_FILE;
   
   /* Ignore un-named buffer */
   if (file[0] == EOS) {
      Curfile = NO_FILE;
      return;
   }
   
   /* Search table of known filenames */
   for (i = 0; (i < MAXFILES) && (Filetab[i].FileName != NULL); i++) {
      if (strucmp (file, Filetab[i].FileName) == 0)
         f = i;
   }

   /* Is it a new filename? */
   if ((f == NO_FILE) && (i < MAXFILES)) {
      Filetab[i].FileName = (uchar *)malloc (strulen (file) + 1);
      if (Filetab[i].FileName == NULL)    /* No memory for filename */
         return;
         
      strucpy (Filetab[i].FileName, file);
      Filetab[i].Curln = 1;
      Filetab[i].Topln = 1;
      f = i;
   }
   
   Curfile = f;

   sprintf ((char *)Savfil, "%s", file);
   mesg (Savfil, FILE_MSG);
}


/* get_filename --- return pointer to current filename */

uchar *get_filename ()
{
   if (Savfil[0] != EOS)
      return (Savfil);
   else
      return (NULL);
}


/* new_filename --- use next or previous file from the table */

int new_filename (dir)
int dir;
{
   int status = ERR;
   int i;
   
   i = Curfile;
   
   if (i == NO_FILE) {
      Errcode = EFILEEND;
      return (status);
   }
   
   if (dir == '+') {          /* Next file */
      if (i == MAXFILES || Filetab[i + 1].FileName == NULL) {
         Errcode = EFILEEND;
         return (status);
      }
      else
         i++;
   }
   else if (dir == '-') {     /* Previous file */
      if (i == 0) {
         Errcode = EFILEBEG;
         return (status);
      }
      else
         i--;
   }
   
   strucpy (Savfil, Filetab[i].FileName);
   status = doenter (Savfil, NO);
   
   return (status);
}


/* expand_env --- expand environment variables in file names */

static bool expand_env (file, buf)
register const uchar *file;
uchar *buf;
{
   register int i;         /* Index into 'file'                */
   register int j;         /* Index into 'buf'                 */
   register int k;         /* Index into 'val' or 'name'       */
   uchar name[MAXPATH];    /* Name of user or environment var. */
   uchar *val;             /* Value of environment variable    */

   j = 0;

#if UNIX | LINUX
   /* Check for leading '~' meaning home directory */
   if (file[0] == '~') {
      for (i = 1, k = 0; file[i] != Dirsep && file[i] != EOS; i++)
         name[k++] = file[i];
         
      name[k] = EOS;
      
      if ((val = gethomedir (name)) == NULL)
         return (NO);
      
      strucpy (buf, val);     /* Copy home directory into 'buf' */
      j = strulen (buf);      /* 'j' points to EOS in 'buf'     */
   }
   else
      i = 0;
#else
   i = 0;
#endif   /* UNIX | LINUX */
   
   while (file[i] != EOS) {
      if (file[i] == ESCAPE) {
         if (file[i + 1] == ENVIRON_CH) {
            buf[j++] = file[++i];   /* the actual $ */
            i++;    /* for next time around the loop */
         }
         else
            buf[j++] = file[i++];   /* the ESCAPE */
      }
      else if (file[i] != ENVIRON_CH)  /* Normal char */
         buf[j++] = file[i++];
      else {                        /* Environment var */
         i++;                       /* Skip $ */

         for (k = 0; file[i] != Dirsep && file[i] != EOS; )
            name[k++] = file[i++];  /* Get var name */

         name[k] = EOS;

         if ((val = (uchar *)getenv ((char *)name)) != NULL)
            for (k = 0; val[k] != EOS; k++)     /* Copy 'val' into path */
               buf[j++] = val[k];
         else
            return (NO);      /* Environment variable no found */
      }
   }

   buf[j] = EOS;

   return (YES);
}



/* crypt_open --- run files through crypt */

static FILE *crypt_open (file, mode)
const char *file, *mode;
{
#if UNIX
   char buf[MAXLINE];
   FILE *fp;

   if (! Crypting)
      return (NULL);

   while (Key[0] == EOS) {
      getcryptkey ();
      if (Key[0] == EOS)
         fprintf (stderr, "%s\r\n", getstring (SCRYPT4));
   }

   switch (mode[0]) {
   case 'r':
      sprintf (buf, "crypt %s < %s", Key, file);
      fp = popen (buf, READ);
      return (fp);       /* caller checks for NULL or not */
      break;

   case 'w':
      sprintf (buf, "crypt %s > %s", Key, file);
      fp = popen (buf, WRITE);
      return (fp);       /* caller checks for NULL or not */
      break;

   case 'a':
      sprintf (buf, "crypt %s >> %s", Key, file);
      fp = popen (buf, WRITE);
      return (fp);       /* caller checks for NULL or not */
      break;

   default:
      return (NULL);
   }
#else
   return (NULL);
#endif   /* UNIX */
}


/* crypt_close --- close a pipe into 'crypt' */

static void crypt_close (fp)
FILE *fp;
{
#if UNIX
   pclose (fp);
#endif   /* UNIX */
}

#if UNIX

/* getcryptkey -- get an encryption key from the user */

void getcryptkey ()
{
   clrscreen ();      /* Does NOT wipe out Screen_image */

   term_exit ();
   ttynormal ();

   do {
      strcpy (Key, getpass ((char *)getstring (SCRYPT1)));
      if (strcmp (Key, getpass ((char *)getstring (SCRYPT2))) != 0) {
         Key[0] = EOS;
         fprintf (stderr, "%s\n", getstring (SCRYPT3));
      }
      /* else
         all ok */
   } while (Key[0] == EOS);

   ttyedit ();
   term_init ();

   restore_screen ();
}
#endif   /* UNIX */
