/* config.h --- machine and OS definitions                             */

/* Modification:
   05/11/00 BJ  Removed ACKC (Amsterdam Compiler Kit) and MINIX
   05/11/00 BJ  Removed VAX/VMS, TRANSPUTER/ISERVER, ATARI/TOS and SIRIUS
   19/06/90 BJ  Added Transputer and 'icc'
   14/03/91 BJ  Added #undefs for LATTICE and ATARI
   14/03/91 BJ  Added AIX
   25/11/91 BJ  Added windowing display driver support
   17/06/98 BJ  Added MS Win32 support
*/

/* The names in this file are defined as '0' or '1' so that the '#if'
   directives in the code can use '&' and '|' on them.  If all compilers
   understood '#if defined (...)' then we could just define the names
   without values, but they don't, so we can't.
*/

/* Undefine the predefines */
#ifdef MSDOS
#undef MSDOS
#endif

/* OS */
#define MSWIN32            0  /* Microsoft Win32 (Windows 95/98/NT)    */
#define MSDOS              0  /* MS-DOS V2.00 or higher                */
#define V7                 0  /* Good old Seventh Edition UNIX         */
#define BSD4_1             0  /* Berkeley 4.1                          */
#define BSD4_2             0  /* Berkeley 4.2                          */
#define BSD4_3             0  /* Berkeley 4.3                          */
#define USG                0  /* New-fangled System V                  */
#define S5R2               0  /* System V Revision 2                   */
#define AIX                0  /* IBM's AIX                             */
#define LINUX              1  /* Linux                                 */

#define BSD  (BSD4_1 | BSD4_2 | BSD4_3)
#define UNIX (V7 | BSD | USG | S5R2 | AIX)

/* Hardware */
#define IBMPC              0  /* IBM PC with MDPA, CGA, EGA, VGA       */

/* Display Type */
#define XWINDOWS           0  /* X Windows                             */
#define MSWINDOWS          0  /* MS Windows on IBM PC                  */

/* Compiler */
#define MSC                0  /* Microsoft C                           */
#define TCC                0  /* Borland Turbo C                       */
#define GNUC               1  /* GNU C                                 */

/* Anachronisms */
#define OLD_STRINGS        0  /* Set to '1' if you need 'index ()'     */
#define NO_ENUM            0  /* Set to '1' if you have no 'enum'      */
#define NO_VOID            0  /* Set to '1' if you have no 'void'      */
#define NO_STRUCT_ASSIGN   0  /* Set to '1' if you cant assign structs */
#define NO_CONST           0  /* Set to '1' if you have no 'const'     */
#define NO_PROTOTYPES      0  /* Set to '1' if no function prototypes  */
