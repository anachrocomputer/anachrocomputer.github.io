#ifdef RCS_ID
static char RCSid[] = "$Header: misc.c,v 2.10 91/12/06 00:00:00 BJ Exp $";
#endif

/*
 * $Log:   misc.c,v $
 * Revision 2.10  91/12/06  00:00:00  BJ
 * Moved 'mntoc ()' into 'bind.c'
 *
 * Revision 2.08  89/04/03  00:00:00  BJ
 * Moved 'twrite ()' and 'tflush ()' out
 * Moved 'get_txt ()' in
 *
 * Revision 2.01  88/05/17  01:00:00  BJ
 * Renamed 'index ()' to avoid clash with C library
 * Added 'mntoc ()'
 *
 * Revision 2.0  87/10/26  19:00:00  BJ
 * Added portability code
 *
 * Revision 1.1  86/05/06  13:37:51  osadr
 * Initial revision
 *
 *
 */

/*
 * misc.c
 *
 * lots of miscellaneous routines for the screen editor.
 */

#include "se.h"
#include "extern.h"

#include "ctrl.h"

#if NO_PROTOTYPES
static bool rc_match ();
#else
static bool rc_match (const uchar *, const char *, const uchar *);
#endif


/* cindex --- return position of character in string */

int cindex (str, c)
register const uchar *str;
register int c;
{
   register int i;

   for (i = 0; *str != EOS; i++)
      if (*str++ == c)  
         return (i);

   return (-1);
}


/* strmap --- map a string to upper/lower case */

void strmap (str, ul)
register uchar str[];
int ul;
{
#if MSC | TCC
   if (isupper (ul))
      strupr (str);
   else
      strlwr (str);
#else
   register int i;

   /* BJ: fixed TWO horrible bugs here... */

   if (isupper (ul))
      for (i = 0; str[i] != EOS; i++)
         str[i] = islower (str[i]) ? toupper (str[i]) : str[i];
   else
      for (i = 0; str[i] != EOS; i++)
         str[i] = isupper (str[i]) ? tolower (str[i]) : str[i];
#endif   /* MSC | TCC */
}


/* xindex --- invert condition returned by cindex */

int xindex (array, c, allbut, lastto)
const uchar *array;
int c;
int allbut, lastto;
{
   if (c == EOS)
      return (-1);

   if (allbut == NO)
      return (cindex (array, c));

   if (cindex (array, c) > -1)
      return (-1);

   return (lastto + 1);
}


/* ctoi --- convert decimal string to a single precision integer */

int ctoi (str, i)
register const uchar *str;
register int *i;
{
   register int ret;

   SKIPBL (str, *i);
   for (ret = 0; isdigit (str[*i]); (*i)++)
      ret = ret * 10 + (str[*i] - '0');

   return (ret);
}


/* zapnl --- zap NEWLINE on end of line */

void zapnl (lin)
register uchar *lin;
{
   register uchar *np;
         
   if ((np = struchr (lin, NEWLINE)) != NULL)
      *np = EOS;
}


/* dfltsopt --- set the 's' option to the extension on the file name */

int dfltsopt (name)
const uchar *name;   /* Pathname of file */
{
   register int i;
   register int j;
   int ret = OK;
   int lastc;

   if (name == NULL)
      ret = dosopt (NULL);       /* No name at all */
   else {
      lastc = strulen (name) - 1;
      
      /* Find file basename */
      for (i = lastc; i >= 0; i--)
         if (name[i] == Dirsep)
            break;
         
      /* Search backwards for suffix */
      for (j = lastc; j >= i; j--)
         if (name[j] == Filsep) {
            ret = dosopt (&name[j + 1]);
            break;
         }

      if (j <= i)             /* No suffix found */
         ret = dosopt ((uchar *)"");
   }

   return (ret);
}


/* bracket_match --- do bracket-matching if in Source-code mode */

void bracket_match (lin)
const uchar *lin;
{
   uchar stack[MAXLINE];   /* Maintain stack of brackets */
   uchar q;
   bool bm = YES;
   bool inquote;
   int b;                  /* Stack pointer              */
   
   if (!Src_mode)
      return;
      
   q = EOS;
   inquote = NO;

   for (b = 0; *lin != EOS && b >= 0; lin++) {
      if (inquote) {    /* Are we inside quotes */
         if (*lin == q)
            inquote = NO;
      }
      else {            
         if (*lin == Q1 || *lin == Q2) {   /* Open quote ? */
            q = *lin;           /* Remember type of quote */
            inquote = YES;
         }
         else {
            switch (*lin) {
               case '(':
                  stack[b++] = ')';    /* Expect close round bracket */
                  break;
               case '[':
                  stack[b++] = ']';    /* Expect close square bracket */
                  break;
               case ')':
               case ']':
                  b--;                 /* Pop stack & check for match */
                  if (b >= 0 && stack[b] != *lin)
                     b = -1;
                     
                  break;
            }
         }
      }
   }
         
   if (b != 0)
      bm = NO;
      
   msgstr (bm ? SNULL : SBRACKMATCH, REMARK_MSG);
}


/* showpat --- do option '/' display */

void showpat ()
{
   uchar str[MAXLINE];
   
   if (Patchoise && Savpat[0] != EOS) {    /* Pattern display */
      sprintf ((char *)str, "/%s/", Savpat);
      mesg (str, PAT_MSG);
   }
   else
      msgstr (SNULL, PAT_MSG);
}


/* dosopt --- set source language-related options */

int dosopt (str)
const uchar str[];
{
/*
 * Note that se's special control characters are NOT processed,
 * and therefore should NOT be used in one's .serc file.
 */
   uchar file[MAXPATH];
   uchar lin[MAXLINE];
   FILE *fp;
   bool recognised;
   int status = OK;
   int len, cursav;

   if (getsefile (SERC_FILE, file) == NO ||
       (fp = fopen ((char *)file, READ)) == NULL) {
      Errcode = ENOLANG;
      return (ERR);
   }

   /* Reset options to initial state */
   reset_opts ();
   clearkws ();
   
   recognised = NO;
   
   /* Start reading SERC file */
   while (fgets ((char *)lin, MAXLINE, fp) != NULL && status == OK) {
      if (lin[0] == '#' || lin[0] == NEWLINE || lin[0] == '}')
         ;       /* Comment or blank line in .serc file */
      else if (lin[0] == '{') {
         if (rc_match (lin, "LANG", str) == NO &&
             rc_match (lin, "TERM", term_name ()) == NO ) {
            /* Skip over inactive block */
            while (fgets ((char *)lin, MAXLINE, fp) != NULL)
               if (lin[0] == '}')
                  break;

            if (lin[0] != '}')       /* End of file */
               status = EOF;
         }
         else {
            recognised = YES;

            if (lin[1] == '~') {
               status = ERR;
               Errcode = EBINFILE;
            }
         }
      }
      else {          /* Most of this code stolen from edit () */
         len = 0;
         cursav = Curln;
         if (getlst (lin, &len, &status) == OK) {
            if ((status = ckglob (lin, &len)) == OK)
               status = doglob (lin, &len, &cursav);
            else if (status != ERR)
               status = docmd (lin, len, NO);
         }

         if (status == ERR) {
            if (Errcode == EHANGUP)
               hangup ();

            Curln = min (cursav, Lastln);
         }
      }
   }

   fclose (fp);

   /* Did we spot a file suffix we know? */
   if (!recognised) {
      Errcode = ENOLANG;
      status = ERR;
   }
   
   return (status);
}


/* rc_match --- compare file suffix with line out of .rc file */

static bool rc_match (lin, type, lang)
const uchar *lin;     /* line will be "{~ LANG exe com" or "{ LANG c h" */
const char *type;    /* "LANG" or "TERM" */
const uchar *lang;    /* "c" */
{
   int i, j;
   uchar suff[MAXLINE];    /* Suffix parsed out of 'lin' */
   bool tspec;
   
   if (lang == NULL)    /* 'se' invoked without a file name */
      return (NO);   
      
   i = 1;
   if (lin[i] == '~')
      i++;
      
   tspec = YES;   /* First time through, specifies type of conditional */
   
   while (lin[i] != NEWLINE) {
      SKIPBL(lin, i);
      if (lin[i] != NEWLINE) {
         for (j = 0; j < (MAXLINE - 1) &&
                     lin[i] != ' ' && lin[i] != NEWLINE; i++, j++)
            suff[j] = lin[i];
            
         suff[j] = EOS;

         if (tspec) {
            if (strucmpi (suff, type) != 0)   /* Compare type */
               return (NO);
            else
               tspec = NO;
         }
         else if (strucmpi (suff, lang) == 0)  /* Compare suffix */
            return (YES);
      }
   }
   
   return (NO);
}


#if !(MSC | TCC)

/* strcmpi --- compare strings regardless of case */

int strcmpi (s1, s2)
register const char *s1, *s2;
{
/*
 * This relies on tolower from <ctype.h>. On the PC, case mapping
 * is made more complex by the international character set.
 * We won't worry about that yet, though...
 */
   register char c1, c2;

   for (; (*s1 && *s2); s1++, s2++) {
      c1 = *s1;
      c2 = *s2;
    
      if (isupper (c1))
         c1 = tolower (c1);

      if (isupper (c2))
         c2 = tolower (c2);
                        
      if (c1 < c2)
         return (-1);
      else if (c1 > c2)
         return (1);
   }
         
   if (*s1)
      return (1);
   else if (*s2)
      return (-1);
      
   return (0);
}

#endif   /* !(MSC | TCC) */


/* verstr --- build the version ID string */

void verstr (buf)
uchar *buf;
{
   extern uchar Sversion[];   /* Defined in 'MAIN.C'     */
   extern uchar Smachine[];   /* Defined in video driver */
   extern uchar Sopsys[];     /* Defined in 'OS.C'       */
   extern uchar Sbuf[];       /* Defined in 'SCRATCH.C   */

   strucpy (buf, Sversion);
   strucat (buf, " ");
   strucat (buf, Smachine);
   strucat (buf, " ");
   strucat (buf, Sopsys);
   strucat (buf, " ");
   strucat (buf, Sbuf);
}


/* get_txt --- locate text for line, copy to 'str' */

LINEDESC *get_txt (line, str)
Lnum line;
register uchar *str;
{
   register LINEDESC *k;

   k = getind (line);
   gtxt (k, str);

   return (k);
}


/* mkdatestr --- generate date string according to function code */

void mkdatestr (str, fn)
uchar *str;
int fn;
{
   struct TimeInfo ti;
   
   get_time (&ti);
   
   switch (fn) {
   case TT_DATE:
      switch (ti.DateFmt) {
      case DDMMYY:
         sprintf ((char *)str, "%02d%c%02d%c%04d",
                  ti.Day, ti.DateSep, ti.Month + 1, ti.DateSep, ti.Year);
         break;
      case MMDDYY:
         sprintf ((char *)str, "%02d%c%02d%c%04d",
                  ti.Month + 1, ti.DateSep, ti.Day, ti.DateSep, ti.Year);
         break;
      case YYMMDD:
         sprintf ((char *)str, "%04d%c%02d%c%02d",
                  ti.Year, ti.DateSep, ti.Month + 1, ti.DateSep, ti.Day);
         break;
      }
      break;
   case TT_TIME:
      if (ti.Tfh)          /* 24 hour */
         sprintf ((char *)str, "%02d%c%02d%c%02d",
                 ti.Hour, ti.TimeSep, ti.Minute, ti.TimeSep, ti.Second);
      else                 /* 12 hour */
         sprintf ((char *)str, "%d%c%02d%c%02d%c",
                  (ti.Hour > 12) ? ti.Hour - 12: ti.Hour,
                  ti.TimeSep, ti.Minute, ti.TimeSep, ti.Second,
                  (ti.Hour > 11) ? 'p' : 'a');
      break;
   case TT_MONTH:
      strucpy (str, getstring (SMONTHTAB + ti.Month));
      break;
   case TT_DAY2:
      sprintf ((char *)str, "%02d", ti.Day);
      break;
   case TT_MONTH2:
      sprintf ((char *)str, "%02d", ti.Month + 1);
      break;
   case TT_YEAR2:
      sprintf ((char *)str, "%02d", ti.Year % 100);
      break;
   case TT_YEAR4:
      sprintf ((char *)str, "%4d", ti.Year);
      break;
   }
}


/* probation --- return YES if the user has repeated a command */

bool probation (cmd)
int cmd;
{
   static int Probation = EOS;
   
   if (Probation == cmd)
      return (YES);        /* User asked for it again */
   else {
      Probation = cmd;     /* If same command is repeated, */
      return (NO);         /* we'll keep quiet             */
   }
}


/* toggle --- toggle a boolean option and update a status message */

int toggle (pflag, onmsg, offmsg, msgtype)
bool *pflag;
int onmsg, offmsg, msgtype;
{
   *pflag = ! *pflag;
   msgstr (*pflag ? onmsg : offmsg, msgtype);
   
   return (OK);
}
