/* sesig --- signal-handling code for 'se'                  15/02/1992 */

#include "se.h"
#include "extern.h"

#include <signal.h>


/* Concerning interrupts: */
static bool Int_caught = NO;   /* Caught a SIGINT from user                 */
#if UNIX | LINUX
static bool Hup_caught = NO;   /* Caught a SIGHUP when phone line dropped   */
#endif
#if BSD
static bool Catching_stops;    /* Catching or ignoring SIGTSTP's?           */
#endif
static bool Reading = NO;      /* Are we doing terminal input?            */


#if NO_PROTOTYPES
static void int_hdlr ();
#if UNIX | LINUX
static void hup_hdlr ();
#if BSD
static void stop_hdlr ();
#endif
#endif   /* UNIX | LINUX */

#else    /* NO_PROTOTYPES */

#if MSDOS
static void int_hdlr (int sig);
#else
static void int_hdlr (int sig, ...);
#endif
#if UNIX | LINUX
static void hup_hdlr (int sig, ...);
#if BSD
static void stop_hdlr (int sig, ...);
#endif
#endif   /* UNIX | LINUX */
#endif   /* NO_PROTOTYPES */


/* sig_init --- initialise this module */

void sig_init ()
{
/* void (*old_int)(); */
#if UNIX | LINUX
   void (*old_quit)();
#if BSD
   void (*old_stop)();
#endif
   /* Catch quit and hangup signals */
/*
 * In the terminal driver munging routines, we set Control-P
 * to generate an interrupt, and turn off generating Quits from
 * the terminal.  Now we just ignore them if sent from elsewhere.
 */

   signal (SIGHUP, hup_hdlr);
   old_quit = signal (SIGQUIT, SIG_IGN);
#endif   /* UNIX | LINUX */

   signal (SIGINT, int_hdlr);

#ifdef notdef
/*
 * This is commented out so that se can be run from the news
 * software.  Commenting it out will also allow you to put it
 * in the background, which could give you trouble. So beware.
 */

   /* fired off into the background, refuse to run */
   if (old_int == SIG_IGN || old_quit == SIG_IGN) {
      if (isatty (fileno (stdin))) {
         fprintf (stderr, "%s: I refuse to run in the background.\n",
            argv[0]);
         exit (EXIT_FAILURE);
      }
      /* else
         assume input is a script */
   }
#endif   /* notdef */

#if BSD
   old_stop = signal (SIGTSTP, stop_hdlr);

   if (old_stop == SIG_IGN) {      /* running Bourne shell */
      signal (SIGTSTP, SIG_IGN);      /* restore it */
      Catching_stops = NO;
   }
   else    /* running C-shell or BRL sh, catch Control-Z's */
      Catching_stops = YES;
#endif   /* BSD */
}


/* hangup --- dump contents of edit buffer if SIGHUP occurs */

void hangup ()
{
#if UNIX | LINUX
   /* close terminal to avoid hanging on any accidental I/O: */
   ttynormal ();
   close (0);
   close (1);
   close (2);

   signal (SIGHUP, SIG_IGN);
   signal (SIGINT, SIG_IGN);
   signal (SIGQUIT, SIG_IGN);

   Hup_caught = NO;
   Crypting = NO;     /* force buffer to be clear text */
   dowrit ((Lnum)1, Lastln, (uchar *)"se.hangup", NO, YES, NO);
   clrbuf ();
   exit (EXIT_FAILURE);
#endif   /* UNIX | LINUX */
}


/* intrpt --- see if there has been an interrupt or hangup */

bool intrpt ()
{
   if (Int_caught) {
      Errcode = EBREAK;
      Int_caught = NO;
      return (YES);
   }
#if UNIX | LINUX
   else if (Hup_caught) {
      Errcode = EHANGUP;
      Hup_caught = NO;
      return (YES);
   }
#endif   /* UNIX | LINUX */

   return (NO);
}


/* in_read --- set or clear 'Reading' flag */

void in_read (flag)
bool flag;
{
   Reading = flag;
}


/* dosuspend --- send the editor into the background */

int dosuspend ()
{
#if BSD
   if (Catching_stops) {
      if (Buffer_changed)
         fprintf (stderr, "WARNING: buffer not saved\r\n");

      kill (getpid (), SIGTSTP);
      /* 'stop_hdlr ()' will do all the work for us */
   }
#else
   msgstr (SNOTSTP, REMARK_MSG);
#endif   /* BSD */

   return (OK);
}


/* int_hdlr --- handle an interrupt signal */

static void int_hdlr (sig)
int sig;
{
#if !BSD4_2
   signal (SIGINT, int_hdlr);
#endif

   sig++;      /* Not really used */
   Int_caught = YES;
}


#if UNIX | LINUX

/* hup_hdlr --- handle a hangup signal */

static void hup_hdlr (sig)
int sig;
{
#if BSD4_2
   /* do things different cause of 4.2 (sigh) */
   Hup_caught = YES;

   if (Reading)    /* doing tty i/o, and that is where hup came from */
      hangup ();
#else
   signal (SIGHUP, hup_hdlr);
   Hup_caught = YES;
#endif   /* BSD4_2 */
}


#if BSD

/* stop_hdlr --- handle the berkeley stop/suspend signal */

static void stop_hdlr (sig)
int sig;
{
   clrscreen ();
   term_exit ();
   ttynormal ();

#if BSD4_2
   /* this handler remains in effect, use uncatchable signal */
   kill (getpid(), SIGSTOP);
#else
   /* action was reset to default when we caught it */
   kill (getpid(), SIGTSTP);
#endif   /* BSD4_2 */

   /*
    * user does a "fg"
    */

#if !BSD4_2
   signal (SIGTSTP, stop_hdlr);    /* reset stop catching */
#endif   /* BSD4_2 */

   ttyedit ();
   term_init ();
   restore_screen ();
}

#endif   /* BSD */
#endif   /* UNIX | LINUX */


/* do_coredump --- generate a core dump */

void do_coredump ()
{
#if UNIX | LINUX
      signal (SIGQUIT, SIG_DFL);      /* restore normal quit handling */
      kill (getpid (), SIGQUIT);      /* dump memory */
#else
      abort ();
#endif   /* UNIX | LINUX */
}


/* sigread --- handle signals during keyboard reads */

void sigread ()
{
#if UNIX | LINUX
   if (Hup_caught)
      hangup ();
   else {  /* must be a SIGINT at present */
      Int_caught = NO;
      Errcode = ENOERR;
   }
#endif   /* UNIX | LINUX */
}
