# poo --- test 'se' on Ratfor

   integer i, idata, jdata
   integer for1, for2, ifor, jfor
   data for1 /42/
   common /poocom/ for2
   
   for (i = 0; i < 42; i++)
      ;
      
   stop
   end
