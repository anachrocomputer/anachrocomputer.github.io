/* ibmpc --- machine-dependent routines for IBM PC          18/06/1987 */
/* Copyright (c) 1987 BJ, Froods Software Development                  */

#include <dos.h>
#include <conio.h>   /* Prototype for 'putch' */

#include "keys.h"

/* #define DB1 */

/* Define this to drive WYSE 700, Opus / Paradise EGA or Axtel */
#define ODDVID

/* Export name of machine & status of ODDVID */
#ifdef ODDVID
string Smachine = "IBM PC (odd)";
#else
string Smachine = "IBM PC";
#endif   /* ODDVID */


/* Mouse control co-ords */
#define MCURX           320
#define MCURY           100
#define LTHRESH         (MCURX - 8)
#define RTHRESH         (MCURX + 8)
#define UTHRESH         (MCURY - 8)
#define DTHRESH         (MCURY + 8)

#define IRET   0xcf           /* IRET opcode */

#define VIDEO_INT    0x10     /* INT for video BIOS         */
#define KEYB_INT     0x16     /* INT for keyboard BIOS      */
#define MOUSE_INT    0x33     /* INT number for mouse calls */


#define MINIT        0x00     /* Initialise                 */
#define MGETPOS      0x03     /* Get position & buttons     */
#define MSETPOS      0x04     /* Set position               */
#define MGETPRESS    0x05     /* Get button press data      */
#define MGETREL      0x06     /* Get button release data    */
#define MLPENOFF     0x0e     /* Light pen emulation off    */


#define SET_MODE     0x00
#define SET_POS      0x02
#define SCROLL_UP    0x06
#define SCROLL_DOWN  0x07
#define GET_MODE     0x0f

/* Screen sizes */
#define MONO_NROWS      25
#define MONO_NCOLS      80
#define HP95_NROWS      16
#define HP95_NCOLS      40
#define CGA_NROWS       25
#define CGA_NCOLS       80
#define EGA_NROWS       25
#define EGA_NCOLS       80

#define BLACK           0
#define BLUE            1
#define GREEN           2
#define CYAN            3
#define RED             4
#define MAGENTA         5
#define YELLOW          6
#define WHITE           7
#define BRIGHT          8

typedef unsigned int scancode;

#if NO_PROTOTYPES
static void clear_to_eol ();
static void capslite ();
static scancode getscan ();
static void flashmode ();
static bool minit ();
static int mread ();
static void mmove ();
static int mbutton ();
/* Following routines are in assembler... */
void mvaddch ();
void mvaddchb ();
void setvseg ();
void setncols ();
bool chkinp ();
#else
static void clear_to_eol (int row, int col, int zone);
static void capslite (void);
static scancode getscan (void);
static void flashmode (bool);
static bool minit (void);
static int mread (int *, int *);
static void mmove (int, int);
static int mbutton (int, int, int *, int *);
/* Following routines are in assembler... */
void mvaddch (int row, int col, unsigned int ch);
void mvaddchb (int row, int col, unsigned int ch);
void setvseg (unsigned int seg);
void setncols (int cols);
bool chkinp (bool flag);
#endif

#ifdef DB1
static bool Started = NO;
#endif   /* DB1 */
static unsigned Screen_image[MAXROWS][MAXCOLS];
static unsigned Blanks[MAXCOLS];    /* Blanks for filling in lines     */
static int Cur_size = CUR_NORMAL;   /* Cursor state                    */
static int Cur_on = YES;
static bool Mono = NO;              /* Flag for MDPA                   */
static bool Has_ega = NO;           /* Flag for EGA card               */
static bool Mouset = NO;            /* Mouse driver flag               */
static bool Use_mouse = NO;         /* Mouse toggle                    */
static bool New_bios = NO;          /* Flag for new 101 key keyboards  */
static int Old_mode = -1;           /* Original VDU mode               */
#ifdef ODDVID
static bool Use_bios = NO;          /* Flag for non-standard VDU modes */
#endif
static int Colours[23] = {
   0,
   WHITE,            /* Text                       */
   WHITE | BRIGHT,   /* Bar                        */
   WHITE,            /* Command line               */
   WHITE | BRIGHT,   /* Line one                   */
   WHITE | BRIGHT,   /* Line $                     */
   GREEN,            /* Status line                */
   GREEN | BRIGHT,   /* Messages on status line    */
   WHITE,            /* Line numbers               */
   WHITE,            /* Mark column                */
   WHITE | BRIGHT,   /* Current line               */
   WHITE | BRIGHT,   /* Help messages              */
   WHITE | BRIGHT,   /* Dashes in 'split-screen'   */
   RED | BRIGHT,     /* Prompts                    */
   YELLOW | BRIGHT,  /* Unprintable characters     */
   WHITE,            /* MS-DOS shell               */
   WHITE,            /* Source-code text           */
   WHITE,            /* Source-code code           */
   CYAN,             /* Source-code comments 1     */
   CYAN | BRIGHT,    /* Source-code comments 2     */
   WHITE | BRIGHT,   /* Source-code reserved words */
   MAGENTA | BRIGHT, /* Source-code strings        */
   RED | BRIGHT      /* Source-code pre-proc cmds. */
};


/* mdvd_init --- initialise this module */

void mdvd_init ()
{
   register int row, col;

   /* Initialise array of blanks */
   for (col = 0; col < MAXCOLS; col++)
      Blanks[col] = (WHITE << 8) | ' ';       /* Set to white blanks */
      
   /* Clear virtual screen array */
   for (row = 0; row < MAXROWS; row++)
      for (col = 0; col < MAXCOLS; col++)
         Screen_image[row][col] = (WHITE << 8) | ' ';
}


/* term_init --- send start-up sequence to terminal */

void term_init ()
{
   flashmode (NO);   /* We want bright backgrounds inside 'se' */
}


/* term_exit --- send close-down sequence to terminal */

void term_exit ()
{
   union REGS r;

   flashmode (YES);              /* Restore DOS defaults on exit */
   shape_cursor (CUR_NORMAL);
   
   /* Restore video mode */
   if (Old_mode != -1) {
      r.h.ah = SET_MODE;
      r.h.al = Old_mode;
      int86 (VIDEO_INT, &r, &r);
   }
}


/* setcolr --- set the colour of a screen zone */

void setcolr (zone, fg, bg)
int zone;
int fg, bg;
{
#ifdef DB1
   if (Started == NO) {
      puts ("setcolr");
      getch ();
   }
#endif   /* DB1 */
   Colours[zone] = fg + (bg << 4);
}


/* shellcolr --- fix colour of screen for DOS shell */

void shellcolr ()
{
   register int i;
   register int row;
   unsigned int ch;
   
   row = Nrows - 1;
   ch = ' ' | (Colours[SHELL_ZONE] << 8);
   
   for (i = 0; i < Ncols; i++)
#ifdef ODDVID
      if (Use_bios)
         mvaddchb (row, i, ch);
      else
#endif
         mvaddch (row, i, ch);
}


/* mvinch --- read a character back from the screen image */

int mvinch (r, c)
int r, c;
{
   return (Screen_image[r][c] & 0xff);
}


/* cprow --- copy from one row to another for append */

void cprow (from, to)
register int from, to;
{
   register int col;

   for (col = 0; col < Ncols; col++)
      load (Screen_image[from][col] & 0xff, to, col, TEXT_ZONE);
}


/* load --- load a character onto the screen at given coordinates */

void load (chr, row, col, zone)
register int chr;
register int row, col;
int zone;
{
   register unsigned int ch;

#ifdef DB1
   if (Started == NO) {
      puts ("load");
      getch ();
   }
#endif   /* DB1 */
   if (chr < ' ')
      ch = (Colours[UPRT_ZONE] << 8) | Unprintable;
   else
      ch = (Colours[zone] << 8) | chr;

   if (row >= 0 && row < Nrows && col >= 0 && col < Ncols
       && Screen_image[row][col] != ch) {
      Screen_image[row][col] = ch;
#ifdef ODDVID
      if (Use_bios)
         mvaddchb (row, col, ch);
      else
#endif
         mvaddch (row, col, ch);
   }
}


/* loadstr --- load a string into a field of the screen */

void loadstr (str, row, stcol, endcol, zone)
register const uchar *str;
int row, stcol, endcol;
int zone;
{
   register unsigned int ch;
   register int p, c, limit;

#ifdef DB1
   if (Started == NO) {
      puts ("loadstr");
      getch ();
   }
#endif   /* DB1 */
   if (row >= 0 && row < Nrows && stcol >= 0) {
      for (p = 0, c = stcol; str[p] != EOS && c < Ncols; p++, c++) {

         if (str[p] < ' ')
            ch = (Colours[UPRT_ZONE] << 8) | (Unprintable & 0xff);
         else
            ch = (Colours[zone] << 8) | str[p];
         
         if (Screen_image[row][c] != ch) {
            Screen_image[row][c] = ch;
#ifdef ODDVID
            if (Use_bios)
               mvaddchb (row, c, ch);
            else
#endif
               mvaddch (row, c, ch);
         }
      }

      ch = (Colours[zone] << 8) | ' ';
      
      if (endcol >= Ncols - 1 && c < Ncols - 1)
         clear_to_eol (row, c, zone);
      else {
         limit = (endcol < Ncols - 1) ? endcol : Ncols - 1;
         for (; c <= limit; c++)
            if (Screen_image[row][c] != ch) {
               Screen_image[row][c] = ch;
#ifdef ODDVID
               if (Use_bios)
                  mvaddchb (row, c, ch);
               else
#endif
                  mvaddch (row, c, ch);
            }
      }
   }
}


/* restore_screen --- screen has been garbaged; fix it */

void restore_screen ()
{
   register int row, col;

   clrscreen ();
   for (row = 0; row < Nrows && ! intrpt (); row++)
      for (col = 0; col < Ncols; col++)
#ifdef ODDVID
         if (Use_bios)
            mvaddchb (row, col, Screen_image[row][col]);
         else
#endif
            mvaddch (row, col, Screen_image[row][col]);

   msgstr (SNULL, REMARK_MSG);   /* get rid of 'type control-q....' */
}


/* ringbell --- generate loud beeping noises */

void ringbell (type)
int type;               /* Different noises for different errors */
{
   if (!Quiet)
      putch (BEL);
}


/* clear_to_eol --- clear from current cursor position to end of line */

static void clear_to_eol (row, col, zone)
int row, col;
int zone;
{
   union REGS in;
   register int c;
   bool flag;
   register unsigned int space;

   flag = NO;

   space = (Colours[zone] << 8) | ' ';
   
   for (c = col; c < Ncols; c++)
      if (Screen_image[row][c] != space) {
         Screen_image[row][c] = space;
         flag = YES;
      }

   if (flag) {
      in.h.cl = col;       /* Start col is current cursor col */
      in.h.dl = Ncols - 1; /* End col is RH margin */
      in.h.ah = SCROLL_UP; /* BIOS window scroller */
      in.h.al = 0;         /* Clear instead of scroll */
      in.h.ch = row;       /* Start row is current cursor row */
      in.h.dh = row;       /* End row is same as start */
      in.h.bh = Colours[zone]; /* Fill blanks with current colour */
      int86 (VIDEO_INT, &in, &in);
   }
}


/* position_cursor --- move the cursor to (r, c) */

void position_cursor (r, c)
int r, c;                  /* Row and col to move to */
{
   union REGS in, out;

#ifdef DB1
   if (Started == NO) {
      puts ("position_cursor");
      getch ();
   }
#endif   /* DB1 */
   in.h.ah = SET_POS;      /* Set cursor position */
   in.h.dh = r;
   in.h.dl = c;
   in.h.bh = 0;

   int86 (VIDEO_INT, &in, &out);
}


/* show_cursor --- show or hide the text cursor */

void show_cursor (on)
bool on;
{
   union REGS r;
   
#ifdef DB1
   if (Started == NO) {
      puts ("show_cursor");
      getch ();
   }
#endif   /* DB1 */
   r.h.ah = 0x01;

   if (on) {
      switch (Cur_size) {
      case CUR_NORMAL:
         if (Mono) {
            r.h.ch = 11;
            r.h.cl = 12;
         }
         else {
            r.h.ch = 6;
            r.h.cl = 7;
         }
         break;
      case CUR_INSERT:
         if (Mono) {
            r.h.ch = 6;
            r.h.cl = 12;
         }
         else {
            r.h.ch = 4;
            r.h.cl = 7;
         }
         break;
      }
   }
   else {
      if (Mono) {
         r.h.ch = 15;
         r.h.cl = 15;
      }
      else {
         r.h.ch = 20;
         r.h.cl = 20;
      }
   }
   
   int86 (VIDEO_INT, &r, &r);
   
   Cur_on = on;
}


/* shape_cursor --- set cursor size or style */

void shape_cursor (size)
int size;
{
#ifdef DB1
   if (Started == NO) {
      puts ("shape_cursor");
      getch ();
   }
#endif   /* DB1 */
   Cur_size = size;

   if (Cur_on)
      show_cursor (YES);
}


/* clrscreen --- clear the physical screen */

void clrscreen ()
{
   union REGS r;

#ifdef DB1
   if (Started == NO) {
      puts ("clrscreen");
      getch ();
   }
#endif   /* DB1 */
   r.h.ah = SCROLL_UP;     /* Scroll Window             */
   r.h.al = 0;             /* No of lines (0 => clear)  */
   r.h.ch = 0;             /* Start row                 */
   r.h.cl = 0;             /* Start col                 */            
   r.h.dh = Nrows - 1;     /* End row                   */
   r.h.dl = (unsigned char) (Ncols - 1);  /* End col    */
   r.h.bh = WHITE;         /* Attribute fill spaces     */

   int86 (VIDEO_INT, &r, &r);

   position_cursor (0, 0);
}


/* inslines --- insert 'n' lines on the screen at 'row' */

void inslines (row, n)
int row, n;
{
   register int i;
   union REGS in;

   in.h.ah = SCROLL_DOWN;  /* BIOS window scroller */
   in.h.al = n;            /* Scroll 'n' lines */
   in.h.cl = 0;            /* Start col LH margin */
   in.h.ch = row;          /* Start row is current cursor row */
   in.h.dl = (unsigned char) (Ncols - 1); /* End col is RH margin */
   in.h.dh = Nrows - 1;    /* End row bottom of screen */
   in.h.bh = Colours[TEXT_ZONE]; /* Fill blanks with temp. colour */
   int86 (VIDEO_INT, &in, &in);

   for (i = Nrows - 1; i - n >= row; i--)
      memcpy (Screen_image[i], Screen_image[i - n], Ncols * sizeof (unsigned));

   for (; i >= row; i--)     
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
}


/* dellines --- delete 'n' lines beginning at 'row' */

void dellines (row, n)
int row, n;
{
   register int i;
   union REGS in;

   in.h.ah = SCROLL_UP; /* BIOS window scroller */
   in.h.al = n;         /* Scroll 'n' lines */
   in.h.cl = 0;         /* Start col LH margin */
   in.h.ch = row;       /* Start row is current cursor row */
   in.h.dl = (unsigned char) (Ncols - 1); /* End col is RH margin */
   in.h.dh = Nrows - 1; /* End row bottom of screen */
   in.h.bh = Colours[TEXT_ZONE]; /* Fill blanks with current colour */
   int86 (VIDEO_INT, &in, &in);

   for (i = row; i + n < Nrows; i++)
      memcpy (Screen_image[i], Screen_image[i + n], Ncols * sizeof (unsigned));

   for (; i < Nrows; i++)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
}


/* set_term --- initialise terminal parameters and actual capabilities */

int set_term (type, hwinsdel, pr, pc)
const uchar *type;
bool *hwinsdel;
int *pr, *pc;
{
   union REGS r;
   int rows, cols;
   
   /* Detect mouse driver */
   Mouset = minit ();
   
   /* Determine keyboard BIOS version */
   r.h.ah = 0x12;
   r.h.al = 0xff;
   int86 (KEYB_INT, &r, &r);
   
   if (r.h.al == 0xff)
      New_bios = NO;       /* Standard keyboard */
   else
      New_bios = YES;      /* Enhanced keyboard */
   
   /* Detect EGA */
   r.h.ah = 0x12;     /* Test for EGA BIOS */
   r.h.bl = 0x10;
   r.h.bh = 0xff;     /* Illegal initial values */
   r.h.cl = 0x0f;
   
   int86 (VIDEO_INT, &r, &r);
   
   if (r.h.cl > 0x0b || r.h.bh > 1 || r.h.bl > 3)
      Has_ega = NO;
   else
      Has_ega = YES;

#ifdef DB
   printf ("Has_ega = %s\n", Has_ega ? "YES": "NO");
   getch ();
#endif   /* DB */
   
   /* Sort out video modes */
   r.h.ah = GET_MODE;
   int86 (VIDEO_INT, &r, &r);
   
   Mono = NO;

   if (r.h.al == 7) {
      setvseg (0xb000);       /* Mono adapter */
      Mono = YES;
      rows = MONO_NROWS;
      cols = MONO_NCOLS;

#ifdef ODDVID
      if (type != NULL) {
         if (struncmp (type, "AXTEL", 5) == 0)
            rows = atoi (&type[5]);
         else if (strucmp (type, "HP95") == 0) {
            rows = HP95_NROWS;
            cols = HP95_NCOLS;
         }
      }
#endif   /* ODDVID */
   }
   else if (r.h.al == 3 || r.h.al == 2) {
      setvseg (0xb800);       /* Colour adapter or EGA */

      if (Has_ega) {
         r.h.ah = 0x11;    /* See if EGA is in 43 line mode */
         r.h.al = 0x30;
         r.x.bx = r.x.cx = r.x.dx = 0;
         int86 (0x10, &r, &r);
         rows = r.h.dl + 1;  /* Handles EGA 43 lines or */
         cols = EGA_NCOLS;   /* VGA 50 lines            */
      }
      else {
         rows = CGA_NROWS;
         cols = CGA_NCOLS;
      }
   }
#ifdef ODDVID
   else if (r.h.al == 33) {         /* Tseng VGA 132x60 */
      setvseg (0xb800);       /* Normal VGA address */
      rows = 60;
      cols = 132;
   }
   else if (r.h.al == 34) {         /* Tseng VGA 132x44 */
      setvseg (0xb800);       /* Normal VGA address */
      rows = 44;
      cols = 132;
   }
   else if (r.h.al == 35) {         /* Tseng VGA 132x25 */
      setvseg (0xb800);       /* Normal VGA address */
      rows = 25;
      cols = 132;
   }
   else if (r.h.al == 36) {         /* Tseng VGA 132x28 */
      setvseg (0xb800);       /* Normal VGA address */
      rows = 28;
      cols = 132;
   }
   else if (r.h.al == 38) {         /* VGA clones at King's */
      setvseg (0xb800);       /* Normal VGA address */
      rows = 60;
      cols = 80;
   }
   else if (r.h.al == 81) {         /* Opus 132 col. EGA */
      setvseg (0xb800);       /* Normal EGA address */
      rows = 30;
      cols = 80;
   }
   else if (r.h.al == 84) {         /* Opus / Paradise 132 col. EGA */
      setvseg (0xb800);       /* Normal EGA address */
      rows = 43;
      cols = 132;
   }
   else if (r.h.al == 85) {         /* Opus / Paradise 132 col. EGA */
      setvseg (0xb800);       /* Normal EGA address */
      rows = 25;
      cols = 132;
   }
   else if (r.h.al == 86) {         /* Paradise 132 col. VGA */
      setvseg (0xb000);       /* MDA address */
      rows = 43;
      cols = 132;
   }
   else if (r.h.al == 87) {         /* Paradise 132 col. VGA */
      setvseg (0xb000);       /* MDA address */
      rows = 25;
      cols = 132;
   }
   else if (r.h.al == 88) {         /* Opus 132 col. EGA */
      setvseg (0xb800);       /* Normal EGA address */
      rows = 43;
      cols = 80;
   }
   else if (r.h.al == 90) {         /* Opus 132 col. EGA */
      setvseg (0xb800);       /* Normal EGA address */
      rows = 60;
      cols = 80;
   }
   else if (r.h.al >= 192 && r.h.al <= 195) { /* Wyse WY-700 */
      Use_bios = YES;      /* Memory layout not documented by Wyse */

      switch (r.h.al) {
      case 192:  
         rows = 25;
         cols = 80;
         break;
      case 193:  
         rows = 50;
         cols = 80;
         break;
      case 194:  
         rows = 25;
         cols = 160;
         break;
      case 195:  
         rows = 50;
         cols = 160;
         break;
      }
   }
#endif   /* ODDVID */
   else {            /* CGA or EGA in graphics mode */
      Old_mode = r.h.al;
      setvseg (0xb800);
      r.h.ah = SET_MODE;
      r.h.al = 3;       /* Force text mode */
      int86 (VIDEO_INT, &r, &r);
      rows = CGA_NROWS;
      cols = CGA_NCOLS; 
   }
   
#ifdef ODDVID
   if ((type != NULL) && (strucmp (type, "BIOS") == 0))
      Use_bios = YES;
#endif   /* ODDVID */

#ifdef DB1
   Started = YES;
#endif   /* DB1 */

   if ((type != NULL) && (strucmp (type, "HP95") == 0))
      setncols (MONO_NCOLS);  /* Memory stride on HP95 is still 80 */
   else
      setncols (cols);  /* Set up width of video RAM */
   
   *hwinsdel = YES;
   *pr = rows;
   *pc = cols;
   
   return (OK);
}


/* term_name --- return the name of the terminal */

uchar *term_name ()
{
#ifdef DB1
   if (Started == NO) {
      puts ("term_name");
      getch ();
   }
#endif   /* DB1 */
   return ("IBM-PC");
}


/* readkey --- read keystrokes and map into 'se' tokens */

int readkey (raw)
bool raw;
{
   int k;
   int mx, my;
   
   if (Mouset) {
      mmove (MCURX, MCURY);         /* Centre the mouse */
/*    mbutton (1, YES, &mx, &my); *//* Flush button counters */
/*    mbutton (2, YES, &mx, &my); */
      mread (&mx, &my);       /* Find out where the mouse is... */
/*    mbutton (3, YES, &mx, &my); */
   }

   /* Busy-wait for a keystroke so we can simulate a CAPS-LOCK light */
   for (;;) {
      capslite ();
      
      if (Mouset) {
         if (mbutton (0, YES, &mx, &my) > 0) {
            k = LMB;
            break;
         }

         if (mbutton (1, YES, &mx, &my) > 0) {
            k = RMB;
            break;
         }

#if 1
         if (mbutton (2, YES, &mx, &my) > 0) {
            k = MMB;
            break;
         }
#endif
      }

      if (chkinp (New_bios)) {   /* Now see if there's a key pressed */
         k = got_keystroke (raw);
         break;
      }
   }
   
   return (k);
}


/* got_keystroke --- read a keyboard event */

static int got_keystroke (raw)
bool raw;
{
   static keycode ktab[] = {
/*00*/NOKEY,   NOKEY,   NOKEY,   C_2,     NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*08*/NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*10*/A_Q,     A_W,     A_E,     A_R,     A_T,     A_Y,     A_U,     A_I,
/*18*/A_O,     A_P,     NOKEY,   NOKEY,   NOKEY,   NOKEY,   A_A,     A_S,
/*20*/A_D,     A_F,     A_G,     A_H,     A_J,     A_K,     A_L,     NOKEY,
/*28*/NOKEY,   C_BQT,   NOKEY,   NOKEY,   A_Z,     A_X,     A_C,     A_V,
/*30*/A_B,     A_N,     A_M,     NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*38*/NOKEY,   C_SPACE, NOKEY,   F1,      F2,      F3,      F4,      F5,
/*40*/F6,      F7,      F8,      F9,      F10,     NOKEY,   NOKEY,   CHOME,
/*48*/CUP,     PUP,     NOKEY,   CLEFT,   NOKEY,   CRIGHT,  NOKEY,   CEND,
/*50*/CDOWN,   PDOWN,   CINSERT, ERASE,   S_F1,    S_F2,    S_F3,    S_F4,
/*58*/S_F5,    S_F6,    S_F7,    S_F8,    S_F9,    S_F10,   C_F1,    C_F2,
/*60*/C_F3,    C_F4,    C_F5,    C_F6,    C_F7,    C_F8,    C_F9,    C_F10,
/*68*/A_F1,    A_F2,    A_F3,    A_F4,    A_F5,    A_F6,    A_F7,    A_F8,
/*70*/A_F9,    A_F10,   NOKEY,   C_CLEFT, C_CRIGHT,C_CEND,  C_PDOWN, C_CHOME,
/*78*/A_1,     A_2,     A_3,     A_4,     A_5,     A_6,     A_7,     A_8,
/*80*/A_9,     A_0,     A_DASH,  A_EQ,    C_PUP,   F11,     F12,     S_F11,
/*88*/S_F12,   C_F11,   C_F12,   A_F11,   A_F12,   C_CUP,   NOKEY,   NOKEY,
/*90*/NOKEY,   C_CDOWN, C_CINSERT,C_ERASE,NOKEY,   NOKEY,   NOKEY,   A_CHOME,
/*98*/A_CUP,   A_PUP,   NOKEY,   A_CLEFT, NOKEY,   A_CRIGHT,NOKEY,   A_CEND,
/*a0*/A_CDOWN, A_PDOWN, A_CINSERT,A_ERASE,NOKEY,   NOKEY,   A_ENTER, NOKEY
   };
   scancode scode;
   int ascii;
   
   scode = getscan ();
   ascii = scode & 0xff;
   
   if (raw)
      return (ascii);
   else if (!(ascii == 0x00 || ascii == 0xe0)) {
      if (ascii < ' ')
         return (-ascii);
      else if (ascii == DEL)
         return (CDELETE);
      else
         return (ascii);
   }
   else {
      scode >>= 8;
      
      if (scode < (sizeof (ktab) / sizeof (ktab[0])))
         return (ktab[scode]);
      else
         return (NOKEY);   /* Unknown scan code */
   }
}


/* capslite --- display a 'caps lock' indicator */

static void capslite ()
{
   union REGS r;
   static bool lock = NO;
   bool stat;
   
   r.h.ah = New_bios ? 0x12: 0x02;

   int86 (KEYB_INT, &r, &r);
   
   stat = (r.h.al & 0x40) != 0;

   if (stat != lock) {
      msgstr (stat ? SCAPS : SNULL, CAPS_MSG);
      lock = stat;
   }
}


/* getscan --- read one character from the 'terminal' */

static scancode getscan ()
{
   union REGS r;
   
   /* Use BIOS to read keyboard to disable ^C */
   r.h.ah = New_bios? 0x10: 0x00;
   int86 (KEYB_INT, &r, &r);

   return (r.x.ax);
}


/* flashmode --- turn VDU flashing on or off */

static void flashmode (flag)
bool flag;
{
   union REGS r;
   unsigned int crtc;
   unsigned int *addr_6845;
   unsigned char *crt_mode_set;
   
   if (Has_ega) {
      r.h.ah = 0x10;
      r.h.al = 0x03;
      r.h.bl = flag ? 0x01 : 0x00;
      int86 (VIDEO_INT, &r, &r);
   }
   else {
#if MSC
      FP_SEG(addr_6845) = 0x40;     /* addr_6845 -> 0040:0063 */
      FP_OFF(addr_6845) = 0x63;
      
      FP_SEG(crt_mode_set) = 0x40;  /* crt_mode_set -> 0040:0065 */
      FP_OFF(crt_mode_set) = 0x65;  
#endif   /* MSC */
#if TCC
      addr_6845    = MK_FP(0x40, 0x63);
      crt_mode_set = MK_FP(0x40, 0x65);
#endif   /* TCC */
      
      crtc = *addr_6845;            /* Read CRTC port address */

#ifdef DB
      printf ("crtc = %04x\n", crtc);
#endif   /* DB */

      if (flag)                     /* Set or clear the bit */
         *crt_mode_set |= 0x20;
      else
         *crt_mode_set &= ~0x20;
         
#ifdef DB
      printf ("crt_mode_set = %02x\n", *crt_mode_set);
      getch ();
#endif   /* DB */
         
      outp (crtc + 0x04, *crt_mode_set);  /* Send it to the port */
   }
}


/* minit --- detect mouse and disable light pen emulation */

static bool minit ()
{
   union REGS in, out;
   struct SREGS segs;
   unsigned char *vec;

   in.h.ah = 0x35;
   in.h.al = MOUSE_INT;

   intdos (&in, &out);
   segread (&segs);

#ifdef DB
   printf ("minit: BX = %d, ES = %d\n", out.x.bx, segs.es);
#endif

   if (out.x.bx == 0 && segs.es == 0)
      return (NO);           /* Software not installed */

#if MSC
   FP_SEG(vec) = segs.es;
   FP_OFF(vec) = out.x.bx;
#endif
#if TCC
   vec = MK_FP(segs.es, out.x.bx);
#endif

   if (*vec == IRET)          /* Vector points to IRET */
      return (NO);            /* MS-DOS 3.1 & PC-DOS 3.2 fix */

   in.x.ax = MINIT;           /* Function code for initialisation */

   int86 (MOUSE_INT, &in, &out);    /* Make an INT 33H call */

   if (out.x.ax != 0xffff)
      return (NO);
      
   in.x.ax = MLPENOFF;

   int86 (MOUSE_INT, &in, &in);     /* Make an INT 33H call */

   return (YES);
}


/* mread --- read mouse position */

static int mread (xpos, ypos)
int *xpos, *ypos;       /* Returned co-ords */
{
   union REGS in, out;

   in.x.ax = MGETPOS;

   int86 (MOUSE_INT, &in, &out);    /* Make an INT 33H call */

   if (xpos != NULL)          /* Store X co-ord */
      *xpos = out.x.cx;

   if (ypos != NULL)          /* Store Y co-ord */
      *ypos = out.x.dx;

   return out.x.bx;           /* Return button status */
}


/* mmove --- set the mouse position */

static void mmove (xpos, ypos)
int xpos, ypos;         /* Co-ords to move to */
{
   union REGS in;

   in.x.ax = MSETPOS;
   in.x.cx = xpos;
   in.x.dx = ypos;

   int86 (MOUSE_INT, &in, &in);     /* Make an INT 33H call */
}


/* mbutton --- get button press/release counts */

static int mbutton (button, flag, xpos, ypos)
int button;             /* Button number */
bool flag;              /* YES == press, NO == release */
int *xpos, *ypos;       /* Returned co-ords at last press/release */
{
   union REGS in, out;

   in.x.ax = flag ? MGETPRESS : MGETREL;
   in.x.bx = button;
   in.x.cx = 0;
   in.x.dx = 0;
   in.x.si = 0;
   in.x.di = 0;

   int86 (MOUSE_INT, &in, &out);    /* Make an INT 33H call */

   if (xpos != NULL)          /* Store X co-ord */
      *xpos = out.x.cx;

   if (ypos != NULL)          /* Store Y co-ord */
      *ypos = out.x.dx;

#ifdef DB
   if (out.x.bx != 0)
      printf ("bx = %d, button = %d (%d, %d), bits = %d\n",
            out.x.bx, in.x.bx, out.x.cx, out.x.dx, mread (NULL, NULL));
#endif   /* DB */

   return out.x.bx;           /* Return button count */
}


#if 0
/* mapkey --- read keystrokes and map for cursor keys and mouse */

unsigned int mapkey ()
{
   int mx, my;

         {
            Use_mouse = ! Use_mouse;            /* Right button */
            msgstr (Use_mouse ? SMOUSE : SNULL, MOUSE_MSG);
         }  

         if (Use_mouse) {
            if (mbutton (2, YES, &mx, &my) > 0)
               return (CTRL_V);                    /* Left button */ 

            mread (&mx, &my);       /* Find out where the mouse is... */

            if (mx > RTHRESH)       /* ...and see if it's moved */
               return (CTRL_G);

            if (mx < LTHRESH)
               return (CTRL_H);

            if (my > DTHRESH)
               return (CTRL_K);

            if (my < UTHRESH)
               return (CTRL_D);
         }
      }
   }
}
#endif
