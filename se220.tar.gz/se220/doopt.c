/* doopt --- option parsing/executing module                18/06/1987 */

#include "se.h"
#include "extern.h"

#include "cmds.h"       /* Option letters */


#if NO_PROTOTYPES
static int settab ();
static int dofopt ();
static int docolour ();
#else
static int settab (const uchar *);
static int dofopt (const uchar *);
static int docolour (const uchar *, int *);
#endif


/* doopt_init --- initialise this module */

void doopt_init ()
{
   reset_opts ();
}


/* reset_opts --- set all options to their default values */

void reset_opts ()
{
   Insert_mode = NO;    /* Turn off insert mode                    */
   msgstr (SNULL, INS_MSG);
   shape_cursor (CUR_NORMAL);

   Invert_case = NO;    /* Turn off case mapping                   */
   msgstr (SNULL, CASE_MSG);
   
   Compress = NO;       /* Turn off TAB expansion/compression      */
   msgstr (SNULL, COMPRESS_MSG);

   View = NO;           /* Turn off 'Read-only' mode               */
   msgstr (SNULL, VIEW_MSG);

   Crypting = NO;       /* Turn off file encryption                */
   msgstr (SNULL, CRYPT_MSG);

   Absnos = NO;         /* Use relative numbers in margin          */
   Rel_a = 'A';         /* Relative line numbers A-Z               */
   Rel_z = 'Z';
   Ddir = FORWARD;      /* Delete forward                          */
   Nchoise = EOS;       /* Choice of line number for cont. display */
   Patchoise = NO;      /* Don't display saved pattern             */
   Overlay_col = 0;     /* Initial cursor column for 'v' command   */
   Warncol = 0;         /* Where to turn on column warning         */
   Firstcol = 0;        /* Leftmost column to display              */         
   Indent = 1;          /* Indent col; 0=same as previous line     */
   Notify = YES;        /* Notify user if he has mail in mail file */
   Globals = NO;        /* Substitutes in a global don't fail      */
   No_hardware = NO;    /* Use hardware insert/delete              */
   Subsys = NO;         /* Not working in 'Subsystem' mode         */
   Quiet = NO;          /* NOISY mode!                             */
/* Use_script = NO;      * Flag for reading from a script          */
/* Scriptfp = NULL;      * Stream for script file                  */
   Src_mode = NO;       /* Source-code mode                        */
   Ot[0] = EOS;         /* Open tag                                */
   Ct[0] = EOS;         /* Close tag                               */
   Q1 = '"';            /* Two types of quote                      */
   Q2 = '\'';
   Oc1[0] = EOS;        /* Open comment 1                          */
   Cc1[0] = EOS;        /* Close comment 1                         */
   Oc2[0] = EOS;        /* Open comment 2                          */
   Cc2[0] = EOS;        /* Close comment 2                         */
   Op[0] = EOS;         /* Open pre-processor directive            */
   Cp[0] = EOS;         /* Close pre-processor directive           */
   Unprintable = ' ';   /* Char to print for unprintable chars     */            
   Casematch = YES;     /* Case sensitive matching                 */
   Show_ok = NO;        /* Don't display 'changed' message         */
   
   strucpy (Tabstr, "+4");
   settab (Tabstr);
}


/* doopt --- interpret option command */

int doopt (lin, i)
uchar lin[];   /* 'splitscreen ()' can write into 'lin' */
int i;
{
   int temp;
   uchar tempstr[MAXLINE];
   uchar *savfil;
   char opt;
   register uchar ch;
   int ret;
   register int j;
   static string fwd = ">";
   static string bwd = "<";
   static string dollar = "$";

   ret = ERR;
   if (Nlines != 0) {
      Errcode = EBADLNR;
      return (ret);
   }
   
   opt = lin[i];
   if (isupper(opt))
      opt = tolower(opt);

   i++;
   ch = lin[i];
   
   switch (opt) {
   case KEYWDOPT:
      while (lin[i] != NEWLINE) {
         SKIPBL(lin, i);
         for (j = 0; lin[i] != ' ' && lin[i] != TAB && lin[i] != NEWLINE;)
            tempstr[j++] = lin[i++];
            
         if (j > 0) {
            tempstr[j] = EOS;
            ret = installkw (tempstr);
         }
      }

      First_affected = Topln;
      break;
      
   case CMNTOPT:     /* Toggle source-code mode */
      if (ch == NEWLINE) {
         Src_mode = !Src_mode;
         
         if (Src_mode)
            fixcomments (1, YES);

         First_affected = Topln;
         ret = OK;
      }
      break;

   case BINDOPT:
      if (ch != NEWLINE)
         ret = dobind (&lin[i]);

      break;
         
   case SWAPOPT:     /* Toggle or set use of script */
      if (ch == NEWLINE) {
         if (Scriptfp != NULL)
            Use_script = ! Use_script;

         ret = OK;
      }
      else {
         if (Scriptfp != NULL) { /* Close any existing script file */
            fclose (Scriptfp);
            Use_script = NO;
         }
            
         if (getfn (lin, i, tempstr) == ERR)
            ret = ERR;
         else if ((Scriptfp = fopen ((char *)tempstr, READ)) == NULL) {
            Errcode = ECANTREAD;
            ret = ERR;
          }
          else {
            Use_script = YES;
            ret = OK;
          }
      }
      break;

   case INSERTOPT:      /* Toggle insert mode (like CTRL-A) */
      if (ch == NEWLINE) {
         ret = toggle (&Insert_mode, SINSERT, SNULL, INS_MSG);
         shape_cursor (Insert_mode ? CUR_INSERT: CUR_NORMAL);
      }
      break;

   case QUIETOPT:       /* Toggle quiet mode */
      if (ch == NEWLINE)
         ret = toggle (&Quiet, SNOBELL, SBELL, REMARK_MSG);

      break;

   case VIEWOPT:        /* Toggle read-only mode */
      if (ch == NEWLINE)
         ret = toggle (&View, SVIEW, SNULL, VIEW_MSG);
      else if (ch == 'f' || ch == 'F') {  /* Toggle the file as well */
         if ((savfil = get_filename ()) != NULL) {
            toggle (&View, SVIEW, SNULL, VIEW_MSG);

            if (setreadonly (savfil, View))
               ret = OK;
            else
               Errcode = ECANTCHMOD;
         }
         else     /* No saved filename */
            Errcode = ENOFN;
      }
      break;

   case COLOUROPT:      /* Set screen colours */
      ret = docolour (lin, &i);
      break;

   case PROMPTOPT:      /* Set or change one of the prompts */
      if (isupper(ch))
         ch = tolower(ch);

      i++;
      SKIPBL(lin, i);
      
      if ((ret = setprompt (ch, &lin[i])) == ERR)
         Errcode = EOWHAT;

      break;

   case GLOBOPT:        /* Substitutes in a global can(not) fail */
      if (ch == NEWLINE)
         ret = toggle (&Globals, SGSUBCONT, SGSUBSTOP, REMARK_MSG);

      break;

   case INSDELOPT:      /* Do/don't use hardware insert/delete */
      if (ch == NEWLINE)
         ret = toggle (&No_hardware, SNOINSDEL, SINSDEL, REMARK_MSG);

      break;

   case SAVEDOPT:       /* Tell user if buffer saved or not */
      if (ch == NEWLINE) {
         msgstr (Buffer_changed ? SNOSAVED : SSAVED, REMARK_MSG);
         ret = OK;
      }
      else if (ch == 'i' || ch == 'I') {
         Show_ok = ! Show_ok;
         ret = OK;
      }
      break;

   case PATMATCHOPT:    /* Toggle case-sensitive pattern matching */
      if (ch == NEWLINE)
         ret = toggle (&Casematch, SPATCASE, SNOPATCASE, REMARK_MSG);

      break;

   case TABSOPT:        /* Set or display tab stops */
      if (ch == NEWLINE) {
         mesg (Tabstr, REMARK_MSG);
         ret = OK;
      }
      else {
         ret = settab (&lin[i]);
         if (ret == OK) {
            strucpy (Tabstr, &lin[i]);
            zapnl (Tabstr);
         }
         else    /* Defaults were set */
            strucpy (Tabstr, "+4");
      }
      break;

   case WARNOPT:     /* Set or display warning column */
      if (ch == NEWLINE) {
         if (Warncol == 0)
            mesg (dollar, REMARK_MSG);
         else
            saynum (Warncol);
         ret = OK;
      }
      else {
         if (ch == '$' && lin[i + 1] == NEWLINE) {
            Warncol = 0;
            ret = OK;
         }
         else {
            temp = ctoi (lin, &i);
            if (lin[i] == NEWLINE) {
               if (temp > 0 && temp < MAXLINE - 3) {
                  ret = OK;
                  Warncol = temp;
               }
               else
                  Errcode = ENONSENSE;
            }
         }
      }
      break;

   case PATOPT:      /* Toggle saved pattern display */
      if (ch == NEWLINE) {
         Patchoise = ! Patchoise;
         showpat ();
         ret = OK;
      }
      break;
      
   case WINDOWOPT:   /* Fix window in place on screen, or erase it */
      ret = splitscreen (lin, &i);
      break;

   case NUMBEROPT:   /* Toggle absolute line numbering */
      if (ch == NEWLINE) {
         Absnos = ! Absnos;
         ret = OK;
      }
      break;

   case CASEOPT:     /* Toggle case-map option */
      if (ch == NEWLINE) {
         ret = toggle (&Invert_case, SCASE, SNULL, CASE_MSG);

         if (Rel_a == 'A') {
            Rel_a = 'a';
            Rel_z = 'z';
         }
         else {
            Rel_a = 'A';
            Rel_z = 'Z';
         }
      }

      break;

   case DELDIROPT:   /* Set or display placement of "." after delete */
      if (ch == NEWLINE) {
         mesg ((Ddir == FORWARD) ? fwd : bwd, REMARK_MSG);
         ret = OK;
      }
      else if (lin[i + 1] != NEWLINE)
         Errcode = EODLSSGTR;
      else if (ch == '>') {
         ret = OK;
         Ddir = FORWARD;
      }
      else if (ch == '<') {
         ret = OK;
         Ddir = BACKWARD;
      }
      else
         Errcode = EODLSSGTR;
      break;

   case OVERLOPT:    /* Set or display overlay column */
      if (ch == NEWLINE) {
         if (Overlay_col == 0)
            mesg (dollar, REMARK_MSG);
         else
            saynum (Overlay_col);
         ret = OK;
      }
      else {
         if (ch == '$' && lin[i + 1] == NEWLINE) {
            Overlay_col = 0;
            ret = OK;
         }
         else {
            temp = ctoi (lin, &i);
            if (lin[i] == NEWLINE) {
               Overlay_col = temp;
               ret = OK;
            }
            else
               Errcode = ENONSENSE;
         }
      }
      break;

   case UPRNTOPT:    /* Set or display character for unprintable chars */
      if (ch == NEWLINE) {
         ret = OK;
         tempstr[0] = tempstr[2] = '"';
         tempstr[1] = Unprintable;
         tempstr[3] = EOS;
         mesg (tempstr, REMARK_MSG);
      }
      else if (lin[i + 1] == NEWLINE) {
#if MSDOS | MSWIN32
         if (ch < ' ')
#else
         if (ch < ' ' || ch >= DEL)
#endif
            Errcode = ENONSENSE;
         else {
            ret = OK;
            if (Unprintable != ch) {
               Unprintable = ch;
               First_affected = Topln;
            }
         }
      }
      break;

   case LINEOPT:     /* Set or display line number display option */
      if (ch == NEWLINE) {
         Nchoise = EOS;
         ret = OK;
      }
      else if (lin[i + 1] == NEWLINE &&
           (ch == CURLINE ||
            ch == LASTLINE ||
            ch == TOPLINE ||
            ch == PERCENT)) {             
         Nchoise = ch;
         ret = OK;
      }
      else if (ch == 'm' || ch == 'M') {
         /* set or display the left margin */
         if (lin[i + 1] == NEWLINE) {
            saynum (Firstcol + 1);
            ret = OK;
         }
         else {
            i++;
            temp = ctoi (lin, &i);
            if (lin[i] == NEWLINE) {
               if (temp > 0 && temp < MAXLINE) {
                  First_affected = Topln;
                  Firstcol = temp - 1;
                  ret = OK;
               }
               else
                  Errcode = ENONSENSE;
            }
         }
      }
      break;

   case FILEOPT:     /* Set file type options */
      ret = dofopt (&lin[i]);
      break;

   case SRCOPT:      /* Set source options */
      for (j = 0; lin[i] != NEWLINE; i++, j++)
         tempstr[j] = lin[i];
         
      tempstr[j] = EOS;
      ret = dosopt (tempstr);
      break;

   case INDENTOPT:   /* Set or display indent option */
      if (ch == NEWLINE)
         ret = OK;
      else if ((ch == 'a' || ch == 'A') && lin[i + 1] == NEWLINE) {
         Indent = 0;
         ret = OK;
      }
      else {
         temp = ctoi (lin, &i);
         if (lin[i] == NEWLINE) {
            if (temp > 0 && temp < MAXLINE - 3) {
               ret = OK;
               Indent = temp;
            }
            else
               Errcode = ENONSENSE;
         }
      }

      if (ret == OK) {
         if (Indent > 0)
            saynum (Indent);
         else
            msgstr (SAUTO, REMARK_MSG);
      }

      break;

   case MESGOPT:     /* Toggle mail notification */
      if (ch == NEWLINE) 
         ret = toggle (&Notify, SMAIL, SNOMAIL, REMARK_MSG);

      break;

   case XTABSOPT:    /* Toggle tab compression */
      if (ch == NEWLINE)
         ret = toggle (&Compress, SXTABS, SNULL, COMPRESS_MSG);

      break;

#if UNIX
   case CRYPTOPT:    /* Encrypt files */
      if (ch == NEWLINE) {
      crypt_toggle:
         ret = OK;
         Crypting = ! Crypting;
         if (Crypting)
            do {
               getcryptkey ();
               if (Key[0] == EOS)
                  msgstr (SNULKEY, REMARK_MSG);

            } while (Key[0] == EOS);
         else
            Key[0] = EOS;
      }
      else {
         ret = OK;
         i++;     /* *i was the 'y' */
         while (isspace (lin[i]) && lin[i] != NEWLINE)
            i++;
         if (lin[i] != NEWLINE && lin[i] != EOS) {
            for (j = 0; lin[i] != NEWLINE && lin[i] != EOS; j++, i++)
               Key[j] = lin[i];    

            Key[j] = EOS;
            Crypting = YES;
         }
         else
            goto crypt_toggle;   /* Who put this in here ? */
      }

      msgstr (Crypting ? SCRYPT : SNULL, CRYPT_MSG);
      break;
#endif   /* UNIX */

   case TSTPOPT:     /* Suspend the editor process */
      if (ch == NEWLINE)
         ret = dosuspend ();

      break;

   default:
      Errcode = EOWHAT;
      break;
   }

   return (ret);
}


/* dofopt --- parse and store options for a file type */

static int dofopt (lin)
register const uchar *lin;
{
   uchar delim;
   uchar legal[MAXLINE];
   register int j;
   int i = 0;
   
   delim = lin[i++];

   /* Start code symbol */
   for (j = 0; lin[i] != delim && lin[i] != NEWLINE; i++)
      Ot[j++] = esc (lin, &i);

   Ot[j] = EOS;
   
   if (lin[i] == NEWLINE)
      return (ERR);
   else
      i++;

   /* End code symbol */
   for (j = 0; lin[i] != delim && lin[i] != NEWLINE; i++)
      Ct[j++] = esc (lin, &i);

   Ct[j] = EOS;
   
   if (lin[i] == NEWLINE)
      return (ERR);
   else
      i++;
      
   /* First quote */
   Q1 = esc (lin, &i);
   i++;

   if (lin[i] != delim)
      return (ERR);
   else
      i++;

   /* Second quote */
   Q2 = esc (lin, &i);
   i++;

   if (lin[i] != delim)
      return (ERR);
   else
      i++;

   /* Open comment 1 symbol */
   for (j = 0; lin[i] != delim && lin[i] != NEWLINE; i++)
      Oc1[j++] = esc (lin, &i);

   Oc1[j] = EOS;
   
   if (lin[i] == NEWLINE)
      return (ERR);
   else
      i++;

   /* Close comment 1 symbol */
   for (j = 0; lin[i] != delim && lin[i] != NEWLINE; i++)
      Cc1[j++] = esc (lin, &i);

   Cc1[j] = EOS;
   
   if (lin[i] == NEWLINE)
      return (ERR);
   else
      i++;

   /* Open comment 2 symbol */
   for (j = 0; lin[i] != delim && lin[i] != NEWLINE; i++)
      Oc2[j++] = esc (lin, &i);

   Oc2[j] = EOS;
   
   if (lin[i] == NEWLINE)
      return (ERR);
   else
      i++;

   /* Close comment 2 symbol */
   for (j = 0; lin[i] != delim && lin[i] != NEWLINE; i++)
      Cc2[j++] = esc (lin, &i);

   Cc2[j] = EOS;
   
   if (lin[i] == NEWLINE)
      return (ERR);
   else
      i++;

   /* Open pre-processor symbol */
   for (j = 0; lin[i] != delim && lin[i] != NEWLINE; i++)
      Op[j++] = esc (lin, &i);

   Op[j] = EOS;
   
   if (lin[i] == NEWLINE)
      return (ERR);
   else
      i++;

   /* Close pre-processor symbol */
   for (j = 0; lin[i] != delim && lin[i] != NEWLINE; i++)
      Cp[j++] = esc (lin, &i);

   Cp[j] = EOS;
   
   if (lin[i] == NEWLINE)
      return (ERR);
   else
      i++;
      
   /* Legal chars set */
   for (j = 0; lin[i] != delim && lin[i] != NEWLINE; i++)
      legal[j++] = esc (lin, &i);

   legal[j] = EOS;
   
   if (lin[i] == NEWLINE)
      return (ERR);
   else
      i++;
      
   setlegal (legal);
   
   First_affected = Topln;
   return (OK);
}


/* settab --- set tab stops */

static int settab (str)
register const uchar *str;
{
   int i, j, n, maxstop, last, ret;
   bool inc;

   for (i = 0; i < MAXLINE; i++)   /* clear all tab stops */
      Tabstops[i] = NO;

   ret = OK;
   maxstop = 0;
   last = 1;

   i = 0;
   SKIPBL (str, i);
   while (str[i] != EOS && str[i] != NEWLINE) {
      if (str[i] == '+') {    /* increment */
         i++;
         inc = YES;
      }
      else
         inc = NO;

      n = ctoi (str, &i);

      if (n <= 0 || n >= MAXLINE) {
         ret = ERR;
         Errcode = ENONSENSE;
         break;
      }

      if (str[i] != ' ' && str[i] != '+' &&
          str[i] != NEWLINE && str[i] != EOS) {
         ret = ERR;
         Errcode = EBADTABS;
         break;
      }

      if (inc) {
         for (j = last + n; j < MAXLINE; j += n) {
            Tabstops[j - 1] = YES;
            maxstop = max (j, maxstop);
         }
      }
      else {
         Tabstops[n - 1] = YES;
         last = n;
         maxstop = max (n, maxstop);
      }
      SKIPBL (str, i);
   }       /* while ... */

   if (ret == ERR)
      maxstop = 0;

   if (maxstop == 0) {     /* no tab stops specified, use defaults */
      for (i = 4; i < MAXLINE - 1; i += 4)
         Tabstops[i] = YES;

      maxstop = i - 4 + 1;
   }

   Tabstops[0] = YES;      /* always set to YES */

   for (i = maxstop; i < MAXLINE; i++)
      Tabstops[i] = YES;

   return (ret);
}


/* docolour --- set the screen colours */

static int docolour (lin, i)
register const uchar *lin;
int *i;
{
   int zone;
   int fg, bg;
   char *p;
   /* Zone names IN CORRECT ORDER! */
   static char znames[] = " tbc1$smnk.h-pu!TKC2RSP";
   /* Colour names also IN CORRECT ORDER! */
   static char cnames[] = "kbgcrmywKBGCRMYW";

   SKIPBL(lin, *i);
   if ((p = strchr (znames, lin[*i])) == NULL) {
      Errcode = ENONSENSE;
      return (ERR);
   }
   else
      zone = (int)(p - znames);

   (*i)++;
   SKIPBL(lin, *i);

   if ((p = strchr (cnames, lin[*i])) == NULL) {
      Errcode = ENONSENSE;
      return (ERR);
   }
   else
      fg = (int)(p - cnames);

   (*i)++;
   SKIPBL(lin, *i);

   if ((p = strchr (cnames, lin[*i])) == NULL) {
      Errcode = ENONSENSE;
      return (ERR);
   }
   else
      bg = (int)(p - cnames);

   setcolr (zone, fg, bg);

   First_affected = Topln;
   return (OK);
}
