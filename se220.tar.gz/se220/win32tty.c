/* win32tty --- video driver for MS Win32 console mode      24/06/1998 */
/* Copyright (c) 1998 BJ, Froods Software Development                  */

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <conio.h>

#include "keys.h"

#define DB1

/* Export name of machine */
string Smachine = "IBM PC (Win32)";

#define BLACK           0
#define BLUE            1
#define GREEN           2
#define CYAN            3
#define RED             4
#define MAGENTA         5
#define YELLOW          6
#define WHITE           7
#define BRIGHT          8

typedef unsigned int scancode;

#if NO_PROTOTYPES
static void clear_to_eol ();
#else
static void clear_to_eol (int row, int col, int zone);
#endif

#ifdef DB1
static bool Started = NO;
#endif   /* DB1 */
HANDLE Hndin = INVALID_HANDLE_VALUE;
HANDLE Hndout = INVALID_HANDLE_VALUE;
static unsigned Screen_image[MAXROWS][MAXCOLS];
static unsigned Blanks[MAXCOLS];    /* Blanks for filling in lines     */
static int Cur_size = CUR_NORMAL;   /* Cursor state                    */
static int Cur_on = YES;
static int Colours[23] = {
   0,
   WHITE,            /* Text                       */
   WHITE | BRIGHT,   /* Bar                        */
   WHITE,            /* Command line               */
   WHITE | BRIGHT,   /* Line one                   */
   WHITE | BRIGHT,   /* Line $                     */
   GREEN,            /* Status line                */
   GREEN | BRIGHT,   /* Messages on status line    */
   WHITE,            /* Line numbers               */
   WHITE,            /* Mark column                */
   WHITE | BRIGHT,   /* Current line               */
   WHITE | BRIGHT,   /* Help messages              */
   WHITE | BRIGHT,   /* Dashes in 'split-screen'   */
   RED | BRIGHT,     /* Prompts                    */
   YELLOW | BRIGHT,  /* Unprintable characters     */
   WHITE,            /* MS-DOS shell               */
   WHITE,            /* Source-code text           */
   WHITE,            /* Source-code code           */
   CYAN,             /* Source-code comments 1     */
   CYAN | BRIGHT,    /* Source-code comments 2     */
   WHITE | BRIGHT,   /* Source-code reserved words */
   MAGENTA | BRIGHT, /* Source-code strings        */
   RED | BRIGHT      /* Source-code pre-proc cmds. */
};


/* mvaddch --- put a character on the screen at (r, c) */

static void mvaddch (int r, int c, int ch)
{
   DWORD nc;
   COORD pos;
   char buf[2];
   //CHAR_INFO ci;
   WORD att[2];

   pos.X = c;
   pos.Y = r;

   //ci.Char.AsciiChar = ch & 0xff;
   //ci.Attributes = ch >> 8;

   buf[0] = ch & 0xff;
   att[0] = ch >> 8;

   WriteConsoleOutputCharacter (Hndout, buf, 1, pos, &nc);
   WriteConsoleOutputAttribute (Hndout, att, 1, pos, &nc);
}


/* mdvd_init --- initialise this module */

void mdvd_init ()
{
   register int row, col;

   /* Initialise array of blanks */
   for (col = 0; col < MAXCOLS; col++)
      Blanks[col] = (WHITE << 8) | ' ';       /* Set to white blanks */
      
   /* Clear virtual screen array */
   for (row = 0; row < MAXROWS; row++)
      for (col = 0; col < MAXCOLS; col++)
         Screen_image[row][col] = (WHITE << 8) | ' ';
}


/* term_init --- send start-up sequence to terminal */

void term_init ()
{
}


/* term_exit --- send close-down sequence to terminal */

void term_exit ()
{
   shape_cursor (CUR_NORMAL);
}


/* setcolr --- set the colour of a screen zone */

void setcolr (zone, fg, bg)
int zone;
int fg, bg;
{
#ifdef DB1
   if (Started == NO) {
      puts ("setcolr");
      getch ();
   }
#endif   /* DB1 */
   Colours[zone] = fg + (bg << 4);
}


/* shellcolr --- fix colour of screen for DOS shell */

void shellcolr ()
{
   register int i;
   register int row;
   unsigned int ch;
   
   row = Nrows - 1;
   ch = ' ' | (Colours[SHELL_ZONE] << 8);
   
   for (i = 0; i < Ncols; i++)
      mvaddch (row, i, ch);
}


/* mvinch --- read a character back from the screen image */

int mvinch (r, c)
int r, c;
{
   return (Screen_image[r][c] & 0xff);
}


/* cprow --- copy from one row to another for append */

void cprow (from, to)
register int from, to;
{
   register int col;

   for (col = 0; col < Ncols; col++)
      load (Screen_image[from][col] & 0xff, to, col, TEXT_ZONE);
}


/* load --- load a character onto the screen at given coordinates */

void load (chr, row, col, zone)
register int chr;
register int row, col;
int zone;
{
   register unsigned int ch;

#ifdef DB1
   if (Started == NO) {
      puts ("load");
      getch ();
   }
#endif   /* DB1 */
   if (chr < ' ')
      ch = (Colours[UPRT_ZONE] << 8) | Unprintable;
   else
      ch = (Colours[zone] << 8) | chr;

   if (row >= 0 && row < Nrows && col >= 0 && col < Ncols
       && Screen_image[row][col] != ch) {
      Screen_image[row][col] = ch;
      mvaddch (row, col, ch);
   }
}


/* loadstr --- load a string into a field of the screen */

void loadstr (str, row, stcol, endcol, zone)
const register uchar *str;
int row, stcol, endcol;
int zone;
{
   register unsigned int ch;
   register int p, c, limit;

#ifdef DB1
   if (Started == NO) {
      puts ("loadstr");
      getch ();
   }
#endif   /* DB1 */
   if (row >= 0 && row < Nrows && stcol >= 0) {
      for (p = 0, c = stcol; str[p] != EOS && c < Ncols; p++, c++) {

         if (str[p] < ' ')
            ch = (Colours[UPRT_ZONE] << 8) | (Unprintable & 0xff);
         else
            ch = (Colours[zone] << 8) | str[p];
         
         if (Screen_image[row][c] != ch) {
            Screen_image[row][c] = ch;
            mvaddch (row, c, ch);
         }
      }

      ch = (Colours[zone] << 8) | ' ';
      
      if (endcol >= Ncols - 1 && c < Ncols - 1)
         clear_to_eol (row, c, zone);
      else {
         limit = (endcol < Ncols - 1) ? endcol : Ncols - 1;
         for (; c <= limit; c++)
            if (Screen_image[row][c] != ch) {
               Screen_image[row][c] = ch;
               mvaddch (row, c, ch);
            }
      }
   }
}


/* restore_screen --- screen has been garbaged; fix it */

void restore_screen ()
{
   register int row, col;

   clrscreen ();
   for (row = 0; row < Nrows && ! intrpt (); row++)
      for (col = 0; col < Ncols; col++)
         mvaddch (row, col, Screen_image[row][col]);

   msgstr (SNULL, REMARK_MSG);   /* get rid of 'type control-q....' */
}


/* ringbell --- generate loud beeping noises */

void ringbell (type)
int type;               /* Different noises for different errors */
{
   if (!Quiet)
      putch (BEL);
}


/* clear_to_eol --- clear from current cursor position to end of line */

static void clear_to_eol (row, col, zone)
int row, col;
int zone;
{
   register int c;
   bool flag;
   register unsigned int space;
   DWORD nc;
   int len;
   COORD pos;

   flag = NO;

   space = (Colours[zone] << 8) | ' ';
   
   for (c = col; c < Ncols; c++)
      if (Screen_image[row][c] != space) {
         Screen_image[row][c] = space;
         flag = YES;
      }

   if (flag) {
      //in.h.cl = col;       /* Start col is current cursor col */
      //in.h.dl = Ncols - 1; /* End col is RH margin */
      //in.h.ah = SCROLL_UP; /* BIOS window scroller */
      //in.h.al = 0;         /* Clear instead of scroll */
      //in.h.ch = row;       /* Start row is current cursor row */
      //in.h.dh = row;       /* End row is same as start */
      //in.h.bh = Colours[zone]; /* Fill blanks with current colour */
      //int86 (VIDEO_INT, &in, &in);
      pos.X = col;
      pos.Y = row;
      len = Ncols - col;
      FillConsoleOutputCharacter (Hndout, ' ', len, pos, &nc);
   }
}


/* position_cursor --- move the cursor to (r, c) */

void position_cursor (r, c)
int r, c;                  /* Row and col to move to */
{
   COORD pos;

#ifdef DB1
   if (Started == NO) {
      puts ("position_cursor");
      getch ();
   }
#endif   /* DB1 */

   pos.Y = r;
   pos.X = c;

   SetConsoleCursorPosition (Hndout, pos);
}


/* show_cursor --- show or hide the text cursor */

void show_cursor (on)
bool on;
{   
#ifdef DB1
   if (Started == NO) {
      puts ("show_cursor");
      getch ();
   }
#endif   /* DB1 */

   if (on) {
      switch (Cur_size) {
      case CUR_NORMAL:
         break;
      case CUR_INSERT:
         break;
      }
   }
   else {
   }
      
   Cur_on = on;
}


/* shape_cursor --- set cursor size or style */

void shape_cursor (size)
int size;
{
#ifdef DB1
   if (Started == NO) {
      puts ("shape_cursor");
      getch ();
   }
#endif   /* DB1 */
   Cur_size = size;

   if (Cur_on)
      show_cursor (YES);
}


/* clrscreen --- clear the physical screen */

void clrscreen ()
{
   DWORD nc;
   int row;
   COORD pos;

#ifdef DB1
   if (Started == NO) {
      puts ("clrscreen");
      getch ();
   }
#endif   /* DB1 */

   for (row = 0; row < Nrows; row++) {
      pos.X = 0;
      pos.Y = row;
      FillConsoleOutputCharacter (Hndout, ' ', Ncols, pos, &nc);
   }

   position_cursor (0, 0);
}


/* inslines --- insert 'n' lines on the screen at 'row' */

void inslines (row, n)
int row, n;
{
   register int i;
   COORD pos;
   SMALL_RECT r;
   CHAR_INFO fill;

   //in.h.ah = SCROLL_DOWN;  /* BIOS window scroller */
   //in.h.al = n;            /* Scroll 'n' lines */
   //in.h.cl = 0;            /* Start col LH margin */
   //in.h.ch = row;          /* Start row is current cursor row */
   //in.h.dl = (unsigned char) (Ncols - 1); /* End col is RH margin */
   //in.h.dh = Nrows - 1;    /* End row bottom of screen */
   //in.h.bh = Colours[TEXT_ZONE]; /* Fill blanks with temp. colour */
   //int86 (VIDEO_INT, &in, &in);

   r.Left = 0;
   r.Right = Ncols - 1;
   r.Top = row;
   r.Bottom = Nrows - 1;

   fill.Char.AsciiChar = ' ';
   fill.Attributes = Colours[TEXT_ZONE];

   pos.X = 0;
   pos.Y = row + n;

   ScrollConsoleScreenBuffer (Hndout, &r, NULL, pos, &fill);

   for (i = Nrows - 1; i - n >= row; i--)
      memcpy (Screen_image[i], Screen_image[i - n], Ncols * sizeof (unsigned));

   for (; i >= row; i--)     
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
}


/* dellines --- delete 'n' lines beginning at 'row' */

void dellines (row, n)
int row, n;
{
   register int i;
   COORD pos;
   SMALL_RECT r;
   CHAR_INFO fill;

   r.Left = 0;
   r.Right = Ncols - 1;
   r.Top = row + 1;
   r.Bottom = Nrows - 1;

   fill.Char.AsciiChar = ' ';
   fill.Attributes = Colours[TEXT_ZONE];

   pos.X = 0;
   pos.Y = row + 1 - n;

   ScrollConsoleScreenBuffer (Hndout, &r, NULL, pos, &fill);

   //in.h.ah = SCROLL_UP; /* BIOS window scroller */
   //in.h.al = n;         /* Scroll 'n' lines */
   //in.h.cl = 0;         /* Start col LH margin */
   //in.h.ch = row;       /* Start row is current cursor row */
   //in.h.dl = (unsigned char) (Ncols - 1); /* End col is RH margin */
   //in.h.dh = Nrows - 1; /* End row bottom of screen */
   //in.h.bh = Colours[TEXT_ZONE]; /* Fill blanks with current colour */
   //int86 (VIDEO_INT, &in, &in);

   for (i = row; i + n < Nrows; i++)
      memcpy (Screen_image[i], Screen_image[i + n], Ncols * sizeof (unsigned));

   for (; i < Nrows; i++)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
}


/* set_term --- initialise terminal parameters and actual capabilities */

int set_term (type, hwinsdel, pr, pc)
const uchar *type;
bool *hwinsdel;
int *pr, *pc;
{
   int rows, cols;
   
   rows = 25;
   cols = 80;

   /* Open the input and output handles */
   Hndin = GetStdHandle (STD_INPUT_HANDLE);
   Hndout = GetStdHandle (STD_OUTPUT_HANDLE);

#ifdef DB1
   Started = YES;
#endif   /* DB1 */
   
   *hwinsdel = YES;
   *pr = rows;
   *pc = cols;
   
   return (OK);
}


/* term_name --- return the name of the terminal */

uchar *term_name ()
{
#ifdef DB1
   if (Started == NO) {
      puts ("term_name");
      getch ();
   }
#endif   /* DB1 */
   return ("IBM-PC");
}


/* readkey --- read keystrokes and map into 'se' tokens */

int readkey (raw)
bool raw;
{
   int k;
   //int mx, my;
   BOOL done;
   INPUT_RECORD buf;
   DWORD ne;

   done = FALSE;

   do {
      if (ReadConsoleInput (Hndin, &buf, 1, &ne) == FALSE)
         printf ("readkey: ReadConsoleInput: %d\n", GetLastError ());

      switch (buf.EventType) {
      case KEY_EVENT:
         if (buf.Event.KeyEvent.bKeyDown && (buf.Event.KeyEvent.uChar.AsciiChar != 0)) {
            k = buf.Event.KeyEvent.uChar.AsciiChar;

            if (k < ' ')
               k = -k;
            else if (k == DEL)
               k = CDELETE;

            done = TRUE;
         }
         //else if (buf.Event.KeyEvent.bKeyDown)
         //   printf ("key is %d (%d)\n", buf.Event.KeyEvent.wVirtualKeyCode, buf.Event.KeyEvent.wVirtualScanCode);

         if (buf.Event.KeyEvent.wVirtualKeyCode == VK_CAPITAL) {
            if (buf.Event.KeyEvent.dwControlKeyState & CAPSLOCK_ON)
               msgstr (SCAPS, CAPS_MSG);
            else
               msgstr (SNULL, CAPS_MSG);
         }

         break;
      case MOUSE_EVENT:
         if (buf.Event.MouseEvent.dwEventFlags == MOUSE_MOVED)
            ;
         else {
            //printf ("Mouse: %d\n", buf.Event.MouseEvent.dwButtonState);
            if (buf.Event.MouseEvent.dwButtonState & FROM_LEFT_1ST_BUTTON_PRESSED) {
               k = LMB;
               done = TRUE;
            }
            else if (buf.Event.MouseEvent.dwButtonState & RIGHTMOST_BUTTON_PRESSED) {
               k = RMB;
               done = TRUE;
            }
         }

         break;
      case WINDOW_BUFFER_SIZE_EVENT:
         break;
      case MENU_EVENT:
      case FOCUS_EVENT:
      default:
         break;
      }

   } while (!done);

   return (k);
}

#if 0

/* got_keystroke --- read a keyboard event */

static int got_keystroke (raw)
bool raw;
{
   static keycode ktab[] = {
/*00*/NOKEY,   NOKEY,   NOKEY,   C_2,     NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*08*/NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*10*/A_Q,     A_W,     A_E,     A_R,     A_T,     A_Y,     A_U,     A_I,
/*18*/A_O,     A_P,     NOKEY,   NOKEY,   NOKEY,   NOKEY,   A_A,     A_S,
/*20*/A_D,     A_F,     A_G,     A_H,     A_J,     A_K,     A_L,     NOKEY,
/*28*/NOKEY,   C_BQT,   NOKEY,   NOKEY,   A_Z,     A_X,     A_C,     A_V,
/*30*/A_B,     A_N,     A_M,     NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*38*/NOKEY,   C_SPACE, NOKEY,   F1,      F2,      F3,      F4,      F5,
/*40*/F6,      F7,      F8,      F9,      F10,     NOKEY,   NOKEY,   CHOME,
/*48*/CUP,     PUP,     NOKEY,   CLEFT,   NOKEY,   CRIGHT,  NOKEY,   CEND,
/*50*/CDOWN,   PDOWN,   CINSERT, ERASE,   S_F1,    S_F2,    S_F3,    S_F4,
/*58*/S_F5,    S_F6,    S_F7,    S_F8,    S_F9,    S_F10,   C_F1,    C_F2,
/*60*/C_F3,    C_F4,    C_F5,    C_F6,    C_F7,    C_F8,    C_F9,    C_F10,
/*68*/A_F1,    A_F2,    A_F3,    A_F4,    A_F5,    A_F6,    A_F7,    A_F8,
/*70*/A_F9,    A_F10,   NOKEY,   C_CLEFT, C_CRIGHT,C_CEND,  C_PDOWN, C_CHOME,
/*78*/A_1,     A_2,     A_3,     A_4,     A_5,     A_6,     A_7,     A_8,
/*80*/A_9,     A_0,     A_DASH,  A_EQ,    C_PUP,   F11,     F12,     S_F11,
/*88*/S_F12,   C_F11,   C_F12,   A_F11,   A_F12,   C_CUP,   NOKEY,   NOKEY,
/*90*/NOKEY,   C_CDOWN, C_CINSERT,C_ERASE,NOKEY,   NOKEY,   NOKEY,   A_CHOME,
/*98*/A_CUP,   A_PUP,   NOKEY,   A_CLEFT, NOKEY,   A_CRIGHT,NOKEY,   A_CEND,
/*a0*/A_CDOWN, A_PDOWN, A_CINSERT,A_ERASE,NOKEY,   NOKEY,   A_ENTER, NOKEY
   };
   scancode scode;
   int ascii;
   
   scode = getscan ();
   ascii = scode & 0xff;
   
   if (raw)
      return (ascii);
   else if (!(ascii == 0x00 || ascii == 0xe0)) {
      if (ascii < ' ')
         return (-ascii);
      else if (ascii == DEL)
         return (CDELETE);
      else
         return (ascii);
   }
   else {
      scode >>= 8;
      
      if (scode < (sizeof (ktab) / sizeof (ktab[0])))
         return (ktab[scode]);
      else
         return (NOKEY);   /* Unknown scan code */
   }
}
#endif
