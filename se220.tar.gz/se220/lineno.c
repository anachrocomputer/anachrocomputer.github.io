/* lineno --- line number parsing routines                  03/08/1987 */

#include "se.h"
#include "extern.h"


#if NO_PROTOTYPES
static int getnum ();
#else
static int getnum (uchar [], int *, Lnum *, int *); 
#endif


/* getlst --- collect line numbers (if any) at lin[*i], increment i */

int getlst (lin, i, status)
register uchar lin[];
register int *i;
int *status;
{
   Lnum num;

   Line2 = 0;
   for (Nlines = 0; (*status = getone (lin, i, &num)) == OK; ) {
      Line1 = Line2;
      Line2 = num;
      Nlines++;
      if (lin[*i] != ',' && lin[*i] != ';')
         break;

      if (lin[*i] == ';')
         Curln = num;

      (*i)++;
   }

   if (Nlines > 2)
      Nlines = 2;

   if (Nlines <= 1)
      Line1 = Line2;

   if (Line1 > Line2) {
      *status = ERR;
      Errcode = EBACKWARD;
   }

   if (*status != ERR)
      *status = OK;

   return (*status);
}


/* getnum --- convert one term to line number */

static int getnum (lin, i, pnum, status)
uchar lin[];      /* Code for missing delimiters will write into 'lin' */
register int *i;
register Lnum *pnum;
register int *status;
{
   int j, ret;
   int k;
   bool missing_delim = YES;

   ret = OK;
   SKIPBL (lin, *i);
   if (lin[*i] >= Rel_a && lin[*i] <= Rel_z && Absnos == NO)
      *pnum = Topln - Toprow + lin[*i] - Rel_a;
   else if (lin[*i] == CURLINE)
      *pnum = Curln;
   else if (lin[*i] == PREVLN || lin[*i] == PREVLN2)
      *pnum = Curln - 1;
   else if (lin[*i] == LASTLINE)
      *pnum = Lastln;
   else if (lin[*i] == SCAN || lin[*i] == BACKSCAN) {
      /* see if trailing delim supplied, since command can follow pattern */
      for (k = *i + 1; lin[k] != EOS; k++)
         if (lin[k] == ESCAPE)
            k++;    /* skip esc, loop will skip escaped char */
         else if (lin[k] == lin[*i]) {
            missing_delim = NO;
            break;
         }
         /* else
            continue */

      if (missing_delim) {
         for (; lin[k] != EOS; k++)
            ;

         k--;       /* k now at newline */

         /* supply trailing delim */
         lin[k] = lin[*i];
         lin[++k] = NEWLINE;
         lin[++k] = EOS;
         Peekc = YES;
      }

      if (optpat (lin, i) == ERR)
         ret = ERR;
      else if (lin[*i] == SCAN)
         ret = ptscan (FORWARD, pnum);
      else
         ret = ptscan (BACKWARD, pnum);
   }
   else if (lin[*i] == SEARCH || lin[*i] == BACKSEARCH) {
      j = *i;
      (*i)++;

      if (getkn (lin, i, &Savknm, Savknm) == ERR)
         ret = ERR;
      else if (lin[j] == SEARCH)
         ret = knscan (FORWARD, pnum);
      else
         ret = knscan (BACKWARD, pnum);

      (*i)--;
   }
   else if (isdigit (lin[*i])) {
      *pnum = ctoi (lin, i);
      (*i)--;
   }
   else if (lin[*i] == TOPLINE)
      *pnum = Topln;
   else
      ret = EOF;

   if (ret == OK)
      (*i)++;

   *status = ret;

   return (ret);
}


/* getone --- evaluate one line number expression */

int getone (lin, i, num)
uchar lin[];
register int *i;
register Lnum *num;
{
   int status;
   int ret;
   Lnum pnum;
   char porm;      /* "plus or minus" (sic) */

   ret = EOF;      /* assume we won't find anything for now */
   status = OK;
   *num = 0;

   if (getnum (lin, i, num, &status) == OK) {       /* first term */
      ret = OK;       /* to indicate we've seen something */

      do {          /* + or - terms */
         porm = EOS;
         SKIPBL (lin, *i);

         if (lin[*i] == '-' || lin[*i] == '+') {
            porm = lin[*i];
            (*i)++;
         }

         if (getnum (lin, i, &pnum, &status) == OK) {
            if (porm == '-')
               *num -= pnum;
            else
               *num += pnum;
         }
         
         if (status == EOF && porm != EOS)      /* trailing + or - */
            status = ERR;
      } while (status == OK);
   }

   if (*num < 0 || *num > Lastln) {   /* make sure number is in range */
      status = ERR;
      Errcode = EORANGE;
   }

   if (status == ERR)
      ret = ERR;
   else
      status = ret;

   return (ret);
}


/* defalt --- set defaulted line numbers */

void defalt (def1, def2)
Lnum def1, def2;
{
   if (Nlines == 0) {      /* no line numbers supplied, use defaults */
      Line1 = def1;
      Line2 = def2;
   }
}


/* nextln --- get line after "line" */

Lnum nextln (line)
register Lnum line;
{
   line++;

   if (line > Lastln)
      line = 0;

   return (line);
}


/* prevln --- get line before "line" */

Lnum prevln (line)
register Lnum line;
{
   line--;

   if (line < 0)
      line = Lastln;

   return (line);
}
