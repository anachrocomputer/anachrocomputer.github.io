#ifdef RCS_ID
static char RCSid[] = "$Header: main.c,v 2.08 89/05/29 16:00:00 BJ Exp $";
#endif

/*
 * $Log:        main.c,v $
 * Revision 2.10 91/12/15  20:00:00  BJ
 * Moved signal-handling code into 'sesig.c'
 * Removed obsolete '-t <term_type>' option -- deleted 'Argno'
 *
 * $Log:        main.c,v $
 * Revision 2.09 90/06/19  14:00:00  BJ
 * Added ANSI exit codes
 *
 * Revision 2.08 89/05/29  16:00:00  BJ
 * Moved 'Tspeed' and 'Term_type' into 'term.c'
 * Moved 'Currow' and 'Curcol' into video driver
 * Eliminated global variable 'Txt'
 *
 * Revision 2.05 88/05/16  00:00:00  BJ
 * Added ANSI 'const' declarations
 *
 * Revision 2.0  87/09/14  13:59:00  BJ
 * Removed many UNIX dependencies
 * Moved some global variables out into modules
 *
 * Revision 1.4  86/10/07  14:50:17  arnold
 * Changed setterm to set_term, to avoid Unix/PC shared library conflict.
 *
 * Revision 1.3  86/07/17  17:20:58  arnold
 * Terminal initialization code cleaned up considerably.
 *
 * Revision 1.2  86/07/11  15:12:26  osadr
 * Removed code that was Georgia Tech specific
 *
 * Revision 1.1  86/05/06  13:37:38  osadr
 * Initial revision
 *
 *
 */

/*
 * main.c
 *
 * main program and lots of other routines
 * for 'se' -- the hoopiest screen editor in the whole of the 
 * known Universe.
 */

#include "se.h"

/* Declare global variables */

/* Export the version number */
string Sversion = "V2.20";

/* Concerning line numbers: */
Lnum Line1;                   /* First line number on command line     */
Lnum Line2;                   /* Second line number on command line    */
int Nlines;                   /* Number of line numbers specified      */
Lnum Curln;                   /* Current line; value of dot            */
Lnum Lastln;                  /* Last line; value of dollar            */
Lnum Topln;                   /* Line number of first line on screen   */
Lnum First_affected;          /* Number of first line affected by cmd  */
uchar Savknm = DEFAULTNAME;   /* Saved mark name for < and >           */


/* Concerning patterns: */
Pattern Pat = "";             /* Saved pattern for 's' command         */
uchar Savpat[MAXLINE] = "";   /* Saved pattern as ASCII                */
uchar Tlpat[MAXPAT] = "";     /* Saved character list for 'y' command  */


/* Concerning the 'undo' command: */
#ifdef OLD_SCRATCH
LINEDESC *Free = NULL;        /* Head of free list                     */
LINEDESC *Limbo = NULL;       /* Head of limbo list for undo           */
#else
int Limbo = 0;                /* Index of first limbo line in Buf      */
#endif
int Limcnt = 0;               /* Number of lines in limbo              */
int Lost_lines = 0;        /* Number of garbage lines in scratch file */


/* Concerning file names: */
uchar Dirsep = EOS;           /* Directory separator character         */
uchar Filsep = EOS;           /* File suffix separator character       */


/* Concerning line descriptors: */
LINEDESC Buf[MAXBUF];         /* The line descriptor array             */
LINEDESC *Line0;              /* Head of list of line descriptors      */


/* Concerning miscellaneous variables */
bool Buffer_changed = NO;  /* YES if buffer changed since last write  */
int Errcode = ENOERR;      /* cause of most recent error              */
int Saverrcode = ENOERR;   /* cause of previous error                 */
bool Peekc = NO;           /* push a SKIP_RIGHT if adding delimiters  */


/* Concerning options: */
int Ddir;                  /* Delete direction                        */
bool Compress;             /* Compress/expand tabs on read/write      */
uchar Tabstr[MAXLINE] = "";   /* String representation of tab stops   */
bool Tabstops[MAXLINE];    /* Array of tab stops                      */
uchar Unprintable;         /* Char to print for unprintable chars     */
bool Absnos;               /* Use absolute numbers in margin          */
int Nchoise;               /* Choice of line number for cont. display */
bool Patchoise;            /* Display saved pattern ?                 */
int Overlay_col;           /* Initial cursor column for 'v' command   */
int Warncol;               /* Where to turn on column warning         */
int Firstcol;              /* Leftmost column to display              */
int Indent;                /* Indent col; 0=same as previous line     */
bool Notify;               /* Notify user if he has mail in mail file */
bool Globals;              /* Substitutes in a global don't fail      */
bool No_hardware;          /* Never use hardware insert/delete        */
bool Subsys;               /* Working in 'Subsystem' mode             */
bool View;                 /* Working in 'Read-only' mode             */
bool Quiet;                /* NOISY mode!                             */
bool Use_script = NO;      /* Flag for reading from a script          */
FILE *Scriptfp = NULL;     /* Stream for script file                  */
bool Src_mode;             /* Source-code mode                        */
uchar Ot[MAXLINE];         /* Open tag                                */
uchar Ct[MAXLINE];         /* Close tag                               */
uchar Q1;                  /* Two types of quote                      */
uchar Q2;
uchar Oc1[MAXLINE];        /* Open comment 1                          */
uchar Cc1[MAXLINE];        /* Close comment 1                         */
uchar Oc2[MAXLINE];        /* Open comment 2                          */
uchar Cc2[MAXLINE];        /* Close comment 2                         */
uchar Op[MAXLINE];         /* Open pre-processor directive            */
uchar Cp[MAXLINE];         /* Close pre-processor directive           */
bool Casematch;            /* Case sensitive matching                 */
bool Show_ok;              /* Display 'changed' message               */
bool Invert_case;          /* Flag to specify case mapping on input   */
bool Insert_mode;          /* Flag to specify character insertion     */
int Rel_a;                 /* Char to use for first alpha line number */
int Rel_z;                 /* Char to use for last alpha line number  */
bool Crypting;             /* Doing file encryption?                  */
char Key[KEYSIZE] = "";    /* Saved encryption key                    */


/* Concerning the screen format: */
int Nrows;              /* Number of rows on screen                  */
int Ncols;              /* Number of columns on screen               */
bool Terminsdel;        /* TRUE if terminal can do ins/del line      */
int Toprow;             /* Top row of window field on screen         */
int Botrow;             /* Bottom row of window field on screen      */
int Cmdrow;             /* Row number of command line                */
int Scline[MAXROWS];    /* Lines currently on screen (rel to Sctop)  */
int Sctop;              /* First line currently on screen            */
int Sclen;              /* Number of lines currently on screen       */


/* Special stack size for Turbo C */
#if MSDOS & TCC
int _stklen = 8192;        /* Allow 8k for stack */
#endif


#if NO_PROTOTYPES
static void initialise ();
static void usage ();
#else
static void initialise (void);
static void usage (void);
#endif   /* NO_PROTOTYPES */


/* main --- main program for screen editor */

int main (argc, argv)
int argc;
const uchar *argv[];
{
   initialise ();

   /* Initialise the scratch file: */
   mkbuf ();

   edit (argc, argv);
   
   /* Get rid of the scratch file: */
   clrbuf ();

   /* Send any required close-down sequence to the terminal */
   term_exit ();
   
   /* Reset the terminal line modes */
   ttynormal ();
   
   /* Terminate gracefully */
   pvem_close ();
   
   return (EXIT_SUCCESS);
}


/* initialise --- set up global data areas, get terminal type */

static void initialise ()
{
   int r, c;
   
   os_init ();
   sig_init ();
   file_init ();
   mdvd_init ();
   pvem_init ();
   screen_init ();
   
   r = c = -1;
   
   if (set_term ((uchar *)getenv ("TERM"), &Terminsdel, &r, &c) == ERR)
      usage ();
         
   if (r == -1)
      error (NO, "could not determine number of rows");

   if (c == -1)
      error (NO, "could not determine number of columns");

   Nrows = r;
   Ncols = c;
   
   /* Set up screen size parameters */
   setscreen ();

   /* Set terminal line to no echo, no output processing */
   ttyedit ();

   /* Send any required start-up sequence to the terminal */
   term_init ();
   
   /* Clear the screen */
   clrscreen ();

   doopt_init ();
   bind_init ();
}


/* error --- print error message and die semi-gracefully */

void error (coredump, msg)
bool coredump;
char *msg;
{
/*
 * You might think we want to try and save the buffer,
 * BUT, fatal errors can be caused by buffer problems,
 * which would end up putting us into a non-ending recursion.
 */
   term_exit ();
   ttynormal ();

   fprintf (stderr, "se: %s\n", msg);

   if (coredump)
      do_coredump ();
   else
      exit (EXIT_FAILURE);
}


/* usage --- print usage diagnostic and die */

static void usage ()
{
   fputs ("Usage: se [--abcdfghijklmopqrstuvwxyz] [file ...]\n", stderr);

   exit (EXIT_FAILURE);
}
