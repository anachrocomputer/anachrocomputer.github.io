/* Terminal types */
#define NOTERM          0    /* type not known yet                   */
#define ADDS980         1    /* ADDS Consul 980                      */
#define ADDS100         2    /* ADDS Regent 100, 20, 40, etc         */
#define FOX             3    /* Perkin-Elmer 1100                    */
#define TVT             4    /* Allen's SWTPC T. V. Typewriter II    */
#define GT40            5    /* DEC GT40 with Waugh terminal program */
#define BEE150          6    /* Beehive 150                          */
#define BEE200          7    /* Beehive 200                          */
#define SBEE            8    /* Beehive Super-Bee                    */
#define SOL             9    /* Sol emulating Beehive 200            */
#define HAZ1510         10   /* Hazeltine 1500 series                */
#define CG              11   /* Chromatics CG                        */
#define ISC8001         12   /* ISC 8001 color terminal              */
#define ADM3A           13   /* Lear-Siegler ADM 3A                  */
#define IBM             14   /* IBM 3101                             */
#define ANP             15   /* Allen & Paul model 1                 */
#define NETRON          16   /* Netronics                            */
#define H19             17   /* Heath H19/Zenith Z19                 */
#define TRS80           18   /* Radio Shaft TRS80                    */
#define HP21            19   /* Hewlett-Packard 2621A/P              */
#define ADM31           20   /* Lear-Siegler ADM 31                  */
#define VI200           21   /* VIsual 200 terminal                  */
#define VC4404          22   /* Volker-Craig 4404                    */
#define ESPRIT          23   /* Hazeltine Esprit (Hazeltine mode)    */
#define TS1             24   /* Falco TS-1                           */
#define TVI950          25   /* Televideo 950                        */
#define VI50            26   /* Visual 50                            */
#define VI300           27   /* Visual 300                           */
#define PCANSI          28   /* MS-DOS with ANSI.SYS installed       */
#define VT100           29   /* DEC VT100                            */
#define VT200           30   /* DEC VT220/VT240                      */
#define VT300           31   /* DEC VT320                            */
#define PERQ_PNX        32   /* ICL PERQ                             */
