/* mdvd --- machine-dependent video driver (skeleton)       18/07/1989 */
/* Copyright (c) 1989 BJ, Froods Software Development                  */


/* Export name of machine */
string Smachine = "skeleton";


static unsigned int Screen_image[MAXROWS][MAXCOLS];
static unsigned int Blanks[MAXCOLS];   /* Blanks for filling in lines */
static int Currow = 0;                 /* Cursor row                  */
static int Curcol = 0;                 /* Cursor column               */
static int Cur_size = CUR_NORMAL;      /* Cursor state                */
static int Cur_on = YES;

#if NO_PROTOTYPES
static void clear_to_eol ();
#else
static void clear_to_eol (int row, int col, int zone);
#endif


/* mdvd_init --- initialise this module */

void mdvd_init ()
{
   register int row, col;

   /* Initialise array of blanks */
   for (col = 0; col < MAXCOLS; col++)
      Blanks[col] = ' ';
      
   /* Clear virtual screen array */
   for (row = 0; row < MAXROWS; row++)
      for (col = 0; col < MAXCOLS; col++)
         Screen_image[row][col] = ' ';
}


/* set_term --- initialise terminal parameters and actual capabilities */

int set_term (type, hwinsdel, r, c)
const uchar *type;
bool *hwinsdel;
int *r, *c;
{
   *r = 25;
   *c = 80;
   *hwinsdel = NO;
   
   return (OK);
}


/* term_init --- send start-up sequence to terminal */

void term_init ()
{
}


/* term_exit --- send close-down sequence to terminal */

void term_exit ()
{
}


/* setcolr --- set the colour of a screen zone */

void setcolr (zone, fg, bg)
int zone;
int fg, bg;
{
}


/* shellcolr --- fix colour of screen for DOS shell */

void shellcolr ()
{
}


/* mvinch --- read a character back from the screen image */

int mvinch (r, c)
int r, c;
{
   return (Screen_image[r][c] & 0xff);
}


/* cprow --- copy from one row to another for append */

void cprow (from, to)
register int from, to;
{
   register int col;

   for (col = 0; col < Ncols; col++)
      load (Screen_image[from][col] & 0xff, to, col, TEXT_ZONE);
}


/* load --- load a character onto the screen at given coordinates */

void load (chr, row, col, zone)
register uchar chr;
register int row, col;
int zone;
{
   register uchar ch;

   if (chr < ' ')
      ch = Unprintable;
   else
      ch = chr;

   if (row >= 0 && row < Nrows && col >= 0 && col < Ncols
       && Screen_image[row][col] != ch) {
      Screen_image[row][col] = ch;
      /* Send 'ch' to screen at (row, col) */
   }
}


/* loadstr --- load a string into a field of the screen */

void loadstr (str, row, stcol, endcol, zone)
register const uchar *str;
int row, stcol, endcol;
int zone;
{
   register unsigned int ch;
   register int p, c, limit;

   if (row >= 0 && row < Nrows && stcol >= 0) {
      for (p = 0, c = stcol; str[p] != EOS && c < Ncols; p++, c++) {

         if (str[p] < ' ')
            ch = Unprintable;
         else
            ch = str[p];
         
         if (Screen_image[row][c] != ch) {
            Screen_image[row][c] = ch;
            /* Send 'ch' to screen at (row, col) */
         }
      }

      ch = ' ';
      
      if (endcol >= Ncols - 1 && c < Ncols - 1)
         clear_to_eol (row, c, zone);
      else {
         limit = (endcol < Ncols - 1) ? endcol : Ncols - 1;
         for (; c <= limit; c++)
            if (Screen_image[row][c] != ch) {
               Screen_image[row][c] = ch;
               /* Send 'ch' to screen at (row, col) */
            }
      }
   }
}


/* restore_screen --- screen has been garbaged; fix it */

void restore_screen ()
{
   register int row, col;

   clrscreen ();

   for (row = 0; row < Nrows && ! intrpt (); row++)
      for (col = 0; col < Ncols; col++)
         ;  /* Send 'ch' to screen at (row, col) */

   msgstr (SNULL, REMARK_MSG);   /* get rid of 'type control-q....' */
}


/* ringbell --- generate loud beeping noises */

void ringbell (type)
int type;               /* Different noises for different errors */
{
   if (!Quiet)
      ;     /* Send 'BEL' */
}


/* clear_to_eol --- clear from current cursor position to end of line */

static void clear_to_eol (row, col, zone)
int row, col;
int zone;
{
   register int c;
   bool flag;
   register unsigned int space;

   flag = NO;

   space = ' ';
   
   for (c = col; c < Ncols; c++)
      if (Screen_image[row][c] != space) {
         Screen_image[row][c] = space;
         flag = YES;
      }

   if (flag) {
      /* Send 'clear to end of line' sequence */
   }
}


/* position_cursor --- move the cursor to (r, c) */

void position_cursor (r, c)
int r, c;                  /* Row and col to move to */
{
   if (r == Currow && c == Curcol)
      return;
      
   /* Move that cursor! */
   
   Currow = r;
   Curcol = c;
}


/* show_cursor --- show or hide the text cursor */

void show_cursor (on)
bool on;
{
   Cur_on = on;
}


/* shape_cursor --- set cursor size or style */

void shape_cursor (size)
int size;
{
   Cur_size = size;
}


/* clrscreen --- clear the physical screen */

void clrscreen ()
{
}


/* inslines --- insert 'n' lines on the screen at 'row' */

void inslines (row, n)
int row, n;
{
   register int i;

   for (i = Nrows - 1; i - n >= row; i--)
      memcpy (Screen_image[i], Screen_image[i - n], Ncols * sizeof (unsigned));

   for (; i >= row; i--)     
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
}


/* dellines --- delete 'n' lines beginning at 'row' */

void dellines (row, n)
int row, n;
{
   register int i;

   for (i = row; i + n < Nrows; i++)
      memcpy (Screen_image[i], Screen_image[i + n], Ncols * sizeof (unsigned));

   for (; i < Nrows; i++)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
}


/* term_name --- return the name of the terminal */

uchar *term_name ()
{ 
   return ((uchar *)"?");
}


/* readkey --- read keystrokes and map for cursor keys and mouse */

int readkey (raw)
bool raw;
{
}
