/* misccmds --- do all miscellaneous commands               03/08/1987 */

#include "se.h"
#include "extern.h"
#include "cmds.h"

#if NO_PROTOTYPES
static int draw_box ();
#else
static int draw_box (const uchar *lin, int i);
#endif


/* domisc --- parse and call miscellaneous commands */

int domisc (lin, i)
register const uchar *lin;
int i;
{
   int ret = ERR;
   uchar ch, cmd;
   uchar str[MAXLINE];
   
   cmd = lin[i];
   i++;
   
   if (isupper (cmd))
      cmd = tolower (cmd);

   ch = lin[i];

   defalt (Curln, Curln);
   
   switch (cmd) {
   case BOXCOM:    /* Draw box */
      if (View)
         Errcode = EVIEW;
      else
         ret = draw_box (lin, i);

      break;

#ifdef DB
   case 'd':               /* Display debugging information */
      sprintf (str, "sizeof (Buf): %u", sizeof (Buf));
      mesg (str, REMARK_MSG);
      ret = OK;
      break;
      
   case 'e':
      DumpFreeChain ();
      getch ();
      ret = OK;
      break;
#endif   /* DB */
      
   case VERCOM:      /* Display version info */
      if (ch == NEWLINE) {
         verstr (str);
         mesg (str, REMARK_MSG);
         ret = OK;
      }
      break;

   default:
      Errcode = EWHATZAT;
      break;
   }

   return (ret);
}


/* draw_box --- draw or erase a box at coordinates in command line */

static int draw_box (lin, i)
register const uchar *lin;
int i;
{
   int left, right, col, len;
   register LINEDESC *k;
   uchar text[MAXLINE];
   uchar txt[MAXLINE];
   uchar ch;

   left = ctoi (lin, &i);
   if (left <= 0 || left > MAXLINE) {
      Errcode = EBADCOL;
      return (ERR);
   }

   if (lin[i] == ',') {
      i++;
      SKIPBL (lin, i);
      right = ctoi (lin, &i);
      if (right <= 0 || right >= MAXLINE || left > right) {
         Errcode = EBADCOL;
         return (ERR);
      }
   }
   else
      right = left;

   SKIPBL (lin, i);
   if (lin[i] == NEWLINE)
      ch = ' ';
   else
      ch = lin[i++];

   if (lin[i] != NEWLINE) {
      Errcode = EEGARB;
      return (ERR);
   }

   if (Line1 <= 0) {
      Errcode = EORANGE;
      return (ERR);
   }

   for (Curln = Line1; Curln <= Line2; Curln++) {
      k = getind (Curln);
      len = gtxt (k, txt);
      memcpy (text, txt, len);

      if (text[len - 2] == NEWLINE)
         col = len - 1;
      else
         col = len;

      for (; col <= right; col++)
         text[col - 1] = ' ';

      text[col - 1] = NEWLINE;
      text[col] = EOS;

      if (Curln == Line1 || Curln == Line2)
         for (col = left; col <= right; col++)
            text[col - 1] = ch;
      else {
         text[left - 1] = ch;
         text[right - 1] = ch;
      }

      if (strucmp (text, txt) != 0) {
         if (changeln (k, text, NO) == ERR)
            return (ERR);
      }
   }

   Curln = Line1;     /* move to top of box */
   if (First_affected > Curln)
      First_affected = Curln;

   adjust_window (Curln, Curln);

   return (OK);
}
