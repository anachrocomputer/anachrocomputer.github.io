#ifdef RCS_ID
static char RCSid[] = "$Header: docmd.c,v 2.0 87/10/26 19:00:00 BJ Exp $";
#endif         

/*
 * $Log:        docmd.c,v $
 * Revision 2.20  00/11/05  21:00:00  BJ
 * Once again removed SWT command letter
 *
 * Revision 2.08  89/05/28  21:00:00  BJ
 * Changed 'bind' into an option
 * Split #defines into 'cmds.h'
 *
 * Revision 2.0  87/10/26  19:00:00  BJ
 * Restored SWT command letters
 * Separated 'docmd ()' from rest of code
 *
 * Revision 1.3  86/07/17  17:19:37  arnold
 * Some general code cleaning up.
 *
 * Revision 1.2  86/07/11  15:10:20  osadr
 * Removed Georgia Tech specific items.
 *
 * Revision 1.1  86/05/06  13:36:44  osadr
 * Initial revision
 *
 *
 */

/*
 * docmd.c
 *
 * main command processor.
 */

#include "se.h"
#include "extern.h"

#include "cmds.h"    /* Command codes */

#define APND1           '>'
#define APND2           '+'
#define XTABS           'x'
#define UCXTABS         'X'


#if NO_PROTOTYPES
static bool ckchar ();
static int ckupd ();
static int getstr ();
#else
static bool ckchar (int, int, const uchar [], int *);
static int ckupd (const uchar [], int *, int);
static int getstr (uchar *, int *, uchar *, int);
#endif


/* docmd --- handle all commands except globals */

int docmd (lin, i, glob)
uchar lin[];
int i;
bool glob;
{
   int status;
   uchar file[MAXPATH];       /* Filename for 'e', 'r', 'w', 'f' */
   Pattern sub;               /* Substitution for 's'            */
   uchar kname;               /* Mark name                       */
   uchar cmd, ch;             /* Command letter & one after      */
   bool gflag;                /* Global substitute               */
   bool flag;                 /* Append instead of overwrite     */       
   bool fflag;                /* Force overwrite                 */
   bool tflag;                /* Expand tabs on read/write       */
   bool qflag;                /* Quit after write                */
   register int j;            /* For adding delimiters           */
   bool missing_delim;
   int line3, allbut;

   status = ERR;
   if (intrpt ())  /* catch a pending interrupt */
      return (status);

   cmd = lin[i++];
   if (isupper(cmd))
      cmd = tolower(cmd);
      
   ch = lin[i];    /* First character of command args */
   
   defalt (Curln, Curln);
   
   /* First check for a read-only buffer */
   if (View) {
      switch (cmd) {
      case INSERTCOM:
      case APPENDCOM:
      case OVERLAYCOM:
      case CHANGECOM:
      case DELCOM:
      case MOVECOM:
      case COPYCOM:
      case SUBSTITUTE:
      case TLITCOM:
      case JOINCOM:
      case UNDOCOM:
      case READCOM:
         Errcode = EVIEW;
         return (status);
      }
   }
   
   switch (cmd) {
   case INSERTCOM:
      if (Line1 <= 0) {
         Errcode = EORANGE;
         break;
      }

   case APPENDCOM:

      if (ch == NEWLINE || ch == INLINE) {
         if (ch == NEWLINE) {
            /* avoid updating with inline insertion */
            adjust_window (Line1, Line2);
            updscreen ();
         }

         if (cmd == APPENDCOM)
            status = append (Line2, &lin[i]);
         else
            status = append (prevln (Line2), &lin[i]);
      }
      break;

   case PRINTCUR:
      if (ch == NEWLINE) {
         saynum (Line2);
         status = OK;
      }
      break;

   case OVERLAYCOM:
      if (ch == NEWLINE)
         status = dooverlay ();

      break;

   case CHANGECOM:
      if (Line1 <= 0)
         Errcode = EORANGE;
      else if (ch == NEWLINE || ch == INLINE)
         status = dochange (&lin[i]);

      break;

   case DELCOM:
      if (lin[i] == NEWLINE) {
         if ((status = deleteln (Line1, Line2)) == OK) {
            if (Ddir == FORWARD) {
               if (Line1 <=  Lastln)
                  Curln = Line1;
               else
                  Curln = Lastln;
            }
            else {
               if (Line1 > 1)
                  Curln = prevln (Line1);
               else
                  Curln = 1;
            }
         }
      }
      break;

   case MOVECOM:
   case COPYCOM:
      if ((status = getone (lin, &i, &line3)) == EOF)
         status = ERR;
      else {
         if (lin[i] == NEWLINE) {
            if (cmd == MOVECOM)
               status = move (line3);
            else
               status = copy (line3);
         }
         else {
            status = ERR;
            Errcode = EEGARB;
         }
      }
      break;

   case SUBSTITUTE:
   case TLITCOM:
      if (ch == NEWLINE) {   /* turn "s\n" into "s//%/\n" */
         lin[i+0] = '/';
         lin[i+1] = '/';
         lin[i+2] = '%';
         lin[i+3] = '/';
         lin[i+4] = NEWLINE;
         lin[i+5] = EOS;
         Peekc = YES;
      }
      else {      /* try to handle "s/stuff\n" */
         missing_delim = YES;
         for (j = i + 1; lin[j] != NEWLINE; j++)
            if (lin[j] == ESCAPE && lin[j+1] == ch)
               j++;    /* skip esc, loop continues */
            else if (lin[j] == ch) {
               missing_delim = NO;
               break;  /* for */
            }

         if (missing_delim) {
            for (; lin[j] != EOS; j++)
               ;
            j--;       /* j now at newline */

            lin[j] = ch;   /* delim */
            lin[++j] = NEWLINE;
            lin[++j] = EOS;
            Peekc = YES;
            /* rest of routines will continue to fix up */
         }
      }

      if (cmd == SUBSTITUTE) {
         if (optpat (lin, &i) == OK
             && getrhs (lin, &i, sub, &gflag) == OK
             && lin[i + 1] == NEWLINE)
            status = subst (sub, gflag, glob);
      }
      else {
         if (getrange (lin, &i, Tlpat, MAXPAT, &allbut) == OK
             && makset (lin, &i, sub, MAXPAT) == OK
             && lin[i + 1] == NEWLINE)
            status = dotlit (sub, allbut);
      }
      break;

   case JOINCOM:
      if (getstr (lin, &i, sub, MAXPAT) == OK
          && lin[i + 1] == NEWLINE) {
         defalt (prevln (Curln), Curln);
         status = join (sub);
      }
      break;

   case UNDOCOM:
      flag = ckchar (UCDELCOM, DELCOM, lin, &i);
      if (lin[i] == NEWLINE)
         status = doundo (flag);

      break;

   case ENTERCOM:
      if (Nlines != 0)
         Errcode = EBADLNR;
      else if (ckupd (lin, &i, ENTERCOM) == OK) {
         tflag = ckchar (XTABS, UCXTABS, lin, &i);

         if (getfn (lin, i, file) == OK)
            status = doenter (file, tflag);
         else
            status = ERR;
      }
      break;

   case FILECOM:
      if (Nlines != 0)
         Errcode = EBADLNR;
      else if (ch == NEWLINE || ckchar ('+', '>', lin, &i)) {
         if (Buffer_changed)
            Errcode = ESTUPID;
         else
            status = new_filename ('+');
      }
      else if (ckchar ('-', '<', lin, &i)) {
         if (Buffer_changed)
            Errcode = ESTUPID;
         else
            status = new_filename ('-');
      }
      else if (getfn (lin, i, file) == OK) {
         set_filename (file);
         status = OK;
      }
      break;

   case READCOM:
      tflag = ckchar (XTABS, UCXTABS, lin, &i);

      if (getfn (lin, i, file) == OK) {
         status = doread (Line2, file, tflag);
      }

      break;

   case WRITECOM:
      flag = ckchar (APND1, APND2, lin, &i);       /* Append ? */

      if (flag == NO)
         fflag = ckchar (ANYWAY, ANYWAY, lin, &i); /* Force ? */
      else
         fflag = NO;

      tflag = ckchar (XTABS, UCXTABS, lin, &i);    /* Tabs ? */

      qflag = ckchar (QUITCOM, UCQUITCOM, lin, &i);   /* Quit ? */

      if (getfn (lin, i, file) == OK) {
         defalt (1, Lastln);
         status = dowrit (Line1, Line2, file, flag, fflag, tflag);
      }
      
      if (status == OK && qflag)      /* If all was well, quit  */ 
         status = EOF;                /* ...if we were asked to */
         
      break;

   case PRINT:
      if (ch == NEWLINE) {
         defalt (1, Topln);
         status = doprnt (Line1, Line2);
      }
      break;

   case PAGECOM:
      defalt (1, min (Lastln, Botrow - Toprow + Topln));

      if (Line1 <= 0)
         Errcode = EORANGE;
      else if (ch == NEWLINE) {
         Topln = Line2;
         Curln = Line2;
         First_affected = Line2;
         status = OK;
      }
      break;

   case NAMECOM:
   case MARKCOM:
      if (getkn (lin, &i, &kname, DEFAULTNAME) != ERR
          && lin[i] == NEWLINE) {
         if (cmd == NAMECOM)
            status = uniquely_name (kname);
         else
            status = domark (kname);
      }
      break;

   case NEWLINE:
      line3 = nextln (Curln);
      defalt (line3, line3);
      status = doprnt (Line2, Line2);
      break;

   case LOCATECOM:
      if (ch == NEWLINE) {
         mesg (sysname (), REMARK_MSG);
         status = OK;
      }
      break;

   case QUITCOM:
      if (Nlines != 0)
         Errcode = EBADLNR;
      else if (ckupd (lin, &i, QUITCOM) == OK) {
         if (lin[i] == NEWLINE)
            status = EOF;
         else
            status = ERR;
      }
      break;

   case OPTCOM:
      status = doopt (lin, i);
      break;

   case WINDCOM:
      status = dowind (lin, i);
      break;

   case HELPCOM:
      status = dohelp (lin, i);
      break;

   case MISCCOM:      /* Miscellaneous features */
      status = domisc (lin, i);
      break;

   case SHELLCOM:
      status = doshell (lin, i);
      break;

   default:
      Errcode = EWHATZAT;     /* Command not recognised */
      break;
   }

   if (status == OK)
      probation (EOS);     /* Clear the 'probation' flag */

   return (status);
}


/* ckchar --- look for ch or altch on lin at i, return 1 if found */

static bool ckchar (ch, altch, lin, i)
int ch, altch;
const uchar lin[];
int *i;
{
   if (lin[*i] == ch || lin[*i] == altch) {
      (*i)++;
      return (YES);
   }
   else
      return (NO);
}


/* ckupd --- make sure it is ok to destroy the buffer */

static int ckupd (lin, i, cmd)
const uchar lin[];
int *i;
int cmd;
{
   bool flag;
   int status;

   flag = ckchar (ANYWAY, ANYWAY, lin, i);
   status = OK;

   if (!flag && Buffer_changed && probation (cmd) == NO) {
      status = ERR;
      Errcode = ESTUPID;
   }

   return (status);
}


/* getstr --- get string from lin at i, copy to dst, bump i */

static int getstr (lin, i, dst, maxdst)
uchar *lin;
int *i;
uchar *dst;
int maxdst;
{
/*
 * NOTE: this routine only called for doing the join command.
 * therefore, don't do anything else with it.
 */
   uchar delim;
   int j, k, d;

   j = *i;
   Errcode = EBADSTR;

   delim = lin[j];

   if (delim == NEWLINE) {
      lin[j] = '/';
      lin[++j] = ' ';    /* join with a single blank */
      lin[++j] = '/';
      lin[++j] = NEWLINE;
      lin[++j] = EOS;
      j = *i;
      delim = lin[j];
      Peekc = YES;
      /* now fall thru */

      /* return (ERR);      old way */
   }

   if (lin[j + 1] == NEWLINE) {    /* command was 'j/' */
      dst[0] = EOS;
      Errcode = ENOERR;
      return (OK);
      /* return (ERR);      old way */
   }

   /*
    * otherwise, stuff there in the string, try to allow for
    * a missing final delimiter.
    */

   for (k = j + 1; lin[k] != NEWLINE; k++)
      ;       /* find end */

   k--;    /* now points to char before newline */

   if (lin[k] != delim || (lin[k-1] == ESCAPE && lin[k-2] != ESCAPE)) {
      /* no delim, or last char is escaped delim */
      k++;
      lin[k] = delim;
      lin[++k] = NEWLINE;
      lin[++k] = EOS;
      Peekc = YES;
   }
   /* else
      delim is there
      leave well enough alone */

   /* code to actually do the join */

   for (k = j + 1; lin[k] != delim; k++) {  /* find end */   
      if (lin[k] == NEWLINE || lin[k] == EOS) {
         if (delim == ' ')
            break;
         else
            return (ERR);
      }

      esc (lin, &k);
   }

   if (k - j > maxdst)
      return (ERR);

   for (d = 0, j++; j < k; d++, j++)
      dst[d] = esc (lin, &j);

   dst[d] = EOS;

   *i = j;
   Errcode = EEGARB;       /* the default */

   return (OK);
}
