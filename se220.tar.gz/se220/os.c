/* os --- operating system interface module                 03/08/1987 */

#include "se.h"
#include "extern.h"

#include <signal.h>

/*
 * Note: if the value of 'LIBDIR' is unsuitable for your system,
 * it can be overridden from the makefile with '-DLIBDIR=...'
 */

#if MSDOS
#include <dos.h>
#include <process.h>
#include <errno.h>
#include <time.h>

#if TCC
#include <dir.h>     /* We need 'findfirst' */
#include <io.h>      /* and '_chmod' */
#define FA_NORMAL    0x00
#endif

#define INTERNATIONAL_CALL    0x38
#define COMMIT_FILE           0x68

struct Nation {      /* Returned by International Call */
   unsigned int dtform; /* Date/time format    */
   uchar csym[5];       /* Currency symbol     */
   uchar thou[2];       /* Thousands separator */
   uchar deci[2];       /* Decimal point char. */
   uchar dsep[2];       /* Date separator      */
   uchar tsep[2];       /* Time separator      */
   uchar cflags;        /* Currency flags      */
   uchar cplaces;       /* Currency decimals   */
   uchar tflag;         /* 24 hour flag        */
   uchar casemap[4];    /* Case mapping call   */
   uchar lsep[2];       /* List separator      */
};

/* Novell NetWare Server Information block */
/* Note: some of the fields in this struct are integer values stored
   in 68000 byte order.  They have been declared as two-byte arrays
   to avoid word-alignment and to remind the user to swap the bytes */
struct ServerInfo {
   int Len;
   uchar ServName[48];
   uchar NetWareVer;
   uchar NetWareSub;
   uchar MaxConns[2];   /* 68000 byte order */
   uchar UsedConns[2];  /* 68000 byte order */
   uchar MaxVols[2];    /* 68000 byte order */
   uchar Revision;
   uchar SFTLevel;
   uchar TTSLevel;
   uchar PeakConn[2];   /* 68000 byte order */
   uchar AccountVer;
   uchar VAPVer;
   uchar QueueVer;
   uchar PrintServVer;
   uchar VirtualVer;
   uchar SecurityVer;
   uchar BridgeVer;
   uchar Reserved[60];
};

string Sopsys = "MS-DOS";     /* Export name of OS */
static struct Nation Nat;     /* National date/time info */

#if NO_PROTOTYPES

static void setlocal ();
#if IBMPC
static int netware ();
#endif   /* IBMPC */
static bool getvlab ();

#else

static void setlocal (struct Nation *);
#if IBMPC
static int netware (const void *, void *);
#endif   /* IBMPC */
static bool getvlab (char *);

#endif   /* NO_PROTOTYPES */

#endif   /* MSDOS */

#if MSWIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

string Sopsys = "Win32";     /* Export name of OS */
#endif


#if UNIX | LINUX
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/file.h>
#include <pwd.h>           /* For 'struct passwd' */

#if BSD4_2
#include <sys/time.h>
#else
#include <time.h>
#endif   /* BSD4_2 */

#ifndef LIBDIR
#define LIBDIR "/usr/local/lib"
#endif

/* Locate the directory that holds mailboxes */
#if BSD | LINUX
#define MAILBOX_DIRECTORY  "/usr/spool/mail/"   /* BSD style */
#else
#define MAILBOX_DIRECTORY  "/usr/mail/"         /* System V style */
#endif

/* Make your mind up about which shell to use... */
#if BSD
#define DEFAULT_PATH    "/bin/csh"     /* C-Shell */
#define DEF_SHELL       "csh"
#else
#define DEFAULT_PATH    "/bin/sh"      /* Bourne Shell */              
#define DEF_SHELL       "sh"
#endif   /* BSD */

#if USG | S5R2 | LINUX
#include <sys/utsname.h>        /* stuff to find out who we are */
#endif

#ifndef L_cuserid
#define L_cuserid (32)     /* Just in case it's not defined */
#endif

#if LINUX
string Sopsys = "Linux";      /* Export name of OS */
#else
string Sopsys = "UNIX";       /* Export name of OS */
#endif
#endif   /* UNIX | LINUX */

/* Fix a few bit-masks... */
#ifndef W_OK
#define W_OK     2
#endif

#ifndef R_OK
#define R_OK     4
#endif

#ifndef S_IWUSR
#define S_IWUSR  0200         /* Write permission bit for owner */
#endif

#ifndef S_IRUSR
#define S_IRUSR  0400         /* Read permission bit for owner */
#endif

#ifndef S_IWGRP
#define S_IWGRP  0020         /* Write permission bit for group */
#endif

#if MSDOS
static char shell[MAXLINE];
static char pstat = EOS;
static char tmp[MAXPATH] = "\\se_pipe.tmp";
static int sys_rc;
#endif

#if NO_PROTOTYPES
#ifdef LOG_USAGE
static void log_usage ();
#endif

#else    /* NO_PROTOTYPES */

#ifdef LOG_USAGE
static void log_usage (void);
#endif
#endif   /* NO_PROTOTYPES */


/* os_init --- initialise this module */

void os_init ()
{
#if MSDOS
   setlocal (&Nat);
   
   Dirsep = '\\';
   Filsep = '.';
#endif

#if MSWIN32
   Dirsep = '\\';
   Filsep = '.';
#endif

#if UNIX | LINUX
   Dirsep = '/';
   Filsep = '.';
#endif

#ifdef LOG_USAGE
   log_usage ();     /* Log who used the program */
#endif
}


/* get_time --- return the time as a structure */

void get_time (t)
struct TimeInfo *t;
{
#if UNIX | LINUX
   time_t clock;
   struct tm *now;

   time (&clock);
   now = localtime (&clock);

   t->Day = now->tm_mday;
   t->Month = now->tm_mon;
   t->Year = now->tm_year + 1900;
   t->Hour = now->tm_hour;
   t->Minute = now->tm_min;
   t->Second = now->tm_sec;
   t->WkDay = now->tm_wday;

   t->Tfh = YES;     /* Don't really know any of these... */
   t->DateFmt = DDMMYY;
   t->TimeSep = ':';
   t->DateSep = '/';
#endif   /* UNIX | LINUX */

#if MSDOS
/* 
 * MS-DOS knows about 12 hour or 24 hour time according to
 * nationality.  The call '_dos_gettime' is a Microsoft library
 * function that gives us the hours & minutes; we must test
 * the 24 hour flag before building the time string
 */
#if MSC
   struct dostime_t tm;
   struct dosdate_t dt;
   
   _dos_gettime (&tm);
   _dos_getdate (&dt);
   
   t->Day = dt.day;
   t->Month = dt.month - 1;
   t->Year  = dt.year;
   
   t->Hour = tm.hour;
   t->Minute = tm.minute;
   t->Second = tm.second;
   
   t->WkDay = dt.dayofweek;

   t->Tfh = Nat.tflag ? YES : NO;
   t->DateFmt = DDMMYY;
   t->TimeSep = Nat.tsep[0];
   t->DateSep = Nat.dsep[0];
#endif   /* MSC */
#if TCC
   struct time tm;
   struct date dt;
   
   gettime (&tm);
   getdate (&dt);
   
   t->Day   = dt.da_day;
   t->Month = dt.da_mon - 1;
   t->Year  = dt.da_year;
   
   t->Hour   = tm.ti_hour;
   t->Minute = tm.ti_min;
   t->Second = tm.ti_sec;
   
   t->WkDay = 0;  /* XXX */

   t->Tfh = YES;  /* XXX */
   t->DateFmt = DDMMYY;
   t->TimeSep = ':'; /* XXX */
   t->DateSep = '/'; /* XXX */
#endif   /* TCC */
#endif   /* MSDOS */

#if MSWIN32
   SYSTEMTIME buf;

   GetLocalTime (&buf);

   t->Day = buf.wDay;
   t->Month = buf.wMonth - 1;
   t->Year = buf.wYear;
   t->Hour = buf.wHour;
   t->Minute = buf.wMinute;
   t->Second = buf.wSecond;
   t->WkDay = buf.wDayOfWeek;

   t->Tfh = YES;     /* Must find out how to get these... */
   t->DateFmt = DDMMYY;
   t->TimeSep = ':';
   t->DateSep = '/';
#endif
}


/* isreadonly --- return YES if a file is read-only */

bool isreadonly (file)
const uchar *file;
{
#if MSDOS
/* 
 * MS-DOS has a simple 'read-only' bit that can be set to
 * prevent writing into a file.
 */
#if MSC
/* 
 * '_dos_getfileattr' is a Microsoft C
 * library call that returns file attribute bits.
 */
   unsigned int attrib;
   
   if (_dos_getfileattr ((char *)file, &attrib) != 0)
      return (NO);
      
   if (attrib & _A_RDONLY)
      return (YES);
   else
      return (NO);
#endif   /* MSC */
#if TCC
/* 
 * '_chmod' is a Borland Turbo C library
 * call that returns file attribute bits.
 */
   unsigned int attrib;
   
   attrib = _chmod ((char *)file, 0);
      
   if (attrib & FA_RDONLY)
      return (YES);
   else
      return (NO);
#endif   /* TCC */
#endif   /* MSDOS */

#if MSWIN32
   DWORD attrib;

   attrib = GetFileAttributes (file);

   if (attrib == 0xffffffff)
      return (NO);
   else
      return (attrib & FILE_ATTRIBUTE_READONLY);
#endif

#if UNIX | LINUX
/* 
 * UNIX has proper file protection
 */
   struct stat buf;
   
   if ((getuid () == 0) || (geteuid () == 0))
      return (NO);   /* Root can write *anything* ! */
      
   /* Check permissions for real user & group IDs */
   if (access ((char *)file, W_OK) == 0)
      return (NO);
      
   /* Now we need the actual protection bits... */
   if (stat ((char *)file, &buf) != 0)
      return (NO);
      
   /* Does the effective UID or GID give us any extra rights? */
   if ((buf.st_mode & S_IWUSR) && (buf.st_uid == geteuid ()))
      return (NO);
   else if ((buf.st_mode & S_IWGRP) && (buf.st_gid == getegid ()))
      return (NO);
   else
      return (YES);
#endif   /* UNIX | LINUX */
}


/* setreadonly --- set a file to read-only */

bool setreadonly (file, ro)
const uchar *file;
bool ro;
{
#if MSDOS
/* 
 * Simply set or clear the 'read-only' bit as required.
 */
#if MSC
/* 
 * Once again, '_dos_setfileattr' is a Microsoft library function.
 */
   unsigned int attrib;
   
   if (_dos_getfileattr (file, &attrib) != 0)
      return (NO);
      
   if (ro)
      attrib |= _A_RDONLY;
   else
      attrib &= ~(_A_RDONLY);

   if (_dos_setfileattr (file, attrib) == 0)
      return (YES);
   else
      return (NO);
#endif   /* MSC */
#if TCC
/* 
 * Once again, '_chmod' is a Borland library function.
 */
   unsigned int attrib;
   
   attrib = _chmod ((char *)file, 0);
      
   if (ro)
      attrib |= FA_RDONLY;
   else
      attrib &= ~(FA_RDONLY);

   _chmod ((char *)file, 1, attrib);

   return (YES);
#endif   /* TCC */
#endif   /* MSDOS */

#if MSWIN32
   if (SetFileAttributes (file, ro ? FILE_ATTRIBUTE_READONLY : FILE_ATTRIBUTE_NORMAL))
      return (YES);
   else
      return (NO);
#endif

#if UNIX | LINUX
   if (chmod ((char *)file, ro ? S_IRUSR : (S_IRUSR | S_IWUSR)) != 0)
      return (NO);
   else
      return (YES);
#endif   /* UNIX | LINUX */
}


/* sysname --- return the name of the host computer */

uchar *sysname ()
{
   static uchar unknown[] = "unknown";

#if V7
   return (unknown);
#endif   /* V7 */

#if MSDOS      /* CP/M-like */
/* 
 * There's no proper machine name in MS-DOS, so we return
 * the volume label of the current disk.  If we're lucky,
 * it will be set to a sensible name.
 */
   static char buf[65] = "";

   if (getvlab (buf))      /* See if there's a volume label */
      return ((uchar *)buf);
   else
      return (unknown);
#endif   /* MSDOS */

#if MSWIN32
   static char buf[MAX_COMPUTERNAME_LENGTH + 1];
   DWORD nb;

   nb = MAX_COMPUTERNAME_LENGTH;

   if (GetComputerName (buf, &nb) == FALSE)
      return (unknown);
   else
      return (buf);
#endif

#if USG | S5R2 | LINUX     /* System V-like */
   static struct utsname whoarewe;

   if (uname (&whoarewe) != 0)
      return (unknown);
   else
      return ((uchar *)whoarewe.nodename);
#endif   /* USG | S5R2 | LINUX */

#if BSD4_2   /* Berkeley 4.2 */
   static uchar buf[MAXLINE] = "";
   int j;

   if (buf[0] != EOS)       /* Been called before ? */
      return (buf);

   j = sizeof (buf);
   if (gethostname (buf, &j) == 0)
      return (buf);
   else
      return (unknown);
#else
#if BSD   /* Berkeley 4.1 */
   static char buf[MAXLINE] = "";
   int i;
   int c;
   FILE *fp;
   char *cp;

   if (buf[0] != EOS)
      return (buf);

   if ((fp = fopen ("/usr/include/whoami.h", READ)) == NULL)
      return (unknown);
   else {
      /*
       * file should contain a single line:
       * #define sysname "......"
       */
      while ((c = getc (fp)) != '"' && c != EOF)
         ;

      if (c == EOF)
         cp = unknown;
      else {
         for (i = 0; (c = getc (fp)) != '"' && c != EOF; i++)
            buf[i] = c;
         buf[i] = EOS;
         if (c == EOF && i == 0)
            cp = unknown;
         else
            cp = buf;
      }

      fclose (fp);

      return (cp);
   }
#endif   /* BSD */
#endif   /* BSD4_2 */
}


/* usrname --- return the name of the user */

uchar *usrname ()
{
   static uchar *p = NULL;

#if UNIX | LINUX
#if BSD
   char *getlogin ();

   if (p == NULL)
      p = (uchar *)getlogin ();
#else
   static char buf[L_cuserid];
   char *cuserid ();    /* This function may go away in POSIX */

   if (p == NULL)
      p = (uchar *)cuserid (buf);
#endif   /* BSD */

#else
#if MSWIN32
   static char buf[256];
   DWORD nb;

   nb = 256;

   if (GetUserName (buf, &nb) == FALSE)
      p = (uchar *)"unknown";
   else
      p = buf;
#else
   if (p == NULL) {
      if ((p = (uchar *)getenv ("USER")) == NULL)
         p = (uchar *)"unknown";
   }
#endif   /* MSWIN32 */
#endif   /* UNIX | LINUX */

   return (p);
}


/* shell_open --- open a file to/from a pipe */

FILE *shell_open (cmd, mode)
const uchar *cmd;
const char *mode;
{
#if MSDOS
   FILE *fp;
   
   switch (mode[0]) {
   case 'r':
   case 'R':
      sprintf (shell, "%s >%s", cmd, tmp);
      sys_rc = system (shell); 
      pstat = 'r';
      fp = fopen (tmp, READ);
      break;
   case 'w':
   case 'W':
      sprintf (shell, "%s <%s", cmd, tmp);
      pstat = 'w';
      fp = fopen (tmp, WRITE);
      break;
   default:
      fp = NULL;
      break;
   }
   
   return (fp);
#endif   /* MSDOS */

#if MSWIN32
   return (NULL);
#endif

#if UNIX | LINUX
   return (popen ((char *)cmd, mode));
#endif
}


/* shell_close --- close the pipe opened by 'shell_open' */

int shell_close (fp)
FILE *fp;
{
#if MSDOS
   switch (pstat) {
   case EOS:
      return (-1);
      break;
   case 'r':
      fclose (fp);
      unlink (tmp);
      break;
   case 'w':
      fclose (fp);
      sys_rc = system (shell);
      unlink (tmp);
      break;
   }

   pstat = EOS;
   return (sys_rc);
#endif   /* MSDOS */

#if MSWIN32
   return (-1);
#endif

#if UNIX | LINUX
   return (pclose (fp));
#endif
}


#if UNIX | LINUX

/* gethomedir --- return name of user's home directory */

uchar *gethomedir (user)
const uchar *user;
{
   struct passwd *p;

   if (*user == EOS)
      p = getpwuid (getuid ());
   else
      p = getpwnam ((char *)user);
      
   if (p == NULL)
      return (NULL);
   else
      return ((uchar *)p->pw_dir);
}

#endif   /* UNIX | LINUX */


#if MSDOS

/* getvlab --- read the volume label */

static bool getvlab (str)
register char *str;
{
#if MSDOS
#if MSC
   struct find_t buf;
#endif
#if TCC
   struct ffblk buf;
#endif
   char *ep;
#if IBMPC
   struct ServerInfo serv;
   struct Request {
      int Len;
      uchar SubF;
   } req;

   /* First get the Novell NetWare file server name */
   req.Len = 1;
   req.SubF = 0x11;
   
   serv.Len = sizeof (struct ServerInfo);
   serv.NetWareVer = 0xff;
   serv.NetWareSub = 0xff;
   
   netware (&req, &serv);

   if (serv.NetWareVer != 0xff && serv.NetWareSub != 0xff) {
      struncpy (str, serv.ServName, 48);
      strcat (str, "\\");
   }
   else              /* No NetWare, so no file server name */
      str[0] = EOS;
#else
   /* Don't bother with networks on the Sirius... */
   str[0] = EOS;
#endif   /* IBMPC */
      
   /* Now append the volume label */
#if MSC
   if (_dos_findfirst ("*.*", _A_VOLID, &buf) == 0) {
      if ((ep = strchr (buf.name, '.')) != NULL) {
         *ep = EOS;                /* Get rid of dot in middle of filename */
         strcat (str, buf.name);
         strcat (str, ++ep);
      }
      else                         /* Too short to have a dot */
         strcat (str, buf.name);
   }
#endif   /* MSC */
#if TCC
   if (findfirst ("*.*", &buf, FA_LABEL) == 0) {
      if ((ep = strchr (buf.ff_name, '.')) != NULL) {
         *ep = EOS;                /* Get rid of dot in middle of filename */
         strcat (str, buf.ff_name);
         strcat (str, ++ep);
      }
      else                         /* Too short to have a dot */
         strcat (str, buf.ff_name);
   }
#endif   /* TCC */
   
   return (*str != EOS);
#endif   /* MSDOS */
}

#endif   /* MSDOS */


#if MSDOS

/* setlocal --- set local date/time format */

static void setlocal (p)
struct Nation *p;
{
   union REGS r;
   struct SREGS s;
   
   if (_osmajor >= 3) {    /* Ask the OS */
      segread (&s);
      r.h.ah = INTERNATIONAL_CALL;
      r.h.al = 0;
      r.x.dx = FP_OFF (p);
      s.ds   = FP_SEG (p);
      intdosx (&r, &r, &s);
   }
   else {                  /* Set up some defaults */
      p->tsep[0] = ':';       /* Use ':' for time separator */
      p->tsep[1] = EOS;
      p->tflag   = YES;       /* Use 24 hour time           */
   }
}


#if IBMPC

/* netware --- call Novell NetWare via INT 21 */

static int netware (req, buf)
const void *req;
void *buf;
{
   union REGS r;
   struct SREGS s;
   
   segread (&s);
   
   r.h.ah = 0xe3;          /* Call NetWare via INT 21H, function E3H */

   s.ds   = FP_SEG(req);   /* DS:SI -> request packet */
   r.x.si = FP_OFF(req);

   s.es   = FP_SEG(buf);   /* ES:DI -> reply packet */
   r.x.di = FP_OFF(buf);

   intdosx (&r, &r, &s);

   return (0);
}

#endif   /* IBMPC */

#endif   /* MSDOS */


/* call_shell --- invoke command interpreter with optional command line */

int call_shell (cmdlin)
const uchar *cmdlin;
{
   int forkstatus;   /* Status of invokation of the shell      */
   int childstatus;  /* Status of command run from shell, nonzero == ERR */

#if UNIX | LINUX
   int i;
   void (*save_quit)(), (*save_int)();
   char *path, *name, *p;
   uchar buf[MAXLINE];

   /* UNIX -- fork off a new process */
   
   if ((p = getenv ("SHELL")) == NULL || strcmp (p, DEFAULT_PATH) == 0) {
      path = DEFAULT_PATH;
      name = DEF_SHELL;       /* default */
   }
#if BSD
   /* on Berkeley systems, check the other shell */
   else if (strcmp (p, "/bin/sh") == 0) {
      path = "/bin/sh";
      name = "sh";
   }
#endif
   else {
      if (p[0] == Dirsep) {      /* full pathname there */
         path = p;             /* work backwards to find just name */
         i = strlen (p);
         while (p[i] != Dirsep)
            i--;

         i++;       /* skip '/' */
         name = &p[i];
      }
      else {
         sprintf ((char *)buf, "unknown shell, using %s", DEF_SHELL);
         mesg (buf, REMARK_MSG);
         path = DEFAULT_PATH;
         name = DEF_SHELL;
      }
   }

   forkstatus = fork ();

   if (forkstatus == -1) {    /* the fork failed */
      Errcode = ECANTFORK;
      return (ERR);
   }

   if (forkstatus == 0) {     /* we're in the child process */
      signal (SIGINT, SIG_DFL);
      signal (SIGQUIT, SIG_DFL);

#if BSD
      if (strcmp (name, "sh") != 0)   /* not /bin/sh */
         signal (SIGTSTP, SIG_DFL);
      else
         signal (SIGTSTP, SIG_IGN);
#endif

      if (*cmdlin == EOS) {      /* No params; run a shell */
         execl (path, name, 0);
         _exit (EXIT_FAILURE);         /* exec failed, notify parent */
      }
      else {
         execl (path, name, "-c", cmdlin, 0);
         _exit (EXIT_FAILURE);         /* exec failed, notify parent */
      }
   }

   /* we're in the parent process here */
   save_int = signal (SIGINT, SIG_IGN);   /* ignore interrupts */
   save_quit = signal (SIGQUIT, SIG_IGN);

   while (wait (&childstatus) != forkstatus)
      ;

   save_int = signal (SIGINT, save_int);       /* catch interupts */
   save_quit = signal (SIGQUIT, save_quit);

   if ((childstatus >> 8) != 0) {
      Errcode = ENOSHELL;
      return (ERR);
   }
   
#endif   /* UNIX | LINUX */
   
#if MSDOS
   char *op;             /* Old DOS prompt                */   
   char *np;             /* New prompt MUST be malloc()ed */
   char *p;

   if (*cmdlin == EOS) {
      np = malloc (80); /* Dynamic space for new prompt */
      op = malloc (80);
      
      if (op != NULL && np != NULL) {
         strcpy (np, "PROMPT=");
         strcpy (op, "PROMPT=");

         if ((p = getenv ("PROMPT")) == NULL) {
            strcat (np, "[1] $n$g");     /* [1] A> */
            strcat (op, "$n$g");         /* A> */
         }
         else {                  /* User already has a prompt */
            
            if (p[0] == '[' && p[2] == ']') { /* Assume 'se' set it */
               strcat (np, p);               
               np[8]++;
            }
            else {                              /* Prepend '[1] ' */
               strcat (np, "[1] ");
               strcat (np, p);
            }
            
            strcat (op, p);
         }
            
         putenv (np);      /* Temporary prompt with [n] */
      }

      forkstatus = spawnl (P_WAIT, getenv ("COMSPEC"), "command", NULL);

      if (op != NULL && np != NULL) {
         putenv (op);   /* Restore original prompt */
         free (op);
         free (np);
      }
   }
   else
      forkstatus = system ((char *)cmdlin);

   /* Did the 'fork' fail ? */
   if (forkstatus == -1) {
      if (errno == ENOMEM || errno == E2BIG)
         Errcode = ECANTFORK;
      else
         Errcode = ENOSHELL;
         
      return (ERR);
   }

   childstatus = forkstatus;

#endif   /* MSDOS */

#if MSWIN32
   forkstatus = childstatus = -1;
#endif

   /* Now look at the return value of the child process */
   if (childstatus != 0) {
      Errcode = ESHELLERR;
      return (ERR);
   }

   return (OK);
}


/* mswait --- message waiting subroutine */

void mswait ()
{
/* Should be some MSDOS code here to work on NetWare... */
#if UNIX | LINUX
/*
 * If the user wants to be notified, and the mail file is readable,
 * and there is something in it, then he is given the message.   
 * The 'om' command toggles Notify, controlling notification.
 */
   struct stat buf;
   struct passwd *p;
   static char *mbox = NULL;
   static bool first = YES;
   static unsigned long mtime = 0L;
   static char fname[MAXPATH] = MAILBOX_DIRECTORY;

   if (! Notify)
      return;

   if (first) {
      first = NO;
      mbox = getenv ("MAIL");
      if (mbox == NULL) {
         p = getpwuid (getuid ());

         if (p != NULL)
            strcat (fname, p->pw_name);

         mbox = fname;
      }
      
      if (access (mbox, R_OK) == 0) {
         if (stat (mbox, &buf) >= 0) {
            mtime = buf.st_mtime;

            if (buf.st_size > 0)
               msgstr (SHAVEMAIL, REMARK_MSG);
         }
      }
   }
   else if (stat (mbox, &buf) >= 0 && buf.st_mtime > mtime) {
      mtime = buf.st_mtime;
      if (buf.st_size != 0L) {      /* Empty file means no mail */
         msgstr (SNEWMAIL, REMARK_MSG);
         ringbell (MAIL_BELL);
      }
   }
#endif   /* UNIX | LINUX */
}


/* getsefile --- search for 'se's standard files */

bool getsefile (type, path)
int type;
uchar *path;
{
   register int i;
   char names[5][MAXPATH];
   char *svar = NULL;
   char *file = NULL;
   char *e;
#if MSDOS | MSWIN32
   char boot;
#endif
   
   /* Start with all names null */
   for (i = 0; i < 5; i++)
      names[i][0] = EOS;
      
   /* Set up environment variable name and file base name */
   switch (type) {
   case SERC_FILE:
      svar = "SE_RC";
#if MSDOS | MSWIN32
      file = "se.rc";
#endif
#if UNIX | LINUX
      file = ".serc";
#endif
      break;
   case MESG_FILE:
      svar = "SE_MSG";
#if MSDOS | MSWIN32
      file = "se.msg";
#endif
#if UNIX | LINUX
      file = "se.msg";
#endif
      break;
   case HELP_FILE:
      svar = "SE_HLP";
#if MSDOS | MSWIN32
      file = "se.hlp";
#endif
#if UNIX | LINUX
      file = "se.hlp";
#endif
      break;
   case TEMP_FILE:
      svar = "SE_TMP";
      file = "se.tmp";
      break;
   }

   /* Look for a specific environment variable */
   if ((e = getenv (svar)) != NULL)
      sprintf (names[0], "%s", e);

   /* Look for the file in the current directory */
   sprintf (names[1], "%s", file);
   
   /* Look in the 'se' directory */
   if ((e = getenv ("SE")) != NULL)
      sprintf (names[2], "%s%c%s", e, Dirsep, file);
   
   /* Look in the home directory */
   if ((e = getenv ("HOME")) != NULL)
      sprintf (names[3], "%s%c%s", e, Dirsep, file);
   
   /* Look in the system-wide default place */
#if MSDOS | MSWIN32
   if ((e = getenv ("COMSPEC")) != NULL)  /* Get boot drive letter */
      boot = *e;
   else
      boot = 'C';

   sprintf (names[4], "%c:%c%s", boot, Dirsep, file);
#endif

#if UNIX | LINUX
   sprintf (names[4], "%s%c%s", LIBDIR, Dirsep, file);
#endif

#ifdef DB
   for (i = 0; i < 5; i++)
      printf ("%d: %s\n", i, names[i]);

   gets (path);
#endif
   
   /* Find that file... */
   for (i = 0; i < 5; i++) {
      if (names[i][0] == EOS)
         continue;
         
      if (file_exists ((uchar *)names[i])) {
         (void)strucpy (path, names[i]);
         return (YES);
      }
   }

   return (NO);
}


/* file_exists --- test for existance of a file */

bool file_exists (file)
const uchar *file;
{
#if MSDOS
#if MSC
   struct find_t buf;

   if (_dos_findfirst ((char *)file, _A_NORMAL, &buf) == 0)
      return (YES);
#endif /* MSC */
#if TCC
   struct ffblk buf;

   if (findfirst ((char *)file, &buf, FA_NORMAL) == 0)
      return (YES);
#endif /* TCC */
#endif

#if MSWIN32
   WIN32_FIND_DATA buf;
   HANDLE h;

   if ((h = FindFirstFile (file, &buf)) != INVALID_HANDLE_VALUE) {
      FindClose (h);
      return (YES);
   }
#endif

#if UNIX | LINUX
   struct stat buf;
   
   if (stat ((char *)file, &buf) == 0)
      return (YES);
#endif

   return (NO);
}


/* getflen --- return length of a file in bytes */

long int getflen (file)
const uchar *file;
{
#if MSDOS
#if MSC
   struct find_t buf;
   
   if (_dos_findfirst ((char *)file, _A_NORMAL, &buf) != 0)
      return (-1L);
   else
      return (buf.size);
#endif   /* MSC */
#if TCC
   struct ffblk buf;
   
   if (findfirst ((char *)file, &buf, FA_NORMAL) != 0)
      return (-1L);
   else
      return (buf.ff_fsize);
#endif   /* TCC */
#endif   /* MSDOS */

#if MSWIN32
   WIN32_FIND_DATA buf;
   HANDLE h;

   h = FindFirstFile (file, &buf);

   FindClose (h);

   return (buf.nFileSizeLow);
#endif

#if UNIX | LINUX
   struct stat buf;
   
   if (stat ((char *)file, &buf) != 0)
      return (-1L);
   else
      return (buf.st_size);
#endif   /* UNIX | LINUX */
}


/* commit_file --- ensure file blocks are actually written to disk */

void commit_file (fp)
FILE *fp;
{
#if MSDOS
   union REGS r;
#endif
   filedes fd;
   
   fd = fileno (fp);
   
#if UNIX
   fsync (fd);
#endif

#if MSDOS
   /* In MS-DOS 3.30 or higher, we can do this */
   if (_osmajor > 3 || (_osmajor == 3 && _osminor > 30)) {
      r.h.ah = COMMIT_FILE;
      r.x.bx = fd;
   
      intdos (&r, &r);
   }
#endif   /* MSDOS */
}


/* sync_disk --- flush file system buffers */

void sync_disk ()
{
#if UNIX | LINUX
   /* Sync the file system */
   sync ();
#endif
}


#ifdef LOG_USAGE

/* log_usage --- log se usage */

static void log_usage ()
{
/*
 * This code has little chance of working under MSDOS
 */
#if MSDOS | MSWIN32
   static char logfile[] = "C:\\se.log";        /* a file */
#endif

#if UNIX | LINUX
   static char logfile[] = "/u/bj/se.log";      /* a public file */
#endif

   char tod[26];    /* tod => time of day */
   uchar ver[MAXLINE];
   time_t clock;
   FILE *fp;
#if UNIX | LINUX
   int old_umask;
#endif

   time (&clock);
   strcpy (tod, ctime (&clock));    /* See the manual on ctime(3C)  */
   tod[24] = EOS;                   /* Delete the NEWLINE at the end */

#if UNIX | LINUX
   old_umask = umask (0);     /* Allow writes for everyone        */
#endif                        /* when first call creates the file */

   if ((fp = fopen (logfile, APPEND)) != NULL) {
      verstr (ver);       /* All ok, write out statistics */
      fprintf (fp, "%s@%s: se %s: %s\n", usrname (), sysname (), ver, tod);
      fclose (fp);
   }
   /* else
      don't do anything */

#if UNIX | LINUX
   umask (old_umask);
#endif
}
#endif   /* LOG_USAGE */
