/* poo --- test 'se' on C++ */
// New-style comment

#define JUNK (0)

// Test comments-in-preproc feature
#define TAG /* in-line */ (42) /* suffix */
#define TAG2 /* in-line */ (43) // suffix

const int MAXPOO = 1000;

class bogus {
public:
   int m_mint;
protected:
   long int m_int;
private:
   char m_kint;
   
public:
   bogus::bogus ();
   bogus::~bogus ();
   bogus bogus::operator+ (bogus a, bogus b);
};

void do_int_routine ()
{
   int do_it;
   int int_vec;
   long int int21vec;
   int do1loop;
   char *aint;
   char *bint;
   bogus *kint;
   char *lint;
   char *mint;
   char *nint;
   char *zint;
   long int long_int;
   long int longint;
   
   kint = new bogus;
   
   do {
      do1loop = 42;
      if (long_int)
         mint = 42;

   } while (do_it);
   
   delete kint;
}
