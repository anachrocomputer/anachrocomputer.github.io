/* poo --- test 'se' with some Java code                    05/11/2000 */

import java.awt.*;

class poo {    // a bogus class definition
   private String message;
   protected int x, y;
   
   public static void main (String args[])
   {
      System.out.println ("Hello, world");
   }
}
