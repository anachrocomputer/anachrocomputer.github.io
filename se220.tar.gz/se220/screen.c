#ifdef RCS_ID
static char RCSid[] = "$Header: screen.c,v 2.08 89/06/14 15:00:00 BJ Exp $";
#endif

/*
 * $Log:        screen.c,v $
 * Revision 2.08 89/06/14  15:00:00  BJ
 * Made 'fixscreen ()' static
 *
 * Revision 2.0  87/09/14  19:15:00  BJ
 * Moved all code associated with 'getcmd ()' to 'getcmd.c'
 * Improved modularity; added 'screen_init ()'
 *
 * Revision 1.3  86/07/17  17:22:19  arnold
 * Senddelay() moved to term.c, where it belongs.
 *
 * Revision 1.2  86/05/27  17:46:46  osadr
 * Fix for early 4.2 BSD systems to use <sys/time.h> instead of <time.h>.
 *
 * Revision 1.1  86/05/06  13:38:18  osadr
 * Initial revision
 *
 */

/*
 * screen.c
 *
 * screen handling functions for the screen editor.
 */


#include "se.h"
#include "extern.h"


#define LEGAL     0x01
#define FIRST     0x02

struct Node {
   uchar *kw;
   struct Node *next;
};

static struct Node *Kws[256];
static int Kflg[256];


#if NO_PROTOTYPES
static struct Node *mknode ();
static bool kwlookup ();
static void scan_text ();
static void fixscreen ();
#else
static struct Node *mknode (const uchar *, const struct Node *);
static bool kwlookup (const uchar *);
static void scan_text (bool, const uchar *, int);
static void fixscreen (void);
#endif

/* screen_init --- initialise this module */

void screen_init ()
{
   register int i;
   
   for (i = 0; i < 256; i++) {
      Kws[i] = NULL;
      Kflg[i] = 0;
   }
}


/* setscreen --- set up screen parameters */

void setscreen ()
{
   Toprow = 0;
   Botrow = Nrows - 3;  /* 1 for 0-origin, 1 for status, 1 for cmd */
   Cmdrow = Botrow + 1;
   Topln = 1;
   Sclen = -1;          /* Make sure we assume nothing on the screen */
}


/* installkw --- install a reserved word */

int installkw (kw)
const uchar *kw;
{
   int let, let2;
   register struct Node *p;
   register struct Node *q;
   
   let = *kw & 0xff;
   if (islower (let))
      let2 = toupper (let);
   else if (isupper (let))
      let2 = tolower (let);
   else
      let2 = let;
   
   Kflg[let] |= FIRST;
   Kflg[let2] |= FIRST;
   
   for (p = Kws[let], q = NULL;
         p != NULL && strucmpi (p->kw, kw) < 0; p = p->next)
      q = p;
      
   if (q == NULL) {
      Kws[let] = mknode (kw, Kws[let]);
      Kws[let2] = Kws[let];
   }
   else
      q->next = mknode (kw, q->next);
      
   return (OK);   /* Should really check return value of 'mknode' */
}


/* setlegal --- set up the array of legal characters */

void setlegal (abbr)
const uchar *abbr;   /* Abbreviated list of legal chars in identifiers */
{
   uchar full[MAXLINE]; /* Fully expanded version of above */  
   int i, j;
   
   /* Expand the abbreviated list */
   i = j = 0;
   filset (EOS, abbr, &i, full, &j, MAXLINE);
   
   full[j] = EOS;
   
   /* Set the 'LEGAL' bit on each letter in 'full' */
   for (i = 0; full[i] != EOS; i++)
      Kflg[full[i] & 0xff] |= LEGAL;
}


/* mknode --- allocate a node in the reserved word list */

static struct Node *mknode (kw, next)
const uchar *kw;
const struct Node *next;
{
   register struct Node *n;
   register uchar *p;

   if ((n = (struct Node *)malloc (sizeof (struct Node))) == NULL ||
       (p = (uchar *)malloc (strulen (kw) + 1)) == NULL)
      return (NULL);
      
   n->next = (struct Node *)next;
   n->kw = strucpy (p, kw);
   
   return (n);
}


/* kwlookup --- look up a keyword in the linked-list */

static bool kwlookup (word)
const uchar *word;
{
   int let;
   register int cmp;
   register struct Node *p;

   let = *word & 0xff;
      
   for (p = Kws[let]; p != NULL; p = p->next) {
      cmp = strucmpi (p->kw, word);
      
      if (cmp == 0)
         return (YES);
      else if (cmp > 0)
         return (NO);
   }
   
   return (NO);
}


/* clearkws --- forget all reserved words */

void clearkws ()
{
   register int i;
   register struct Node *p, *next;
   
   for (i = 0; i < 256; i++) {
      if ((i < 'a') || (i > 'z')) { /* Kludge to avoid freeing twice */
         for (p = Kws[i]; p != NULL; p = next) {
            next = p->next;
            free (p->kw);     /* Free the string */
            free (p);         /* Free the node itself */
         }
      }
      
      Kws[i] = NULL;
      Kflg[i] = 0;
   }
}


/* clrrow --- clear out all of a row except the bar */

void clrrow (row)
register int row;
{
   loadstr ((uchar *)"", row, 0, BARCOL - 1, LNUM_ZONE);
   load (BARSYM, row, BARCOL, BAR_ZONE);
   loadstr ((uchar *)"", row, BARCOL + 1, Ncols - 1, TEXT_ZONE); 
}


/* updscreen --- update screen from edit buffer */

void updscreen ()
{
   uchar linestr[10];
   uchar txt[MAXLINE];
   register int line, row;
   register LINEDESC *k;
   register int i;
   static string dot = ".  ->";  /* The 'rocket' */
   static string one = "1";
   static string dol = "$";

   if (hwinsdel ())
      fixscreen ();   /* Do line insert/delete scrolling */
   
   if (Src_mode)
      fixcomments (First_affected, NO);

   line = Topln;
   k = getind (line);

   for (row = Toprow; row <= Botrow; row++) {
      if (line > Lastln || line < 1)      /* Empty line */
         clrrow (row);
      else {            /* Update the line number field */  
         if (line == Curln)
            loadstr (dot, row, 0, NAMECOL - 1, LINE_ZONE);
         else if (line == 1)
            loadstr (one, row, 0, NAMECOL - 1, ONE_ZONE);      
         else if (line == Lastln)
            loadstr (dol, row, 0, NAMECOL - 1, DOL_ZONE);   
         else if (!Absnos && row <= 25) {
            linestr[0] = Rel_a + row;
            linestr[1] = EOS;
            loadstr (linestr, row, 0, NAMECOL - 1, LNUM_ZONE);
         }
         else {         /* Simple numeric line number */
            sprintf ((char *)linestr, "%d", line);
            loadstr (linestr, row, 0, NAMECOL - 1, LNUM_ZONE);
         }

         /* Update the markname and bar column */
         load (GetMarkName (k), row, NAMECOL, MARK_ZONE);
         load (BARSYM, row, BARCOL, BAR_ZONE);

         /* Now see if we need to update the text */
         if (line >= First_affected) {
            if (Firstcol >= GetLength (k))
               loadstr ((uchar *)"", row, POOPCOL, Ncols - 1, TEXT_ZONE);
            else {
               gtxt (k, txt);

               if (Src_mode)
                  scan_text (k->Iscmnt, txt, row);
               else
                  loadstr (&txt[Firstcol], row, POOPCOL, Ncols - 1, PLAIN_ZONE);
            }
         }
      }

      line++;
      k = NEXTLINE(k);
   }

   First_affected = Lastln;

   /* Patch up the 'Scline' array for line insert/delete */
   Sctop = Topln;
   Sclen = Botrow - Toprow + 1;

   for (i = 0; i < Sclen; i++)
      Scline[i] = Sctop + i <= Lastln ? i : -1;
}


/* scan_text --- detect comments, quotes & reserved words */

static void scan_text (cmnt, p, row)
bool cmnt;
register const uchar *p;
int row;
{
   int otl = strulen (Ot), ctl = strulen (Ct);
   int ocl = strulen (Oc1), ccl = strulen (Cc1);
   int oc2l = strulen (Oc2), cc2l = strulen (Cc2);
   int opl = strulen (Op), cpl = strulen (Cp);
   uchar lin[MAXLINE];
   int i, j;
   uchar q = '"';    /* This is the quote we're looking for */
   int z;            /* The zone we started in */
   int zone;         /* The zone we're switching into next */
   int prev_zone;    /* The zone we were in before */
   int col1;         /* Column number within the text line */
   int col2;         /* Column number on se's screen display */

   if (cmnt) {
      zone = CMNT1_ZONE;
      prev_zone = CODE_ZONE;
   }
   else if ((otl != 0) && (ctl != 0)) {
      zone = TEXT_ZONE;
      prev_zone = CODE_ZONE;
   }
   else {
      zone = CODE_ZONE;
      prev_zone = CODE_ZONE;
   }
   
   /* Scan text looking for quotes and comment symbols */
   for (col1 = 0, col2 = POOPCOL; *p != EOS && col2 < Ncols; ) {
      j = 0;
      z = zone;
      
      switch (zone) {
      case TEXT_ZONE:
         while (*p != EOS) {
            if (*p == *Ot && struncmp (p, Ot, otl) == 0) {  
               zone = CODE_ZONE;
               break;
            }
            
            lin[j++] = *p++;
         }
         
         lin[j] = EOS;
         break;

      case CODE_ZONE:
         while (*p != EOS) {
            if (*p == Q1 || *p == Q2) {
               zone = STRING_ZONE;
               q = *p;
               break;
            }
            else if (*p == *Ct && struncmp (p, Ct, ctl) == 0) {
               zone = TEXT_ZONE;
               break;
            }
            else if (*p == *Op && struncmp (p, Op, opl) == 0) {
               zone = PREPROC_ZONE;
               break;
            }
            else if (*p == *Oc1 && struncmp (p, Oc1, ocl) == 0) {
               prev_zone = CODE_ZONE;
               zone = CMNT1_ZONE;
               break;
            }
            else if (*p == *Oc2 && struncmp (p, Oc2, oc2l) == 0) {
               prev_zone = CODE_ZONE;
               zone = CMNT2_ZONE;
               break;
            }
            else if (Kflg[*p] & FIRST) {
               zone = BOLD_ZONE;
               break;
            }
            
            lin[j++] = *p++;
         }
         
         lin[j] = EOS;

         /* Copy close tag symbol */
         if ((*p != EOS) && (zone == TEXT_ZONE)) {
            strucat (lin, Ct);
            p += ctl;
            j += ctl;
         }

         break;

      case BOLD_ZONE:
         lin[j++] = *p++;

         while (*p != EOS) {
            if ((Kflg[*p] & LEGAL) == 0) {
               zone = CODE_ZONE;
               break;
            }
            
            lin[j++] = *p++;
         }
         
         lin[j] = EOS;

         /* Is this word a reserved word ? */
         if (!kwlookup (lin))
            z = CODE_ZONE;

         break;

      case STRING_ZONE:
         /* Copy initial quote */
         lin[j++] = *p++;

         /* Scan past quoted text */
         while (*p != EOS) {
            if (*p == q || *p == NEWLINE) {
               zone = CODE_ZONE;
               break;
            }
            
            lin[j++] = *p++;
         }

         /* Copy final quote */
         if (*p == q)
            lin[j++] = *p++;
      
         lin[j] = EOS;
         break;

      case PREPROC_ZONE:
         lin[j++] = *p++;

         while (*p != EOS) {
            if (*p == *Cp && struncmp (p, Cp, cpl) == 0) {
               zone = CODE_ZONE;
               break;
            }
            else if (*p == *Oc1 && struncmp (p, Oc1, ocl) == 0) {
               prev_zone = PREPROC_ZONE;
               zone = CMNT1_ZONE;
               break;
            }
            else if (*p == *Oc2 && struncmp (p, Oc2, oc2l) == 0) {
               prev_zone = PREPROC_ZONE;
               zone = CMNT2_ZONE;
               break;
            }
            
            lin[j++] = *p++;
         }
      
         lin[j] = EOS;

         /* Copy close pre-proc symbol */
         if ((*p != EOS) && (zone == CODE_ZONE)) {
            strucat (lin, Cp);
            p += cpl;
            j += cpl;
         }

         break;
         
      case CMNT1_ZONE:
         lin[j++] = *p++;
         
         /* Scan through comment text */
         while (*p != EOS) {
            if (*p == *Cc1 && struncmp (p, Cc1, ccl) == 0) {
               zone = prev_zone;
               break;
            }
            
            lin[j++] = *p++;
         }

         lin[j] = EOS;

         /* Copy close comment symbol */
         if (*p != EOS) {
            strucat (lin, Cc1);
            p += ccl;
            j += ccl;
         }

         break;
      case CMNT2_ZONE:
         lin[j++] = *p++;
         
         /* Scan through comment text */
         while (*p != EOS) {
            if (*p == *Cc2 && struncmp (p, Cc2, cc2l) == 0) {
               zone = prev_zone;
               break;
            }
            
            lin[j++] = *p++;
         }

         lin[j] = EOS;

         /* Copy close comment symbol */
         if (*p != EOS) {
            strucat (lin, Cc2);
            p += cc2l;
            j += cc2l;
         }

         break;
      }  /* switch */

      /* Worry about 'olm' */
      if (col1 >= Firstcol) {
         loadstr (lin, row, col2, col2 + j - 1, z);
         col2 += j;
      }
      else if (col1 + j > Firstcol) {
         i = Firstcol - col1;
         loadstr (&lin[i], row, col2, col2 + j - i - 1, z);
         col2 += j - i;
      }
      /* else
            this text is invisible, left of the margin */

      col1 += j;
   }  /* for */

   /* Ensure remainder of line is blank */
   loadstr ((uchar *)"", row, col2, Ncols - 1, CODE_ZONE);
}


/* adjust_window --- position window to include lines 'from' through 'to' */

void adjust_window (from, to)
register Lnum from, to;
{
   register int i, l1, l2, hw;
   register int rows;
   
   rows = Botrow - Toprow;

   /* See if the whole range of lines is on the screen */
   if (from < Topln || to > Topln + rows) {
      /* Find the first and last lines that are on the screen */
      for (i = 0; i < Sclen && Scline[i] == -1; i++)
         ;

      l1 = i < Sclen ? Scline[i] + Sctop : Lastln + 1;

      for (i = Sclen - 1; i >= 0 && Scline[i] == -1; i--)
         ;

      l2 = i >= 0 ? Scline[i] + Sctop : 0;

      /* See if we have hardware line insert/delete */
      hw = hwinsdel ();

      /* Now find the best place to move the screen */
      if (to - from > rows)
         Topln = to - rows;               /* Put last part on screen */
      else if (hw && from >= l1 && to <= l2)
         Topln = (l1 + l2 - rows) / 2;    /* Centre l1 through l2 */
      else if (hw && from < l1 && l1 - from < (rows + 1) / 2)
         Topln = from;                    /* Slide the screen down */
      else if (hw && to > l2 && to - l2 < (rows + 1) / 2)
         Topln = to - rows;               /* Slide the screen up */
      else
         Topln = (from + to - rows) / 2;  /* Centre the range */

      if (Topln + rows > Lastln)
         Topln = Lastln - rows;

      if (Topln < 1)
         Topln = 1;

      if (First_affected > Topln)
         First_affected = Topln;
   }
}


/* fixcomments --- update comment flags in line buffer */

void fixcomments (first, init)
Lnum first;
bool init;
{
   register LINEDESC *k;
   register uchar *p;
   uchar txt[MAXLINE];
   Lnum i;
   int ocl, ccl;
   bool state;
   uchar q;
   
   if (init) {
      k = getind ((Lnum)1);
      k->Iscmnt = NO;   /* File always begins as code */
   }
   
   k = getind (first);
   state = k->Iscmnt;
   ocl = strulen (Oc1);
   ccl = strulen (Cc1);
   
   for (i = first; i <= Lastln; i++) {
      gtxt (k, txt);

      for (p = &txt[0]; *p != EOS; p++) {
         if (state == NO && (*p == Q1 || *p == Q2)) {
            q = *p;
            p++;
            while (*p != q && *p != NEWLINE && *p != EOS)
               p++;
               
            if (*p == q)
               p++;
         }
         else if (*p == Oc1[0] && struncmp (p, Oc1, ocl) == 0) {
            state = YES;
            p += ocl - 1;
         }
         else if (*p == Cc1[0] && struncmp (p, Cc1, ccl) == 0) {
            state = NO;
            p += ccl - 1;   
         }
      }
      
      k = NEXTLINE(k);
      if (k->Iscmnt == state && !init)
         break;

      k->Iscmnt = state;
   }
}


/* svdel --- record the deletion of buffer lines for screen update */

void svdel (ln, n)
register int ln, n;
{
   register int i, lb, ub;

   if (ln + n <= Sctop)
      Sctop -= n;
   else if (ln < Sctop) {
      ub = ln + n - Sctop;

      for (i = 0; i < Sclen; i++)
         if (Scline[i] == -1)
            ;
         else if (Scline[i] < ub)
            Scline[i] = -1;
         else
            Scline[i] -= ub;

      Sctop = ln;
   }
   else {
      lb = ln - Sctop;
      ub = ln + n - Sctop;

      for (i = 0; i < Sclen; i++)
         if (Scline[i] == -1 || Scline[i] < lb)
            ;
         else if (Scline[i] < ub)
            Scline[i] = -1;
         else
            Scline[i] -= n;
   }
}


/* svins --- record a buffer insertion for screen updating */

void svins (ln, n)
register int ln, n;
{
   register int i, lb;

   if (ln < Sctop)
      Sctop += n;
   else {
      lb = ln - Sctop;

      for (i = 0; i < Sclen; i++)
         if (Scline[i] != -1 && Scline[i] > lb)
            Scline[i] += n;
   }
}


/* fixscreen --- try to patch up the screen using insert/delete line */

static void fixscreen ()
{
   register int oi;     /* "old" screen index                       */
   register int ni;     /* "new" screen index                       */
   register int dc;     /* No. of deletions in current block        */
   register int ic;     /* No. of insertions in current block       */ 
   register int ul;     /* No. of lines that must be rewritten if   */
                        /* we don't update by insert/delete         */
   int wline[MAXROWS];  /* New screen contents; Scline contains old */
   int p;

   /* If the screen width was changed, give up before it's too late */
   if (Botrow - Toprow + 1 != Sclen)
      return;

   /* Scale the offsets in Scline to the new Topln; set any that are */
   /* off the screen to -1 so we won't have to fool with them */
   for (oi = 0; oi < Sclen; oi++)
      if (Scline[oi] == -1 || Scline[oi] + Sctop < Topln
          || Scline[oi] + Sctop > Topln + (Botrow - Toprow))
         Scline[oi] = -1;
      else
         Scline[oi] += Sctop - Topln;

   /* Fill in wline with only those numbers that are in Scline */
   for (oi = 0, ni = 0; ni < Sclen; ni++) {
      while (oi < Sclen && Scline[oi] == -1)
         oi++;

      if (oi < Sclen && Scline[oi] == ni) {
         wline[ni] = ni;
         oi++;
      }
      else
         wline[ni] = -1;
   }

   /* See if it's still advisable to fix the screen: if the number */
   /* of lines that must be rewritten is less than 2 + the number */
   /* of lines that must be inserted, don't bother (this is a dumb */
   /* but fairly effective heuristic) */
   ul = ni = 0;
   for (oi = 0; oi < Sclen; oi++) {
      if (Scline[oi] != wline[oi] || Scline[oi] == -1)
         ul++;

      if (wline[oi] == -1)
         ni++;
   }

   if (ul < ni + 2)
      return;

   /* Now scan the screens backwards and put out delete-lines */
   /* for all deletions and changes with more old lines than new */
   oi = ni = Sclen - 1;
   while (oi >= 0 || ni >= 0) {
      for (dc = 0; oi >= 0 && Scline[oi] == -1; dc++)
         oi--;

      for (ic = 0; ni >= 0 && wline[ni] == -1; ic++)
         ni--;

      if (dc > ic)
         dellines (oi + 1 + Toprow + ic, dc - ic);

      while (oi >= 0 && Scline[oi] != -1
          && ni >= 0 && wline[ni] == Scline[oi])
         oi--, ni--;
   }

   /* At last, scan the screens forward and put out insert-lines */
   /* for all insertions and changes with more new lines than old */
   oi = ni = 0;
   while (oi < Sclen || ni < Sclen) {
      p = ni;

      for (dc = 0; oi < Sclen && Scline[oi] == -1; dc++)
         oi++;

      for (ic = 0; ni < Sclen && wline[ni] == -1; ic++)
         ni++;

      if (ic > dc)
         inslines (p + Toprow + dc, ic - dc);

      while (oi < Sclen && Scline[oi] != -1
          && ni < Sclen && wline[ni] == Scline[oi])
         oi++, ni++;
   }
}
