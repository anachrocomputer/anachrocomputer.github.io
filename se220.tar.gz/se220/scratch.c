#ifdef RCS_ID
static char RCSid[] = "$Header: scratch.c,v 2.10 92/01/02 17:00:00 BJ Exp $";
#endif

/*
 * $Log:   scratch.c,v $
 * Revision 2.09 89/12/19  17:00:00  BJ
 * Added 'GETLIMBO' macro to hide OLD_SCRATCH better
 *
 * Revision 2.08 89/06/02  17:00:00  BJ
 * Added union in Buf[] for seek address, char * or EMS address
 * Make seek address long, removed 'divide by 8' kludge
 * Fixed bug in 'change ()' when RAM_SCRATCH was off
 * Made RAM_SCRATCH dynamic - create temp file when RAM runs out
 * Moved 'nextln ()' & 'prevln ()' out into 'lineno.c'
 *
 * Revision 2.00 
 * Added RAM_SCRATCH to eliminate scratch file if preferred
 *
 * Revision 1.2  86/07/17  17:21:38  arnold
 * Calls to error() changed to reflect whether or not to coredump.
 *
 * Revision 1.1  86/05/06  13:38:04  osadr
 * Initial revision
 *
 *
 */

/*
 * scratch.c
 *
 * scratch file handling for se screen editor.
 *
 * If OLD_SCRATCH is defined, then this file will contain the
 * original scratch file handling, based on linked lists,
 * from the ratfor version of Software Tools.  This method is
 * real good at moving lines around, but is poor for finding lines.
 *
 * If OLD_SCRATCH is not defined, which is the default, this file will use
 * the line handling methodology presented in Software Tools In Pascal,
 * *without* changing the way any of the routines are called.
 *
 * Bascially, the lines are always kept in order in the Buf array.
 * Thus, lines 1 through 5 are in Buf[1] through Buf[5]. blkmove() and
 * reverse() do the work of moving lines around in the buffer. The alloc()
 * routine, therefore, always allocates the first empty slot, which will be
 * at Lastln + 1, if there is room.
 *
 * Deleted lines are kept at the end of the buffer. Limbo points to the first
 * line in the group of lines which were last deleted, or else Limbo == NULL.
 *
 * It is a very good idea to read the chapters on editing in BOTH editions of
 * Software Tools, before trying to muck with this. It also helps to be a
 * little bit off the wall....
 *
 * In fact, I would go as far as saying, "If you touch this, it will break.
 * It is held together with chewing gum, scotch tape, and bobby pins."
 * (Of course, you could always use OLD_SCRATCH, which definitely works.
 * It just increases the size of the editor.)  So much for the old
 * "Just replace the implementation of the underlying primitives..."
 */

#include "se.h"
#include "extern.h"

#if MSDOS
#include <fcntl.h> 
#include <io.h>         /* Declares lseek, open, close, etc. */
#endif

#ifndef O_BINARY
/* This O_BINARY stuff is for MS-DOS & WIN32, where files
   contain CR/LF instead of NEWLINE. We define it as 0
   here so that sensible machines can ignore it. */
#define O_BINARY     0
#endif

#define GARB_FACTOR     2
#define GARB_THRESHOLD  1000

/* Places where we can keep the buffer */
#define MEMORY          0
#define DISK            1
#if IBMPC & MSDOS
#define EMS             2
#include "ems.h"
#endif   /* IBMPC & MSDOS */


#ifdef OLD_SCRATCH
#define GETLIMBO  Limbo

static int Lastbf = 0;           /* Index of last element used in Buf */

/* Export buffer organisation */
string Sbuf = "list buffer";
#else
#define GETLIMBO  &Buf[Limbo]

/* Export buffer organisation */
string Sbuf = "array buffer";
#endif   /* OLD_SCRATCH */


/* Concerning the scratch file: */
static int Scratch = MEMORY;     /* Initially put scratch in RAM  */
static filedes Scr;              /* Scratch file descriptor       */
static long int Scrend;          /* End of info on scratch file   */
static uchar Scrname[MAXPATH];   /* Name of scratch file          */

#if NO_PROTOTYPES

static LINEDESC *alloc ();
static void junklimbo ();
static int maklin ();
static filedes makscr ();
static int writef ();
static int readf ();
static void killf ();
static bool create_scratch ();

extern long lseek ();

#else

static LINEDESC *alloc (void);
static void junklimbo (void);
static int maklin (const uchar *, int, LINEDESC **);
static filedes makscr (uchar []);
static int writef (const uchar *, int, long int, filedes);
static int readf (uchar *, int, long int, filedes);
static void killf (filedes, const uchar *);
static bool create_scratch (void);

#if !MSDOS
extern long lseek ();
#endif

#endif   /* NO_PROTOTYPES */


/* alloc --- allocate space for a new pointer block */

static LINEDESC *alloc ()
{
   register LINEDESC *ptr;
   
#ifdef OLD_SCRATCH      /* old way */
   if (Free == NULL) {    /* No free list, expand into unallocated space */
      if (Lastbf < MAXBUF)          /* See if there's room */
         ptr = &Buf[Lastbf++];
      else
         ptr = NULL;           /* Out of pointer space */
   }
   else {                  /* Remove a block from free list */
      ptr = Free;
      Free = Free->Prevline;
   }
#else   /* new way */
   if (Limcnt == 0) {
      if (Lastln < (MAXBUF - 1) - 1)  /* dumb zero based indexing! */
         ptr = &Buf[Lastln + 1];
      else
         ptr = NULL;
   }
   else if (Limbo - Lastln > 1)
      ptr = &Buf[Lastln + 1];
   else
      ptr = NULL;
#endif

   return (ptr);
}


/* clrbuf --- purge scratch file */

void clrbuf ()
{
   register LINEDESC *p;
   register int i;
   
   if (Lastln > 0)
      svdel (1, Lastln);

   switch (Scratch) {
   case DISK:           /* Close & erase the scratch file */
      killf (Scr, Scrname);   
      break;

   case MEMORY:         /* Deallocate all lines */
#ifdef OLD_SCRATCH
      for (p = GETLIMBO, i = 1; i <= Limcnt; p = p->Nextline, i++)
#else
      for (p = GETLIMBO, i = 1; i <= Limcnt; p++, i++)
#endif
         free (p->Addr.Str);

      for (p = Line0, i = 0; i <= Lastln; p = NEXTLINE (p), i++)
         free (p->Addr.Str);
      
      break;

#if IBMPC & MSDOS
   case EMS:            /* Deallocate EMS handle */
      emsclose ();
      break;
#endif   /* IBMPC & MSDOS */
   }
   
   /* Restore initial state */
   Scratch = MEMORY;
}


/* garbage_collect --- compress scratch file */

void garbage_collect ()
{
   uchar new_name[MAXPATH];
   uchar txt[MAXLINE];
   register int i;
   long int new_scrend;
   filedes new_fd;
   register LINEDESC *p;

   /* We only worry about garbage in the scratch file */
   if (Scratch != DISK)
      return;
      
   if (Lost_lines > GARB_THRESHOLD
       && (Lastln + Limcnt) / Lost_lines <= GARB_FACTOR) {
      msgstr (SGARB, SCRATCH_MSG);

      new_fd = makscr (new_name);
      new_scrend = 0L;

      /* Copy the limbo lines */
#ifdef OLD_SCRATCH
      for (p = GETLIMBO, i = 1; i <= Limcnt; p = p->Nextline, i++) {
#else
      for (p = GETLIMBO, i = 1; i <= Limcnt; p++, i++) {
#endif
         gtxt (p, txt);
         writef (txt, GetLength (p), new_scrend, new_fd);
         p->Addr.Seek = new_scrend;
         new_scrend += GetLength (p);
      }

      /* Copy the lines in the buffer */
#ifdef OLD_SCRATCH
      for (p = Line0, i = 0; i <= Lastln; p = p->Nextline, i++) {
#else
      for (p = Line0, i = 0; i <= Lastln; p++, i++) {
#endif
         gtxt (p, txt);
         writef (txt, GetLength (p), new_scrend, new_fd);
         p->Addr.Seek = new_scrend;
         new_scrend += GetLength (p);
      }

      /* Get rid of the old scratch file */
      killf (Scr, Scrname);

      /* Switch over to the new one */
      Scr = new_fd;
      strucpy (Scrname, new_name);
      Scrend = new_scrend;
      Lost_lines = 0;

      msgstr (SNULL, SCRATCH_MSG);
   }
}


/* gtxt --- retrieve a line from the scratch file */

int gtxt (ptr, str)
register const LINEDESC *ptr;
register uchar *str;
{
#ifdef DB
   if (ptr == NULL)
      error (YES, "gtxt: NULL line pointer");
   else {
#ifdef OLD_SCRATCH
      if (ptr->Nextline == ptr)
         error (YES, "gtxt: 'Nextline' link points to self");
      else if (ptr->Prevline == ptr)
         error (YES, "gtxt: 'Prevline' link points to self");
#endif
   }
#endif   /* DB */

   switch (Scratch) {
   case DISK:
      readf (str, GetLength (ptr), ptr->Addr.Seek, Scr);
      break;
   case MEMORY:
#ifdef DB
      if (ptr->Addr.Str == NULL) {
         printf ("\r\ngtxt: NULL string pointer\r\n");
         printf ("ptr = 0x%08x, Buf = 0x%08x to 0x%08x\r\n", ptr, Buf, &Buf[MAXBUF]);
         printf ("Buf[%d] is dud\r\n", ptr - Buf);
         error (YES, "buffer failure");
      }
#endif
      
      strucpy (str, ptr->Addr.Str);
      break;
#if IBMPC & MSDOS
   case EMS:
      emsread (str, GetLength (ptr), ptr->Addr.Ems);
      break;
#endif   /* IBMPC & MSDOS */
   }

   return (GetLength (ptr) - 1);    /* Return length */
}


/* changeln --- replace text of a line efficiently */

int changeln (k, lin, lim)
LINEDESC *k;      /* Line to be changed                    */
const uchar *lin; /* New text                              */
bool lim;         /* TRUE if line is to be kept in 'limbo' */
{
#ifdef OLD_SCRATCH
   LINEDESC *kk;
#endif
   uchar *nl; 
   register uchar *p = NULL;
   register int l;
#if IBMPC & MSDOS
   emsptr ep;
   uchar buf[MAXLINE];
#endif   /* IBMPC & MSDOS */
   
   nl = struchr (lin, NEWLINE);

   /* Is there an embedded NEWLINE ? */
   if (*(nl + 1) != EOS) {
#ifdef OLD_SCRATCH
      Curln = 0;                    /* Fudge Curln */
      for (kk = Line0; kk != k && Curln <= Lastln; Curln++)
         kk = NEXTLINE (kk);
         
/*    printf ("Curln = %d\n", Curln); */
/*    getchar (); */
#else
      Curln = k - Line0;            /* Fudge Curln */
#endif
      deleteln (Curln, Curln);

      Curln--;
      
      if (injectln (lin, Curln) == ERR) /* Resort to using injectln again */
         return (ERR);
   }
   else {            /* No embedded NEWLINE */
      l = (nl - (uchar *)lin) + 2;     /* 2 for NEWLINE & EOS */
      /* Cast above because Microsoft C complains */

      if (Scratch == MEMORY) {
         if ((p = (uchar *)malloc (l)) == NULL)
            create_scratch ();      /* Run out of memory */
      }
#if IBMPC & MSDOS
      else if (Scratch == EMS) {
         if ((ep = emsalloc (l)) == ENULL)
            create_scratch ();      /* Run out of EMS */
      }
#endif   /* IBMPC & MSDOS */

      /* Should we worry about the limbo lines ? */
      if (lim) {
         junklimbo ();              /* Throw away old limbo lines */
   
         Buf[MAXBUF - 1] = *k;      /* Copy the line descriptor */
#ifdef OLD_SCRATCH
         Limbo = alloc ();          /* BUG: should check return */
         *Limbo = *k;               /* Copy the line descriptor */
         relink (Limbo, Limbo, Limbo, Limbo);   /* Link line to itself */
#else
         Limbo = MAXBUF - 1;
         Buf[Limbo] = *k;           /* Copy the line descriptor */
#endif
         Limcnt = 1;                /* Just one line in limbo */
      }
      else {               /* Don't need this text any more */
         if (Scratch == MEMORY)
            free (k->Addr.Str);
#if IBMPC & MSDOS
         else if (Scratch == EMS)
            emsfree (k->Addr.Ems);
#endif   /* IBMPC & MSDOS */
      }
   
      /* Now swap the text... */
      switch (Scratch) {
      case DISK:
         k->Addr.Seek = Scrend;     /* New line goes at end of file */
         writef (lin, l, Scrend, Scr);
         Scrend += l;               /* Update end-of-file */
         break;
      case MEMORY:
         k->Addr.Str = p;
         struncpy (k->Addr.Str, lin, l);
         k->Addr.Str[l - 1] = EOS;
         break;
#if IBMPC & MSDOS
      case EMS:
         k->Addr.Ems = ep;
         struncpy (buf, lin, l);
         buf[l - 1] = EOS;
         emswrite (buf, l, k->Addr.Ems);
         break;
#endif   /* IBMPC & MSDOS */
      }

      k->Lineleng = l;
      Buffer_changed = YES;
      Lost_lines++;
   }
   
   return (OK);
}


/* junklimbo --- free up the lines in 'limbo' */

static void junklimbo ()
{
   register LINEDESC *k;
   register int i;
   
   if (Limcnt == 0)    /* Nothing to do ! */
      return;

#ifdef OLD_SCRATCH
   for (k = GETLIMBO, i = 0; i < Limcnt; k = k->Nextline, i++) {
#else
   for (k = GETLIMBO, i = 0; i < Limcnt; k++, i++) {
#endif
      switch (Scratch) {
      case MEMORY:
         free (k->Addr.Str);
         k->Addr.Str = NULL;        /* Just for neatness... */
         break;
#if IBMPC & MSDOS
      case EMS:
         emsfree (k->Addr.Ems);
         k->Addr.Ems = ENULL;       /* Just for neatness... */
         break;
#endif   /* IBMPC & MSDOS */
      }

      SetMarkName (k, EOS);
#ifdef OLD_SCRATCH
/*    k->Nextline = NULL;     Leave links in place for 'Free' chain */
/*    k->Prevline = NULL; */
#endif
      k->Lineleng = 0;
   }
   
   Limcnt = 0;
   Limbo = 0;
}


/* injectln --- insert a new line after 'line' */

int injectln (str, line)
register const uchar str[];
Lnum line;
{
#ifdef OLD_SCRATCH
   register LINEDESC *k1, *k2;
#endif
   register int i;
   LINEDESC *k3;

   for (i = 0; str[i] != EOS; ) {
      /* Create a single line */
      if ((i = maklin (str, i, &k3)) == ERR) {
         Errcode = ECANTINJECT;
         return (ERR);
      }

#ifdef OLD_SCRATCH
      k1 = getind (line);        /* Get pointer to 'line'      */
      k2 = k1->Nextline;         /* Get pointer to next line   */
      relink (k1, k3, k3, k2);   /* Set pointers of new line   */
      relink (k3, k2, k1, k3);   /* Set pointers of prev, next */
      svins (line, 1);
      Lastln++;          /* update Lastln */
#else
      Lastln++;          /* update Lastln */
      blkmove (Lastln, Lastln, line);
      svins (line, 1);
#endif   /* OLD_SCRATCH */
      Curln++;      /* update Curln */
      line++;
   }

   return (OK);
}


/* maklin --- construct a new line, add to scratch file */

static int maklin (lin, i, newind)
register const uchar *lin;
register int i;
LINEDESC **newind;
{
   uchar text [MAXLINE];
   register int l, n;
   register LINEDESC *ptr;

   if ((ptr = alloc ()) == NULL)  /* Get space for pointer block */
      return (ERR);

   for (n = i; lin[n] != EOS; n++)  /* Find end of line */
      if (lin[n] == NEWLINE) {
         n++;
         break;
      }

   if (n - i >= MAXLINE )  /* Can't handle more than MAXLINE chars/line */
      n = i + MAXLINE - 1;

   l = n - i + 1;     /* Length of new line (including EOS) */

   memcpy (text, &lin[i], l);    /* Move new line into text */
   text[l - 1] = EOS;            /* Add EOS */

   if (Scratch == MEMORY) {
      if ((ptr->Addr.Str = (uchar *)malloc (l)) == NULL)
         create_scratch ();      /* Run out of memory */
   }
#if IBMPC & MSDOS
   else if (Scratch == EMS) {
      if ((ptr->Addr.Ems = emsalloc (l)) == ENULL)
         create_scratch ();      /* Run out of EMS */
   }
#endif   /* IBMPC & MSDOS */

   switch (Scratch) {
   case DISK:
      ptr->Addr.Seek = Scrend;         /* Will go at end              */
      writef (text, l, Scrend, Scr);   /* Append line on scratch file */
      Scrend += l;                     /* Update end-of-file pointer  */
      break;
   case MEMORY:
      strucpy (ptr->Addr.Str, text);   /* Copy text into place */
      break;
#if IBMPC & MSDOS
   case EMS:
      emswrite (text, l, ptr->Addr.Ems);
      break;
#endif   /* IBMPC & MSDOS */
   }

#ifdef OLD_SCRATCH
   ptr->Nextline = NULL;            /* Not part of linked-list yet   */
   ptr->Prevline = NULL;
#endif
   ptr->Lineleng = l;               /* Line length including EOS     */ 
   ptr->Iscmnt = NO;                /* Not a comment line            */
   SetGlobMark (ptr, NO);           /* Not marked for Global command */
   SetMarkName (ptr, DEFAULTNAME);  /* Give it default mark name     */

   Buffer_changed = YES;

   *newind = ptr;       /* Return index of new line */

   return (n);          /* Return next char of interest in lin */
}


/* makscr --- create a new scratch file */

static filedes makscr (str)
register uchar str[];
{
   register filedes fd;
   register int i;
#if MSDOS | MSWIN32
   char *p;
   char scrdrv;
#endif

   /* Create suitable temp file name */
   for (i = 0; i <= 9; i++) {
#if MSDOS | MSWIN32
      if ((p = getenv ("SE_TMP")) != NULL) {
         if (p[strlen (p) - 1] == '\\')
            sprintf ((char *)str, "%sse%d.tmp", p, i);
         else
            sprintf ((char *)str, "%s\\se%d.tmp", p, i);
      }
      else {
         /* Get the boot drive */
         if ((p = getenv ("COMSPEC")) != NULL)
            scrdrv = *p;
         else
            scrdrv = 'C';

         sprintf ((char *)str, "%c:\\se%d.tmp", scrdrv, i);
      }
#endif   /* MSDOS | MSWIN32 */

#if UNIX | LINUX
      sprintf ((char *)str, "/usr/tmp/se%d.%d", getpid (), i);
#endif   /* UNIX | LINUX */

      if ((fd = open ((char *)str, O_BINARY)) < 0) {
         /* if the file is not there, close it and create it */
         close (fd);

         if ((fd = creat ((char *)str, 0700 | O_BINARY)) > 0) {
            close (fd);

            if ((fd = open ((char *)str, 2 | O_BINARY)) > 0)
               return (fd);
         }       
      }
      else
         close (fd);
   }

   error (YES, "can't create scratch file");
   
   /* Can't actually reach this line... */
   return (ERR);
}


/* readf --- read 'count' characters from 'fd' into 'buf' */

static int readf (buf, count, fm, fd)
uchar *buf;
int count;
long int fm;
filedes fd;
{
   register int ret;
   register long int pos;

   pos = lseek (fd, fm, SEEK_SET);     /* Abs seek */
   if (pos != fm)
      error (YES, "Fatal scratch file seek error");

   ret = read (fd, (char *)buf, count);
   if (ret != count)
      error (YES, "Fatal scratch file read error");

   return (ret);
}


/* writef --- write 'count' characters from 'buf' onto 'fd' */

static int writef (buf, count, fm, fd)
const uchar *buf;
int count;
long int fm;
filedes fd;
{
   register int ret;
   register long int pos;

   pos = lseek (fd, fm, SEEK_SET);     /* Abs seek */
   if (pos != fm)
      error (YES, "Fatal scratch file seek error");

   ret = write (fd, (char *)buf, count);
   if (ret != count)
      error (YES, "Fatal scratch file write error");

   return (ret);
}


/* mkbuf --- create scratch file, initialize line 0 */

void mkbuf ()
{
   LINEDESC *p;

#if IBMPC & MSDOS
   if (emsinit (0L))       /* Use EMS if it's available */
      Scratch = EMS;
   else
      Scratch = MEMORY;
#else
   Scratch = MEMORY;
#endif   /* IBMPC & MSDOS */

   Scrname[0] = EOS;
   Scr = -1;
   Scrend = 0L;

   Curln = 0;
#ifdef OLD_SCRATCH
   Lastln = 0;
   Lastbf = 0;          /* Next element available for allocation */
   Free = NULL;         /* Free list initially empty */
   Limbo = NULL;        /* No lines in limbo */
#else
   Lastln = -1;         /* alloc depends on this... */
   Limbo = 0;           /* No lines in limbo */
#endif   /* OLD_SCRATCH */

   Limcnt = 0;          /* Nothing in limbo yet */
   Lost_lines = 0;      /* No garbage in scratch file yet */

   maklin ((const uchar *)"", 0, &p);  /* Create an empty line */
#ifdef OLD_SCRATCH
   relink (p, p, p, p); /* Establish initial linked list */
#endif
   SetMarkName (p, EOS);   /* Give it an illegal mark name */
   Line0 = p;              /* Henceforth and forevermore */

#ifndef OLD_SCRATCH
   Lastln = 0;
#endif
}


/* killf --- close and delete a file */

static void killf (fd, fname)
filedes fd;
const uchar *fname;
{
   close (fd);
   unlink ((char *)fname);
}


/* sp_inject --- special inject for reading files */

LINEDESC *sp_inject (str, len, line)
const uchar str[];
int len;
LINEDESC *line;   /* This arg. only used in OLD_SCRATCH */
{
#ifdef OLD_SCRATCH
   register LINEDESC *k;
#endif
   register LINEDESC *ptr;

   if ((ptr = alloc ()) == NULL) {
      Errcode = ECANTINJECT;
      return (ptr);
   }
   
   len++;   /* Include EOS */

   if (Scratch == MEMORY) {
      if ((ptr->Addr.Str = (uchar *)malloc (len)) == NULL)
         create_scratch ();      /* Run out of memory */
   }
#if IBMPC & MSDOS
   else if (Scratch == EMS) {
      if ((ptr->Addr.Ems = emsalloc (len)) == ENULL)
         create_scratch ();      /* Run out of EMS */
   }
#endif   /* IBMPC & MSDOS */

   ptr->Lineleng = len;
   ptr->Iscmnt = NO;
   SetGlobMark (ptr, NO);
   SetMarkName (ptr, DEFAULTNAME);

   switch (Scratch) {
   case DISK:
      ptr->Addr.Seek = Scrend;
      writef (str, len, Scrend, Scr);
      Scrend += len;
      break;
   case MEMORY:
      strucpy (ptr->Addr.Str, str);
      break;
#if IBMPC & MSDOS
   case EMS:
      emswrite (str, len, ptr->Addr.Ems);
      break;
#endif   /* IBMPC & MSDOS */
   }

   Lastln++;

   Buffer_changed = YES;

#ifdef OLD_SCRATCH
   k = line->Nextline;
   relink (line, ptr, ptr, k);
   relink (ptr, k, line, ptr);
#else
   /*
    * this part dependant on the fact that we set
    * Curln = line in the routine do_read.
    */
/* blkmove (ptr - Buf, ptr - Buf, Curln);    need line no's */
   blkmove (Lastln, Lastln, Curln);       /* need line no's */
   Curln++;
#endif

   return (ptr);
}


/* create_scratch --- switch over from memory/EMS to temp file */

static bool create_scratch ()
{
   register int i;
   register LINEDESC *p;
   uchar lin[MAXLINE];
   
   /* Warn the user that there will be a slight delay... */
   msgstr (SSCRATCH, SCRATCH_MSG);

   /* Make a scratch file */
   Scr = makscr (Scrname);
   Scrend = 0L;
   
   /* Copy all the lines from memory into the file */
#ifdef OLD_SCRATCH
   for (p = GETLIMBO, i = 1; i <= Limcnt; p = p->Nextline, i++) {
#else
   for (p = GETLIMBO, i = 1; i <= Limcnt; p++, i++) {
#endif
      gtxt (p, lin);
      writef (lin, GetLength (p), Scrend, Scr);

      if (Scratch == MEMORY)
         free (p->Addr.Str);
#if IBMPC & MSDOS
      else if (Scratch == EMS)
         emsfree (p->Addr.Ems);
#endif   /* IBMPC & MSDOS */

      p->Addr.Seek = Scrend;
      Scrend += GetLength (p);
   }

   for (p = Line0, i = 0; i <= Lastln; p = NEXTLINE (p), i++) {
      gtxt (p, lin);
      writef (lin, GetLength (p), Scrend, Scr);

      if (Scratch == MEMORY)
         free (p->Addr.Str);
#if IBMPC & MSDOS
      else if (Scratch == EMS)
         emsfree (p->Addr.Ems);
#endif   /* IBMPC & MSDOS */

      p->Addr.Seek = Scrend;
      Scrend += GetLength (p);
   }
   
#if IBMPC & MSDOS
   if (Scratch == EMS)
      emsclose ();
#endif   /* IBMPC & MSDOS */

   Scratch = DISK;

   msgstr (SNULL, SCRATCH_MSG);
   
   return (YES);
}
