/* video --- machine dependant video driver                 16/03/1989 */

#include "se.h"
#include "extern.h"


#ifdef HARD_TERMS

#include "hardterm.c"

#else

#if IBMPC & MSDOS
#include "ibmpc.c"
#endif

#if IBMPC & MSWIN32
#include "win32tty.c"
#endif

#if UNIX | LINUX
#if XWINDOWS
#include "xdisplay.c"
#else
#include "uxterm.c"
#endif /* XWINDOWS */
#endif /* UNIX | LINUX */

#endif   /* HARD_TERMS */
