/* resource file indicies for GSE */

#define MENUBAR  0	/* menu tree */
#define MDESK    3	/* TITLE in tree MENUBAR */
#define MFILE    4	/* TITLE in tree MENUBAR */
#define MABOUT   7	/* STRING in tree MENUBAR */
#define MQUIT    16	/* STRING in tree MENUBAR */

#define ABOUTBOX 1	/* form/dialog */
#define ABOUTOK  2	/* BUTTON in tree ABOUTBOX */

