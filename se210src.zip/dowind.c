/* dowind --- second window module                          29/07/1987 */
/* Copyright (c) 1987 BJ, Froods Software Development                  */

#include "se.h"
#include "extern.h"
#include "cmds.h"

#if IBMPC
#define SPLITSYM        196     /* Split-screen divider              */
#define INTERSECT       197     /* Intersection of 'bar' and 'split' */
#define TEESYM          194     /* Tee-piece for message display     */
#define TEESYM2         209     /* Tee-piece for long messages       */
#define SPLITSYM2       205     /* Divider for long messages         */
#else
#define SPLITSYM        '-'     /* Split-screen divider              */
#define INTERSECT       '+'     /* Intersection of 'bar' and 'split' */
#define TEESYM          '-'     /* Tee-piece for message display     */
#define TEESYM2         '*'     /* Tee-piece for long messages       */
#define SPLITSYM2       '*'     /* Divider for long messages         */
#endif   /* IBMPC */

static string Smore = " M O R E   T O   C O M E ";

#if NO_PROTOTYPES
static void draw_split ();
static void display_page ();
#else
static void draw_split (int);
static void display_page (FILE *, int);
#endif


/* dowind --- handle second window */

int dowind (lin, i)
const uchar lin[];
int i;
{
   static FILE *fp = NULL;
   static int curline = 1;
   uchar fname[MAXPATH];
   uchar cmd;
   int n;
   
   if (Nlines != 0) {
      Errcode = EBADLNR;
      return (ERR);
   }
   
   cmd = lin[i];
   
   if (isupper (cmd))
      cmd = tolower (cmd);
   
   switch (cmd) {
   case ENTERCOM:
      i++;

      if (fp != NULL)
         fclose (fp);
         
      if (getfn (lin, i, fname) == ERR)
         return (ERR);
         
      if ((fp = fopen ((char *)fname, READ)) == NULL) {
         Errcode = ECANTREAD;
         return (ERR);
      }
      
      if (Toprow > 0) {    /* Close any existing 'help' or 'o-' */
         Topln = max (0, Topln - (Toprow - 1));
         Toprow = 0;
         First_affected = Topln;
      }

      n = (Nrows / 2) - 1;
      Toprow = n;
      Topln += n;
      
      draw_split (Toprow - 1);

      curline = 1;
      display_page (fp, curline);
      break;
   case PAGECOM:
      curline += Toprow - 2;
      display_page (fp, curline);
      break;
   case QUITCOM:
      if (fp != NULL)
         fclose (fp);

      if (Toprow > 0) {    /* Close any existing window */
         Topln = max (1, Topln - Toprow);
         Toprow = 0;
         First_affected = Topln;
      }
      break;
   default: 
      Errcode = EWHATZAT;
      return (ERR);
   }
   
   return (OK);
}


/* display_page --- display a page of 'fp' */

static void display_page (fp, line)
FILE *fp;
int line;
{
/* BUG: should expand <TAB>s */
   int i, row;
   uchar lin[MAXLINE];
   
   fseek (fp, 0L, SEEK_SET);
   
   for (i = 1; i < line && fgets ((char *)lin, MAXLINE, fp) != NULL; i++)
      ;
      
   for (row = 0; row < Toprow - 1 &&
                 fgets ((char *)lin, MAXLINE, fp) != NULL; row++) {
      zapnl (lin);
      loadstr (lin, row, 0, Ncols, HELP_ZONE);
   }
      
   for (; row < Toprow - 1; row++)
      loadstr ((uchar *)"", row, 0, Ncols, HELP_ZONE);
}


/* display_help --- copy contents of help script to screen */

int display_help (fp)
FILE *fp;
{
   uchar lin[MAXCOLS];
   int row, col, k;
   bool eof;

   if (Toprow > 0) {
      Topln = max (0, Topln - (Toprow - 1));
      Toprow = 0;
   }

   eof = NO;
   for (row = Toprow; row < Botrow - 1; row++) {
      if (fgets ((char *)lin, MAXCOLS, fp) == NULL ||
         (*lin != ' ' && *lin != NEWLINE)) {
         eof = YES;  /* Non-blank terminates help page */
         break;
      }

      Toprow++;
      Topln++;

      zapnl (lin);         /* Remove NEWLINE */
      loadstr (lin, row, 0, Ncols, HELP_ZONE);
   }

   if (!eof) {
      k = (Ncols - sizeof (Smore)) / 2;

      for (col = 0; col < k; col++)
         load (SPLITSYM2, row, col, DASH_ZONE);

      load (TEESYM2, row, BARCOL, DASH_ZONE);
      
      for (k = 0; Smore[k] != EOS; k++, col++)
         load (Smore[k], row, col, DASH_ZONE);     

      for (; col < Ncols; col++)
         load (SPLITSYM2, row, col, DASH_ZONE);        
   }
   else
      draw_split (row);

   Toprow++;
   Topln++;

   if (Topln > Lastln)
      adjust_window (0, Lastln);

   if (Curln < Topln)
      Curln = Topln;

   First_affected = Topln;    /* must rewrite the whole screen */

   msgstr (SHELP, HELP_MSG);

   return (eof ? EOF: OK);
}


/* splitscreen --- split the editing screen in two */

int splitscreen (lin, i)
uchar *lin;    /* 'getone ()' can write into 'lin */
int *i;
{
   Lnum line;
   int stat;
   int ret;
   
   ret = ERR;
   
   if ((stat = getone (lin, i, &line)) == EOF) {
      msgstr (SNULL, HELP_MSG);
      if (Toprow > 0) {
         Topln = max (1, Topln - Toprow);
         Toprow = 0;
         First_affected = Topln;
      }
      ret = OK;
   }
   else if (stat != ERR && lin[*i] == NEWLINE) {
      if ((line > 0) && (Toprow + (line - Topln + 1) < Cmdrow)) {
         Toprow += line - Topln + 1;
         Topln = line + 1;
         draw_split (Toprow - 1);
         
         if (Topln > Lastln)
            adjust_window (1, Lastln);

         if (Curln < Topln)
            Curln = min (Topln, Lastln);

         ret = OK;
      }
      else
         Errcode = EORANGE;
   }

   return (ret);
}


/* draw_split --- put a row of dashes across the screen */

static void draw_split (row)
int row;
{
   register int col;
   
   for (col = 0; col < Ncols; col++)
      load (SPLITSYM, row, col, DASH_ZONE);

   load (TEESYM, row, BARCOL, DASH_ZONE);
}                   
