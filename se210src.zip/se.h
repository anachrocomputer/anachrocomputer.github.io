/*
 * $Header: se.h,v 2.09 89/09/19 14:00:00 BJ Exp $
 */

/*
 * $Log:        se.h,v $
 * Revision 2.09 89/09/19  14:00:00  BJ
 *
 * Revision 2.08 89/05/28  21:00:00  BJ
 * Added 'typedef' for line numbers
 * Changed 'LINEDESC' to include 'union' instead of '#ifdef' 
 * Merged 'display.h' with this file
 *
 * Revision 2.05 88/05/16  00:00:00  BJ
 * Added second window commands
 * Added ANSI 'enum's and 'const's
 *
 * Revision 2.01 88/02/01  00:00:00  BJ
 * Many internal changes
 * Added source-code mode
 *
 * Revision 2.0  87/10/26  19:00:00  BJ
 * Put back many Georgia Tech specific things.
 * Added ANSI function prototypes
 *
 * Revision 1.3  86/07/11  15:09:54  osadr
 * Removed Many Georgia Tech specific things.
 *
 * Revision 1.2  86/05/27  17:44:15  osadr
 * Removed flexnames dependancy on PREVLINE and PREVLINE2, changed to
 * PREVLN and PREVLN2.
 *
 * Revision 1.1  86/05/06  13:36:23  osadr
 * Initial revision
 *
 */

/* se.h --- definitions for the screen editor */

#include "config.h"  /* Decide which OS, machine & compiler to use */

#include <stdio.h>
#include <ctype.h>
#include <string.h>

#if OLD_STRINGS      /* Cope with old C libraries with 'index ()' */
#define strrchr rindex
#define strchr  index
#endif

#if NO_VOID
typedef int void;
#endif

#if NO_CONST
#define const
#endif

/* Use 'stdlib.h' if we can */
#if MSDOS | ICC | LATTICE | GNUC | VAXC
#include <stdlib.h>
#else
extern char *getenv ();
extern char *malloc ();
extern void free ();
#endif

/* Patch up a few things that may not be defined pre-ANSI */
#ifndef SEEK_SET
#define SEEK_SET  0     /* Code for 'fseek ()' and 'lseek ()' */
#endif

#ifndef EXIT_SUCCESS
#if VMS
#define EXIT_SUCCESS    (1)
#define EXIT_FAILURE    (0)
#else
#define EXIT_SUCCESS    (0)
#define EXIT_FAILURE    (1)
#endif
#endif


/* Let's use good old 'se' terminal types... */
/* #define HARD_TERMS */

/* Switch this on whenever Jay wants a copy... */
/* #define SWT */

/* Use the old, linked-list buffer organisation */
/* #define OLD_SCRATCH */

/* and we won't bother gathering statistics either */
/* #define LOG_USAGE */

/* New data types */
/* Note use of 'unsigned' on machines with 8-bit ASCII */
typedef int filedes;            /* Unix file descriptors  */
typedef int bool;               /* YES/NO flags           */
#if !AIX
typedef unsigned char uchar;    /* Prevent sign extension */
#endif
typedef int Lnum;               /* Line number - may be 'long' one day */
typedef const uchar string[];   /* Message texts          */

typedef struct Ldesc {           /* Line descriptor                */
#ifdef OLD_SCRATCH
   struct Ldesc *Prevline;       /* Link to previous line          */
   struct Ldesc *Nextline;       /* Link to next line              */
#endif
   union {
      uchar *Str;                /* Pointer to line in free RAM    */
      long int Seek;             /* Scratch file seek address      */
      long int Ems;              /* EMS page/offset                */
   } Addr;
#if ACKC
   unsigned char Iscmnt;         /* Line begins as comment         */
   unsigned char Globmark;       /* Mark for global commands       */
   unsigned int Lineleng;        /* Line length  including NL  EOS */
#else
   unsigned int Iscmnt   : 1;    /* Line begins as comment         */
   unsigned int Globmark : 1;    /* Mark for global commands       */
   unsigned int Lineleng : 14;   /* Line length  including NL  EOS */
#endif
   uchar Markname;               /* Mark name associated with line */
} LINEDESC;

struct TimeInfo {
   int Year;      /* Year including century */
   int Month;     /* Month 0-11 */
   int Day;       /* Day 1-31 */
   int Hour;      /* Hour 0-23 */
   int Minute;    /* Minute 0-59 */
   int Second;    /* Second 0-59 */
   bool Tfh;      /* 24 hour clock */
   int DateFmt;
   int WkDay;     /* Day of week 0-6, 0 == Sunday */
   uchar TimeSep;
   uchar DateSep;
#define DDMMYY    1
#define MMDDYY    2
#define YYMMDD    3
};


/* Macros for accessing mark names */
#define GetMarkName(k)           (k->Markname)
#define SetMarkName(k, name)     k->Markname = name

/* Macros for accessing global mark bit */
#define GetGlobMark(k)           (k->Globmark)
#define SetGlobMark(k, glob)     k->Globmark = glob

/* Macro for accessing line length */
#define GetLength(k)             ((int) k->Lineleng)

/* Macro for moving around the buffer, either style line handling: */
#ifdef OLD_SCRATCH
#define NEXTLINE(k)     ((k) -> Nextline)
#else
#define NEXTLINE(k)     (((k) < &Buf[Lastln]) ? (k) + 1 : Line0)
#endif

/* Macros to deal with unsigned chars */
#define strulen(s)          strlen ((char *)s)
#define struchr(s, c)       (uchar *)strchr ((char *)s, c)
#define strucpy(s1, s2)     (uchar *)strcpy ((char *)s1, (char *)s2)
#define struncpy(s1, s2, n) strncpy ((char *)s1, (char *)s2, n)
#define strucmp(s1, s2)     strcmp ((char *)s1, (char *)s2)
#define strucmpi(s1, s2)    strcmpi ((char *)s1, (char *)s2)
#define struncmp(s1, s2, n) strncmp ((char *)s1, (char *)s2, n)
#define strucat(s1, s2)     strcat ((char *)s1, (char *)s2)


/* Language extensions */
#ifndef min
#define min(a,b)        ((a)<(b)?(a):(b))
#endif
#ifndef max
#define max(a,b)        ((a)>(b)?(a):(b))
#endif
#define SKIPBL(lin,i)   while (lin[i] == ' ') (i)++
#define READ            "r"
#define WRITE           "w"
#define APPEND          "a"


/* Arbitrary definitions */
#define ERR             (-3)
#define OK              (-2)
#define NOSTATUS        1

#define NO              0
#define YES             1

#define BACKWARD        (-1)
#define FORWARD         0

#define EOS             '\0'
#define NEWLINE         '\n'
#define TAB             '\t'
#define BEL             '\007'   /* Should really be '\a' */
#define BS              '\b'
#define DEL             '\177'
#define ARG_FLAG        '-'

/* 'getcmd' return codes */
#if NO_ENUM
#define TERM_SAME       0
#define TERM_UP         1
#define TERM_SCUP       2
#define TERM_PGUP       3
#define TERM_TOP        4
#define TERM_DOWN       5
#define TERM_SCDN       6
#define TERM_PGDN       7
#define TERM_BOT        8
#define TERM_FUNNY      9
#define TERM_GOTO       10
#define TERM_RESIZE     11
#else
enum {
   TERM_SAME, TERM_UP,   TERM_SCUP, TERM_PGUP, TERM_TOP,
   TERM_DOWN, TERM_SCDN, TERM_PGDN, TERM_BOT,  TERM_FUNNY,
   TERM_GOTO, TERM_RESIZE
};
#endif

/* Types of 'bell' */
#if NO_ENUM
#define MAIL_BELL       1
#define WARN_BELL       2
#define CHAR_BELL       3
#define ERR_BELL        4
#else
enum {
   MAIL_BELL, WARN_BELL, CHAR_BELL, ERR_BELL
};
#endif   /* NO_ENUM */

#if NO_ENUM
#define CUR_NORMAL      1
#define CUR_INSERT      2
#else
enum {
   CUR_NORMAL, CUR_INSERT
};
#endif

#if NO_ENUM
#define SERC_FILE       1        /* Types of file */
#define MESG_FILE       2
#define HELP_FILE       3
#define TEMP_FILE       4
#else
enum {                           /* Types of file */
   SERC_FILE, MESG_FILE, HELP_FILE, TEMP_FILE
};
#endif   /* NO_ENUM */

#define CMD_PRMT        'c'      /* Types of prompt */
#define APD_PRMT        'a'
#define GON_PRMT        'g'
#define WAI_PRMT        'w'
#define NUL_PRMT        EOS

/* Screen design: positions */
#define NAMECOL         5       /* Column to put mark name in  */
#define BARCOL          6       /* Column for "|" divider      */
#define POOPCOL         7       /* Column for text to start in */


/* Screen design: characters */
#if IBMPC
#define BARSYM          0xb3    /* Char for BARCOL             */
#define LSHIFT          '<'     /* Indicate horiz. scrolling   */
#define RSHIFT          '>'
#define STATSYM         0xcd    /* Char to put on status row   */
#define STATL           0xb9    /* Padding to left of message  */
#define STATR           0xcc    /* Padding to right            */
#else
#define BARSYM          '|'     /* Char for BARCOL             */
#define LSHIFT          '<'     /* Indicate horiz. scrolling   */
#define RSHIFT          '>'
#define STATSYM         '.'     /* Char to put on status row   */
#define STATL           ' '     /* Padding to left of message  */
#define STATR           ' '     /* Padding to right            */
#endif   /* IBMPC */


/* Screen design: colour zones */
#if NO_ENUM
#define TEXT_ZONE       1        /* Plain text                       */
#define BAR_ZONE        2        /* 'Bar' indicating left margin     */
#define CMD_ZONE        3        /* Command line                     */
#define ONE_ZONE        4        /* '1' indicating line one          */
#define DOL_ZONE        5        /* '$' indicating last line         */
#define STAT_ZONE       6        /* Status line - background         */
#define MESG_ZONE       7        /* Status line - messages           */
#define LNUM_ZONE       8        /* 'rocket' indicating current line */
#define MARK_ZONE       9        /* Line mark names                  */
#define LINE_ZONE       10       /* Line numbers                     */
#define HELP_ZONE       11       /* Help message display area        */
#define DASH_ZONE       12       /* Dashes below 'help'              */
#define PRMT_ZONE       13       /* Prompt                           */
#define UPRT_ZONE       14       /* Unprintable characters           */
#define SHELL_ZONE      15       /* Shell calls                      */
#define CMNT_ZONE       16       /* Source-code comments             */
#define BOLD_ZONE       17       /* Source-code reserved words       */
#define STRING_ZONE     18       /* Source-code strings              */
#define PREPROC_ZONE    19       /* Source-code pre-proc cmds.       */
#else
enum {
   TEXT_ZONE = 1,          /* Plain text                       */
   BAR_ZONE,               /* 'Bar' indicating left margin     */
   CMD_ZONE,               /* Command line                     */
   ONE_ZONE,               /* '1' indicating line one          */
   DOL_ZONE,               /* '$' indicating last line         */
   STAT_ZONE,              /* Status line - background         */
   MESG_ZONE,              /* Status line - messages           */
   LNUM_ZONE,              /* 'rocket' indicating current line */
   MARK_ZONE,              /* Line mark names                  */
   LINE_ZONE,              /* Line numbers                     */
   HELP_ZONE,              /* Help message display area        */
   DASH_ZONE,              /* Dashes below 'help'              */
   PRMT_ZONE,              /* Prompt                           */
   UPRT_ZONE,              /* Unprintable characters           */
   SHELL_ZONE,             /* Shell calls                      */
   CMNT_ZONE,              /* Source-code comments             */
   BOLD_ZONE,              /* Source-code reserved words       */
   STRING_ZONE,            /* Source-code strings              */
   PREPROC_ZONE            /* Source-code pre-proc cmds.       */
};
#endif   /* NO_ENUM */

/* Array dimensions and other limit values */
#if MSDOS
#ifdef OLD_SCRATCH
#define MAXBUF          4000  /* As large as 64k segment allows */
#else
#define MAXBUF          8000  /* As large as 64k segment allows */
#endif
#define MAXROWS         75    /* Need 72 rows for AXTEL monitor */
#define MAXCOLS         160   /* Need 160 cols for WYSE monitor */
#define MAXPATH         64    /* Big enough for DOS...          */
#endif   /* MSDOS */

#if MSWIN32
#define MAXBUF          32768 /* No more 64k limit at last */
#define MAXROWS         50    /* Allow for 50-line mode */
#define MAXCOLS         80    /* But apparantly no bigger */
#define MAXPATH         64    /* Big enough for DOS...          */
#endif   /* MSDOS */

#if TOS
#ifdef OLD_SCRATCH
#define MAXBUF          2048  /* Ridiculous 32k limit in a 68000! */
#else
#define MAXBUF          4096  /* Ridiculous 32k limit in a 68000! */
#endif
#define MAXROWS         50    /* In case we use 50 rows in mono   */
#define MAXCOLS         80    /* As big as we need                */
#define MAXPATH         64    /* Same as DOS                      */
#endif

#if UNIX
#define MAXBUF          32768 /* Huge static allocation - can we *please* */
                              /* get OLD_SCRATCH working !! */
#define MAXROWS         200   /* Extra big for window systems */
#define MAXCOLS         200
#define MAXPATH         256
#endif

#if MINIX
#define MAXBUF          8192
#define MAXROWS         25
#define MAXCOLS         160   /* Allow for 132 column terminals */
#define MAXPATH         256
#endif

#if LINUX
#define MAXBUF          8192
#define MAXROWS         25
#define MAXCOLS         80
#define MAXPATH         256
#endif

#if VMS
#define MAXBUF          8192
#define MAXROWS         25
#define MAXCOLS         160
#define MAXPATH         255
#endif

#if ISERVER
#define MAXBUF          8192
#define MAXROWS         25
#define MAXCOLS         160
#define MAXPATH         255
#endif

#define MAXLINE         512      /* Line length                   */
#define MAXPAT          512      /* Pattern length                */
#define MAXTAG          10       /* Tags per pattern              */

typedef uchar Pattern[MAXPAT];

#define MAXCMNT         5        /* Length of open/close comments */

#define KEYSIZE         11

/* Message classes for status line at bottom of screen */
#if NO_ENUM
#define NOMSG           0
#define REMARK_MSG      1
#define CHAR_MSG        2
#define CASE_MSG        3
#define INS_MSG         4
#define TIME_MSG        5
#define FILE_MSG        6
#define COL_MSG         7
#define LINE_MSG        8
#define COMPRESS_MSG    9
#define HELP_MSG        10    /* Reminds user about 'o-'              */
#define CRYPT_MSG       11    /* Warns of file encryption             */
#define CAPS_MSG        12    /* Indicates caps-lock on keyboard      */
#define MOUSE_MSG       13    /* Warn that mouse is active (& hungry) */
#define PAT_MSG         14    /* Display saved pattern                */
#define VIEW_MSG        15    /* Read-only file warning               */
#define PRIV_MSG        16    /* Working as Super-User!               */
#define CHANGE_MSG      17    /* Buffer changed                       */
#define SCRATCH_MSG     18    /* Scratch file messages                */
#define LITERAL_MSG     19    /* Prompt for a literal character       */
#else
enum {
   NOMSG,
   REMARK_MSG,
   CHAR_MSG,  
   CASE_MSG,
   INS_MSG, 
   TIME_MSG,
   FILE_MSG,
   COL_MSG, 
   LINE_MSG,
   COMPRESS_MSG,
   HELP_MSG,             /* Reminds user about 'o-'              */
   CRYPT_MSG,            /* Warns of file encryption             */
   CAPS_MSG,             /* Indicates caps-lock on keyboard      */
   MOUSE_MSG,            /* Warn that mouse is active (& hungry) */
   PAT_MSG,              /* Display saved pattern                */
   VIEW_MSG,             /* Read-only file warning               */
   PRIV_MSG,             /* Working as Super-User!               */
   CHANGE_MSG,           /* Buffer changed                       */
   SCRATCH_MSG,          /* Scratch file messages                */
   LITERAL_MSG           /* Prompt for a literal character       */
};
#endif   /* NO_ENUM */

/* Characters typed by the user */
#ifdef SWT
#define BACKSCAN        '\\'
#define ESCAPE          '@'
#else
#define BACKSCAN        '?'
#define ESCAPE          '\\'     /* ...far too much like UNIX */
#endif

#define SCAN            '/'
#define SEARCH          '>'
#define BACKSEARCH      '<'
#define ANYWAY          '!'      /* Forces 'w', 'e' or 'q'         */
#define HIST_CH         '!'      /* Used for shell history         */
#define FNAME_CH        '%'      /* Used for filename substitution */
#define ENVIRON_CH      '$'      /* Used for environment variables */
#define PREVLN          '^'
#define PREVLN2         '-'
#define LASTLINE        '$'
#define TOPLINE         '#'
#define CURLINE         '.'
#define PERCENT         '%'      /* For Nchoise                    */
#define DEFAULTNAME     ' '      /* Default mark name              */
#define INLINE          ':'      /* Text in-line for 'a', 'c' or 'i' */
#define ENDAPPEND       '.'      /* To make append mode stop       */

/* Error message numbers.  MUST be in same order as 'se.msg' file. */  
#define SNULL           0     /* Special null string (not in file) */
#define EBACKWARD       1
#define ENOPAT          2
#define EBADPAT         3
#define EBADSTR         4
#define EBADSUB         5
#define ECANTREAD       6
#define EEGARB          7
#define EFILEN          8
#define EBADTABS        9
#define EINSIDEOUT      10
#define EKNOTFND        11
#define EBINFILE        12
#define E2LONG          13
#define ENOERR          14
#define ENOLIMBO        15
#define EODLSSGTR       16
#define EORANGE         17
#define EOWHAT          18
#define EPNOTFND        19
#define ESTUPID         20
#define EWHATZAT        21
#define EBREAK          22
#define ECANTCHMOD      23    /* Can't set file attributes */
#define ECANTWRITE      24
#define ECANTINJECT     25
#define ENOMATCH        26
#define ENOFN           27
#define EBADLIST        28
#define ENOLIST         29    /* No saved character list -- sorry */
#define ENONSENSE       30    /* Unreasonable value */  
#define ENOHELP         31    /* No help available */
#define EBADLNR         32    /* Line numbers not allowed */
#define EFEXISTS        33
#define EBADCOL         34
#define ENOLANG         35
#define ETRUNC          36
#define ENOSHELL        37    /* Type control-q to rebuild screen */
#define ECANTFORK       38    /* Can't fork --- get help! */
#define EHANGUP         39
#define ENOSUB          40
#define ENOCMD          41
#define EBADBIND        42    /* Bad syntax in key binding */
#define EVIEW           43
#define ESUBSYS         44
#define ESHELLCMD       45    /* Fake error to allow shell cmd editing */
#define ESHELLERR       46    /* Shell returned error code */
#define SCAPS           47
#define SCASE           48
#define SCRYPT          49
#define SGLOB           50
#define SINSERT         51
#define SMARGIN         52
#define SMOUSE          53
#define SNOCHAR         54
#define SWHAT           55
#define SXTABS          56
#define SAUTO           57
#define SBELL           58
#define SNOBELL         59
#define SLINE           60
#define SCOL            61
#define SGARB           62
#define SHELP           63
#define SGSUBCONT       64
#define SGSUBSTOP       65
#define SINSDEL         66
#define SNOINSDEL       67
#define SNOWRITE        68
#define SNOMAIL         69
#define SMAIL           70
#define SNOTSTP         71
#define SVIEW           72
#define SREADING        73
#define SSAVED          74
#define SNOSAVED        75
#define SWRITING        76
#define SNULKEY         77
#define SPATCASE        78
#define SNOPATCASE      79
#define SHAVEMAIL       80
#define SNEWMAIL        81
#define SWINDPOS        82
#define SWINDSIZE       83
#define SMORETOCOME     84
#define SPRIV           85
#define SCHANGED        86
#define SBRACKMATCH     87
#define STYPERETURN     88
#define SSCRATCH        89
#define SCRYPT1         90
#define SCRYPT2         91
#define SCRYPT3         92
#define SCRYPT4         93
#define SLITERAL        94
#define SNOTBOUND       95
#define EWRFAIL         96
#define EBINDKEY        97
#define EBINDQU         98
#define EBINDFUN        99
#define EBINDMEM        100
#define SIDPRMPT        101
#define SKEYBAD         102
#define SNOTBIND        103
#define SMONTHTAB       104 /* Jan */
/*                      105 Feb */
/*                      106 Mar */
/*                      107 Apr */
/*                      108 May */
/*                      109 Jun */
/*                      110 Jul */
/*                      111 Aug */
/*                      112 Sep */
/*                      113 Oct */
/*                      114 Nov */
/*                      115 Dec */
#define EFILETAB        116   /* No room in file table */
#define EFILEEND        117   /* End of file table */


/* Function prototypes */

#if !NO_PROTOTYPES

/* From 'pat.c' */
bool match (const uchar *, const Pattern);
int amatch (const uchar *, int, const Pattern, int [], int []);
int makpat (const uchar *, int, int, Pattern);
int maksub (const uchar *, int, int, Pattern);
bool addset (int, uchar *, int *, int);
uchar esc (const uchar *, int *);
void filset (int, const uchar *, int *, uchar *, int *, int);
void catsub (const uchar *, int [], int [],
             const uchar *, uchar *, int *, int);

/* From 'scratch.c' */
void garbage_collect (void);
LINEDESC *sp_inject (const uchar [], int, LINEDESC *);
int gtxt (const LINEDESC *, uchar *);
void mkbuf (void);
int injectln (const uchar [], Lnum);
int changeln (LINEDESC *, const uchar *, bool);
void clrbuf (void);
/* From 'buffer.c' */
void bump (Lnum *, LINEDESC **, int);
#ifdef OLD_SCRATCH
void relink (LINEDESC *, LINEDESC *, LINEDESC *, LINEDESC *);
#else
void blkmove (int, int, int);
void reverse (int, int);
#endif
LINEDESC *getind (Lnum);
int deleteln (Lnum, Lnum);
int doundo (bool);
/* From 'docmd.c' */
int docmd (uchar [], int, bool);
/* From 'docmd1.c' */
int dohelp (const uchar *, int);
int doprnt (int, int);
int dotlit (const uchar *, int);
int doshell (uchar [], int);
/* From 'docmd2.c' */
int append (int, const uchar *);
int copy (int);
int join (const uchar *);
int move (int);
int dooverlay (void);
int subst (const Pattern, bool, bool);
int dochange (const uchar *);
/* From 'global.c' */
int ckglob (uchar [], int *);
int doglob (uchar [], int *, int *);
/* From 'bind.c' */
void bind_init (void);
int gettok (bool);
void identify_key (void);
int dobind (const uchar *);
/* From 'misccmds.c' */
int domisc (const uchar *, int);
/* From 'doopt.c' */
void doopt_init (void);
void reset_opts (void);
int doopt (uchar [], int);
/* From 'filecmds.c' */
void file_init (void);
int doenter (const uchar *, bool);
int doread (Lnum, const uchar *, bool);
int dowrit (Lnum, Lnum, const uchar *, bool, bool, bool);
int getfn (const uchar *, int, uchar *);
void set_filename (const uchar *);
uchar *get_filename (void);
int new_filename (int dir);
int add_filename (const uchar *file);
void getcryptkey (void);
/* From 'edit.c' */
void edit (int, const uchar *[]);
int getkn (const uchar *, int *, uchar *, int);
int getrange (const uchar *, int *, uchar *, int, int *);
int getrhs (uchar *, int *, Pattern, bool *);
int makset (uchar *, int *, uchar *, int);
int optpat (const uchar *, int *);
int ptscan (int, Lnum *);
/* From 'getcmd.c' */
int getcmd (int, uchar *, int, int *);
/* From 'lineno.c' */
int getlst (uchar [], int *, int *);
int getone (uchar [], int *, Lnum *);
void defalt (Lnum, Lnum);
Lnum nextln (Lnum);
Lnum prevln (Lnum);
/* From 'main.c' */
int main (int, const uchar *[]);
void error (int, char  *);
/* From 'sesig.c' */
void sig_init (void);
void hangup (void);
bool intrpt (void);
void in_read (bool);
int dosuspend (void);
void do_coredump (void);
void sigread (void);
/* From 'pvem.c' */
void pvem_init (void);
void pvem_close (void);
void printverboseerrormessage (void);
uchar *getstring (int);
void msgstr (int, int);
void mesg (const uchar *, int);
/* From 'os.c' */
void os_init (void);
void get_time (struct TimeInfo *);
bool isreadonly (const uchar *);
bool setreadonly (const uchar *, bool);
uchar *sysname (void);
uchar *usrname (void);
int shell_close (FILE *);
FILE *shell_open (const uchar *, const char *);
uchar *gethomedir (const uchar *);
int call_shell (const uchar *);
void mswait (void);
bool getsefile (int, uchar *);
bool file_exists (const uchar *);
long int getflen (const uchar *);
void commit_file (FILE *);
void sync_disk (void);
/* From 'dowind.c' */
int dowind (const uchar [], int);
int display_help (FILE *);
int splitscreen (uchar *, int *);
/* From 'markcmds.c' */
int knscan (int, Lnum *);
int domark (int);
int uniquely_name (int);
/* From 'display.c' */
void litnnum (const uchar *, int, int);
int setprompt (int, const uchar *);
void prompt (int, int);
void saynum (int);
void warn_deleted (int, int);
void watch (void);
void scroll_window (int);
bool hwinsdel (void);
void set_viewflag (void);
/* From 'screen.c' */
void screen_init (void);
void setscreen (void);
int installkw (const uchar *);
void setlegal (const uchar *);
void clearkws (void);
void clrrow (int);
void updscreen (void);
void adjust_window (Lnum, Lnum);
void fixcomments (Lnum, bool);
void svdel (int, int);
void svins (int, int);
/* From 'misc.c' */
int cindex (const uchar *, int);
int xindex (const uchar *, int, int, int);
void strmap (uchar [], int);
void zapnl (uchar *);
int ctoi (const uchar *, int *);
int dfltsopt (const uchar *);
void bracket_match (const uchar *);
void showpat (void);
int dosopt (const uchar []);
#if !(MSC | TCC)
int strcmpi (const char *s1, const char *s2);
#endif
void verstr (uchar *);
LINEDESC *get_txt (Lnum, uchar *);
void mkdatestr (uchar *str, int fn);
bool probation (int cmd);
int toggle (bool *pflag, int onstr, int offstr, int msgtype);
/* From Machine Dependent Video Driver */
void mdvd_init (void);
void setcolr (int, int, int);
void shellcolr (void);
int mvinch (int, int);
void cprow (int, int);
void load (int, int, int, int);
void loadstr (const uchar *, int, int, int, int);
void restore_screen (void);
void ringbell (int);
void position_cursor (int, int);
void show_cursor (bool);
void shape_cursor (int);
void clrscreen (void);
void inslines (int, int);
void dellines (int, int);
int set_term (const uchar *t, bool *hw, int *r, int *c);
uchar *term_name (void);
int readkey (bool raw);
void term_init (void);
void term_exit (void);
/* From 'ttyio.c' */
void tflush (void);
void ttyedit (void);
void ttynormal (void);
int t1in (void);
int t1ou (char ch);

#else    /* NO_PROTOTYPES */

/* From 'pat.c' */
extern bool match ();
extern int amatch ();
extern int makpat ();
extern int maksub ();
extern bool addset ();
extern uchar esc ();
extern void filset ();
extern void catsub ();

/* From 'scratch.c' */
extern LINEDESC *sp_inject ();
extern void mkbuf ();
extern int gtxt ();
extern int injectln ();
extern void garbage_collect ();
extern int changeln ();
extern void clrbuf ();
/* From 'buffer.c' */
extern void bump ();
#ifdef OLD_SCRATCH
extern void relink ();
#else
extern void blkmove ();
extern void reverse ();
#endif
extern LINEDESC *getind ();
extern int deleteln ();
extern int doundo ();
/* From 'docmd.c' */
extern int docmd ();
/* From 'docmd1.c' */
extern int dohelp ();
extern int doprnt ();
extern int dotlit ();
extern int doshell ();
/* From 'docmd2.c' */
extern int append ();
extern int copy ();
extern int join ();
extern int move ();
extern int dooverlay ();
extern int subst ();
extern int dochange ();
/* From 'global.c' */
extern int ckglob ();
extern int doglob ();
/* From 'bind.c' */
extern void bind_init ();
extern int gettok ();
extern void identify_key ();
extern int dobind ();
/* From 'misccmds.c' */
extern int domisc ();
/* From 'doopt.c' */
extern void doopt_init ();
extern void reset_opts ();
extern int doopt ();
/* From 'filecmds.c' */
extern void file_init ();
extern int doenter ();
extern int doread ();
extern int dowrit ();
extern int getfn ();
extern void set_filename ();
uchar *get_filename ();
int new_filename ();
int add_filename ();
extern void getcryptkey ();
/* From 'edit.c' */
extern void edit ();
extern int getkn ();
extern int getrange ();
extern int getrhs ();
extern int makset ();
extern int optpat ();
extern int ptscan ();
/* From 'getcmd.c' */
extern int getcmd ();
/* From 'lineno.c' */
extern int getlst ();
extern int getone ();
extern void defalt ();
extern int nextln ();
extern int prevln ();
/* From 'main.c' */
extern int main ();
extern void error ();
/* From 'sesig.c' */
void sig_init ();
extern void hangup ();
extern bool intrpt ();
void in_read ();
int dosuspend ();
void do_coredump ();
void sigread ();
/* From 'pvem.c' */
extern void pvem_init ();
extern void pvem_close ();
extern void printverboseerrormessage ();
extern uchar *getstring ();
extern void msgstr ();
extern void mesg ();
/* From 'os.c' */
extern void os_init ();
extern void get_time ();
extern bool isreadonly ();
extern bool setreadonly ();
extern uchar *sysname ();
extern uchar *usrname ();
extern int shell_close ();
extern FILE *shell_open ();
extern uchar *gethomedir ();
int call_shell ();
extern void mswait ();
extern bool getsefile ();
extern bool file_exists ();
extern long int getflen ();
extern void commit_file ();
extern void sync_disk ();
/* From 'dowind.c' */
extern int dowind ();
extern int display_help ();
extern int splitscreen ();
/* From 'markcmds.c' */
extern int knscan ();
extern int domark ();
extern int uniquely_name ();
/* From 'display.c' */
extern void litnnum ();
extern int setprompt ();
extern void prompt ();
extern void saynum ();
extern void warn_deleted ();
extern void watch ();
extern void scroll_window ();
extern bool hwinsdel ();
extern void set_viewflag ();
/* From 'screen.c' */
extern void screen_init ();
extern void setscreen ();
extern int installkw ();
extern void setlegal ();
extern void clearkws ();
extern void clrrow ();
extern void mesg ();
extern void updscreen ();
extern void adjust_window ();
extern void fixcomments ();
extern void svdel ();
extern void svins ();
/* From 'misc.c' */
extern int cindex ();
extern int xindex ();
extern void strmap ();
extern void zapnl ();
extern int ctoi ();
extern int dfltsopt ();
extern void bracket_match ();
extern void showpat ();
extern int dosopt ();
#if !MSC
extern int strcmpi ();
#endif
extern void verstr ();
extern LINEDESC *get_txt ();
extern void mkdatestr ();
extern bool probation ();
extern int toggle ();
/* From Machine Dependent Video Driver */
extern void mdvd_init ();
extern void setcolr ();
extern void shellcolr ();
extern int mvinch ();
extern void cprow ();
extern void load ();
extern void loadstr ();
extern void restore_screen ();
extern void ringbell ();
extern void position_cursor ();
extern void show_cursor ();
extern void shape_cursor ();
extern void clrscreen ();
extern void inslines ();
extern void dellines ();
extern int set_term ();
extern uchar *term_name ();
extern int readkey ();
extern void term_init ();
extern void term_exit ();
/* From 'ttyio.c' */
extern void tflush ();
extern void ttyedit ();
extern void ttynormal ();
extern int t1in ();
extern int t1ou ();

#endif      /* NO_PROTOTYPES */
