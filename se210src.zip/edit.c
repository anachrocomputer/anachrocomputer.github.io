#ifdef RCS_ID
static char RCSid[] = "$Header: edit.c,v 2.08 89/03/16 00:00:00 BJ Exp $";
#endif

/*
 * $Log:        edit.c,v $
 * Revision 2.08 89/03/16  00:00:00  BJ
 * Added read-only file detection
 * Improved encapsulation of version information
 * Fixed bug in 'getrhs' that corrupted 'Subs'
 *
 * Revision 2.07 88/11/18  00:00:00  BJ
 * Moved 'serc' code to 'misc.c' in 'dfltsopt ()'
 *
 * Revision 2.05 88/05/16  00:00:00  BJ
 * Added ANSI 'const' declarations
 *
 * Revision 2.0  87/09/14  13:54:00  BJ
 * Fixed bug in filename routine when name was 1 char.
 * Fixed bug in 'serc ()' code
 * Moved OS specific code to 'os.c'
 * Added version identification
 *
 * Revision 1.3  86/07/11  15:11:34  osadr
 * Removed Georgia Tech specific code.
 *
 * Revision 1.2  86/05/27  17:44:56  osadr
 * Removed flexnames dependancy; PREVLINE[2] --> PREVLN[2].
 * Improved the sysname() routine, particularly to use the nodename
 * member of the utsname structure under System V.
 *
 * Revision 1.1  86/05/06  13:37:16  osadr
 * Initial revision
 *
 *
 */

/*
 * edit.c
 *
 * editor main routine, plus other routines used a lot.
 */

#include "se.h"
#include "extern.h"

#include "cmds.h"    /* We need GLOBAL & UCGLOBAL */

#ifdef SWT
#define NOTINCCL        '~'
#else
#define NOTINCCL        '^'
#endif


static string Stitle   = "se --- the Froods editor";


/* edit --- main routine for screen editor */

void edit (argc, argv)
int argc;
const uchar *argv[];
{
   int cursav, status, len, cursor;
   uchar lin[MAXLINE];
   int term;
   int i = 0;
   int argno;
   uchar *file;

   verstr (lin);
   loadstr (Stitle, i++, POOPCOL, Ncols, HELP_ZONE);
   loadstr (lin,    i++, POOPCOL, Ncols, HELP_ZONE);

   status = OK;
   Errcode = EEGARB;    /* Default error code for 'doopt' */

   for (argno = 1; status == OK && argno < argc; argno++) {
      strucpy (lin, argv[argno]);
      if (i < Nrows)
         loadstr (lin, i++, POOPCOL, Ncols, TEXT_ZONE);

      if (lin[0] == ARG_FLAG) {        /* It's a switch... */
         strucat (lin, "\n");
         status = doopt (lin, 1);
      }
      else {                           /* It's a file... */
         status = add_filename (lin);
      }
   }
   
   /* Set options now if we didn't do it before */
   if (status == OK) {
      if ((file = get_filename ()) == NULL)
         dfltsopt (NULL);     /* Un-named buffer -- read the SE.RC file */
      else
         status = doenter (file, NO);  /* Read SE.RC and enter file */
   }

   watch ();   /* Display time of day (after setting up SERC) */

   /* Is the buffer file read-only ? */
   set_viewflag ();
   
   if (status == ERR) {
      if (Errcode == EHANGUP)
         hangup ();

      printverboseerrormessage ();
   }
   else
      Curln = min (1, Lastln);

   Buffer_changed = NO;    /* Buffer not changed yet */
   First_affected = 1;     /* Maintained by updscreen & commands */
   if (Src_mode)           /* Set up comment flags */
      fixcomments (1, YES);

   updscreen ();

   if (status != ERR)      /* Leave offending file name or option */
      lin[0] = EOS;

   cursor = 0;

   /* Main command loop */
   do {
      intrpt ();           /* Discard pending breaks (interrupts) */
      garbage_collect ();
      
      if (Show_ok && Buffer_changed)
         msgstr (SCHANGED, CHANGE_MSG);
      else
         msgstr (SNULL, CHANGE_MSG);

      mswait ();           /* Check for pending messages */

      Cmdrow = Botrow + 1; /* Reset the command line location */

      prompt (CMD_PRMT, Cmdrow);

      term = getcmd (Cmdrow, lin, 0, &cursor);
      msgstr (SNULL, REMARK_MSG);   /* Clear out any error messages */

      while (!(term == TERM_SAME || term == TERM_FUNNY)) {
         scroll_window (term);
         updscreen ();
         term = getcmd (Cmdrow, lin, 0, &cursor);
      }

      prompt (WAI_PRMT, Cmdrow);  /* Display 'wait' prompt */

      cursav = Curln;      /* Remember it in case of an error */
      Errcode = EEGARB;    /* Default error code for garbage at end */

      len = 0;
      if (getlst (lin, &len, &status) == OK) {
         if ((status = ckglob (lin, &len)) == OK)
            status = doglob (lin, &len, &cursav);
         else if (status != ERR)
            status = docmd (lin, len, NO);
      }

      if (status == ERR) {
         if (Errcode == EHANGUP)
            hangup ();

         printverboseerrormessage ();
         Curln = min (cursav, Lastln);
      }
      else if (term != TERM_FUNNY) {
         cursor = 0;
         lin[0] = EOS;
      }

      adjust_window (Curln, Curln);
      updscreen ();

   } while (status != EOF);

   /* Clean up the screen... */
   clrscreen ();
}


/* getkn --- get mark name from lin[i], increment i */

int getkn (lin, i, kname, dfltnm)
const uchar *lin;
int *i;
uchar *kname;
int dfltnm;
{
   if (lin[*i] == NEWLINE || lin[*i] == EOS) {
      *kname = dfltnm;
      return (EOF);
   }

   *kname = lin[*i];
   (*i)++;
   return (OK);
}


/* getrange --- get 'from' range for tlit command */

int getrange (array, k, set, size, allbut)
const uchar *array;
int *k;
uchar *set;
int size, *allbut;
{
   int i, j;

   Errcode = EBADLIST;     /* preset error code */

   i = *k + 1;
   if (array[i] == NOTINCCL) {     /* check for negated character class */
      *allbut = YES;
      i++;
   }
   else
      *allbut = NO;

   j = 0;
   filset (array[*k], array, &i, set, &j, size);
   if (array[i] != array[*k]) {
      set[0] = EOS;
      return (ERR);
   }

   if (set[0] == EOS) {
      Errcode = ENOLIST;
      return (ERR);
   }

   if (j > 0 && !addset (EOS, set, &j, size)) {
      set[0] = EOS;
      return (ERR);
   }

   *k = i;
   Errcode = EEGARB;

   return (OK);
}


/* getrhs --- get substitution string for 's' command */

int getrhs (lin, i, sub, gflag)
uchar *lin;
int *i;
Pattern sub;
bool *gflag;
{
   static Pattern Subs = "";     /* Saved replacement pattern */
   int j;

   Errcode = EBADSUB;

   if (lin[*i] == EOS)     /* missing the middle delimiter */
      return (ERR);

   if ((lin[*i + 1] == '%' || lin[*i + 1] == '&') &&
       (lin[*i + 2] == lin[*i] || lin[*i + 2] == NEWLINE)) {
   /*
    * s//%/ -- should mean do the same thing as I did last time, even
    * s//&/ -- if I deleted something. So we comment out these lines.
    *
      if (Subs[0] == EOS) {
         Errcode = ENOSUB;
         return (ERR);
      }
    */

      memcpy (sub, Subs, sizeof (Pattern));   /* Use saved pattern */

      *i += 2;
      if (lin[*i] == NEWLINE) {
         /* fix it up for pattern matching routines */
         lin[*i] = lin[*i - 2];
         lin[*i + 1] = NEWLINE;
         lin[*i + 2] = EOS;
         Peekc = YES;
      }
   }
   else {      /* Not using saved substitution pattern */
      if (lin[*i + 1] == NEWLINE) {
         /* missing the trailing delimiter */
         /* pattern was empty */
         lin[*i + 1] = lin[*i];  /* supply missing delimiter */
         lin[*i + 2] = NEWLINE;
         lin[*i + 3] = EOS;
         Peekc = YES;
         /* return (ERR);       this is the original action */
      }
      else {
         /* stuff in pattern, check end of line */
         for (j = *i; lin[j] != EOS; j++)
            ;

         j -= 2;    /* j now points to char before NEWLINE */

         if (lin[j] == 'p' || lin[j] == 'P') {
            --j;
            if (lin[j] == GLOBAL || lin[j] == UCGLOBAL) {
               if (j >= *i + 1 && lin[j-1] == lin[*i]
                  && (lin[j-2] != ESCAPE
                      || lin[j-3] == ESCAPE))
                  ;       /* leave alone */
               else {
                  /* \<delim>gp\n is pattern */
                  /* supply trailing delim */
                  j +=  2;   /* j at \n */
                  lin[j] = lin[*i];
                  lin[++j] = NEWLINE;
                  lin[++j] = EOS;
                  Peekc = YES;
               }
            }
            else if (j >= *i + 1 && lin[j] == lin[*i] &&
                  (lin[j-1] != ESCAPE
                   || lin[j-2] == ESCAPE))
               ;       /* leave alone */
            else {
               /* \<delim>p\n is pattern */
               /* supply trailing delim */
               j += 2;
               lin[j] = lin[*i];
               lin[++j] = NEWLINE;
               lin[++j] = EOS;
               Peekc = YES;
            }
         }
         else if (lin[j] == GLOBAL || lin[j] == UCGLOBAL) {
            --j;
            if (j >= *i + 1 && lin[j] == lin[*i] &&
               (lin[j-1] != ESCAPE || lin[j-2] == ESCAPE))
               ;       /* leave alone */
            else {
               /* \<delim>g\n is pattern */
               /* supply trailing delim */
               j +=  2;   /* j at \n */
               lin[j] = lin[*i];
               lin[++j] = NEWLINE;
               lin[++j] = EOS;
               Peekc = YES;
            }
         }
         else if ((lin[j] != lin[*i]) ||
            (lin[j] == lin[*i] &&
            lin[j-1] == ESCAPE && lin[j-2] != ESCAPE)) {
            /* simply missing trailing delimeter */
            /* supply it */
            j++;       /* j at \n */
            lin[j] = lin[*i];
            lin[++j] = NEWLINE;
            lin[++j] = EOS;
            Peekc = YES;
         }
         /* else
            unescaped delim is there,
            leave well enough alone */
      }

      /* Make the text at lin[*i] into a substitution pattern */
      if ((*i = maksub (lin, *i + 1, lin[*i], sub)) == ERR)
         return (ERR);

      memcpy (Subs, sub, sizeof (Pattern));   /* Save pattern for later */
   }

   if (lin[*i + 1] == GLOBAL || lin[*i + 1] == UCGLOBAL) {
      (*i)++;
      *gflag = YES;
   }
   else
      *gflag = NO;

   Errcode = EEGARB;       /* The default */

   return (OK);
}


/* makset --- make set from array[k] in set */

int makset (array, k, set, size)
uchar *array;
int *k;
uchar *set;
int size;
{
   static uchar Tset[MAXPAT] = "";  /* Saved translit dest range */
   int i, j;
   int l;

   Errcode = EBADLIST;

   /*
    * try to allow missing delimiter for translit command.
    */

   if (array[*k] == EOS)
      return (ERR);

   if (array[*k + 1] == '%' && (array[*k + 2] == array[*k]
                  || array[*k + 2] == NEWLINE)) {
      strucpy (set, Tset);
      *k += 2;
      if (array[*k] == NEWLINE) {
         /* fix it up for rest of the routines */
         array[*k] = array[*k - 2];
         array[*k+ 1] = NEWLINE;
         array[*k+ 2] = EOS;
      }
      Peekc = YES;
   }
   else {
      for (l = *k; array[l] != EOS; l++)
         ;

      l -= 2;    /* l now points to char before NEWLINE */

      if (l == *k) {  /* "y/.../\n" */
         array[*k + 1] = array[*k];      /* add delimiter */
         array[*k + 2] = NEWLINE;
         array[*k + 3] = EOS;
         Peekc = YES;
      }
      else if (array[l] == 'p' || array[l] == 'P') {
         --l;
         if (l >= *k + 1 && array[l] == array[*k] &&
            (array[l-1] != ESCAPE || array[l-2] == ESCAPE))
            ;       /* leave alone */
         else {
            /* \<delim>p\n is set */
            /* supply trailing delim */
            l += 2;
            array[l] = array[*k];
            array[++l] = NEWLINE;
            array[++l] = EOS;
            Peekc = YES;
         }
      }
      else if (array[l] != array[*k]  /* no delim, and no p */
          || (array[l-1] == ESCAPE    /* or last char is escaped delim */
         && array[l-2] != ESCAPE)) {
         /* simply missing trailing delimeter */
         /* supply it */
         l++;       /* l now at \n */
         array[l] = array[*k];
         array[++l] = NEWLINE;
         array[++l] = EOS;
         Peekc = YES;
      }
      /* else
         delim is there,
         leave well enough alone */

      j = 0;
      i = *k + 1;
      filset (array[*k], array, &i, set, &j, size);

      if (array[i] != array[*k])
         return (ERR);

      if (!addset (EOS, set, &j, size))
         return (ERR);

      strucpy (Tset, set);    /* Save for later */
      *k = i;

   }

   Errcode = EEGARB;

   return (OK);
}


/* optpat --- make pattern specified at lin[i] */

int optpat (lin, i)
const uchar *lin;
int *i;
{
   register int j, k;
   uchar delim;         /* Pattern delimiter (often '/')      */
   int start;           /* Index of start of pattern in 'lin' */
   
   delim = lin[*i];
   start = *i + 1;
   
   if (lin[*i] == EOS)        /* Nothing there at all */
      *i = ERR;
   else if (lin[start] == EOS)   /* Too short to be a pattern */
      *i = ERR;
   else if (lin[start] == delim)       /* Repeated delimiter:          */
      (*i)++;                       /* Leave existing pattern alone */
   else
      *i = makpat (lin, start, delim, Pat);

   if (Pat[0] == EOS) {    /* Make sure we can remember old pattern */
      Errcode = ENOPAT;
      return (ERR);
   }

   if (*i == ERR) {        /* Call to 'makpat' failed */
      Pat[0] = EOS;
      Errcode = EBADPAT;
      return (ERR);
   }

   /* Save text of pattern for 'o/' */
   if (lin[start] != delim) {
      for (j = 0, k = start; lin[k] != delim && lin[k] != EOS; j++, k++)
         if (lin[k] == ESCAPE) {
            Savpat[j++] = lin[k++];    /* Copy ESCAPE */
            Savpat[j] = lin[k];        /* Copy escaped character */
         }
         else
            Savpat[j] = lin[k];
      
      Savpat[j] = EOS;
      showpat ();    /* Update screen display of pattern */
   }

   return (OK);
}


/* ptscan --- scan for next occurrence of pattern */

int ptscan (way, num)
int way;                /* Direction of scan */
register Lnum *num;      /* Line number where match found */
{
   LINEDESC *k;
   uchar txt[MAXLINE];

   *num = Curln;        /* Search begins at Curln */
   k = getind (*num);
   do {
      bump (num, &k, way);
      gtxt (k, txt);
      if (match (txt, Pat))
         return (OK);         /* Found */

   } while (*num != Curln && ! intrpt ());

   if (Errcode == EEGARB)     /* Did user break out ? */
      Errcode = EPNOTFND;

   return (ERR);     /* Either not found or break */
}
