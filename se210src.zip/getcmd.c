/* getcmd --- routines for reading keyboard input           14/09/1987 */

#include "se.h"
#include "extern.h"

#include "ctrl.h"       /* Control character mapping */

#define SCAN_LEFT       1
#define SCAN_RIGHT      2

static uchar Last_char_scanned = EOS;  /* Last char scanned w/ctl-[jl] */


#if NO_PROTOTYPES
static void show_lnum ();
static int scan_char ();
static int scan_tab ();
static void gobble ();
static int insert ();
static int set_cursor ();
static int stuff_string ();
#else
static void show_lnum (void);
static int scan_char (int, bool, int, int, const uchar *, int *);
static int scan_tab (int dir, int cursor, int *status);
static void gobble (int, int, int *, int *, uchar *);
static int insert (int, int *, int, uchar *);
static int set_cursor (int, int *, int *, uchar *);
static int stuff_string (const uchar *str, int *nlp, int *cursor, uchar *lin);
#endif


/* getcmd --- read a line allowing for character editing */

int getcmd (row, lin, col1, curpos)
int row;             /* Screen row         */
uchar *lin;          /* Line buffer        */
int col1;            /* Left margin column */
int *curpos;         /* Cursor position    */
{
   uchar spcstr[MAXLINE];
   uchar *savfil;
   int termcode;     /* Termination code              */
   int nlpos;        /* NEWLINE position              */
   int cursor;       /* Cursor position               */
   int prev_cursor;  /* Previous cursor position      */
   int wcol;         /* Column where we warn the user */
   int status;       /* Status of this time around    */
   int prev_status;  /* Status of previous iteration  */
   int scan_pos;
   int tab_pos;
   int first;
   int c;            /* Character or token read in    */
   int chr;          /* Character at cursor position  */

   if (Use_script) {
      if (fgets ((char *)lin, MAXLINE, Scriptfp) == NULL) {
         Use_script = NO;
         fclose (Scriptfp);
         Scriptfp = NULL;
      }
      else {
         cursor = strulen (lin) - 1;
         *curpos = cursor;
         termcode = TERM_SAME;
         return (termcode);
      }
   }

   /* Set up the warning column */
   if (Warncol == 0)
      wcol = Ncols - BARCOL;
   else
      wcol = Warncol;
   
   /* Set up the newline position */
   nlpos = strulen (lin) - 1;
   if (nlpos == -1 || lin[nlpos] != NEWLINE)
      nlpos++;

   /* Set up the cursor position */
   if (*curpos < 0)
      cursor = 0;
   else if (*curpos >= MAXLINE - 1)
      cursor = nlpos;
   else
      status = set_cursor (*curpos, &cursor, &nlpos, lin);

   prev_cursor = cursor;

   watch ();      /* Display the time of day */
                              
   show_lnum ();  /* Display line number on status line */
   
   if (cursor + 1 < wcol)       /* erase the column display */
      msgstr (SNULL, COL_MSG);

   termcode = EOF;   /* Not yet terminated */
   status = OK;
   prev_status = ERR;
   first = col1;

   while (termcode == EOF) {
      lin[nlpos] = EOS;       /* Make sure the line has an EOS */
      if (status == ERR)      /* Last iteration generated an error */ 
         ringbell (CHAR_BELL);
      else if (status == EOF) /* Last iteration displayed a message */ 
         ;
      else if (prev_status == ERR || prev_status == EOF)
         msgstr (SNULL, CHAR_MSG); /* last one OK but one before had error */

      prev_status = status;
      status = OK;

      if (first > cursor)     /* do horiz. scroll if needed */
         first = cursor;
      else if (first < cursor - Ncols + POOPCOL + 1)
         first = cursor - Ncols + POOPCOL + 1;

      if (first == col1)      /* indicate horizontally shifted line */
         load (BARSYM, row, BARCOL, BAR_ZONE);
      else if (first > col1)
         load (LSHIFT, row, BARCOL, BAR_ZONE);   
      else if (first < col1)
         load (RSHIFT, row, BARCOL, BAR_ZONE);   

      loadstr (&lin[first], row, POOPCOL, Ncols - 1, CMD_ZONE);

      if (cursor == wcol - 1 && prev_cursor < wcol - 1)
         ringbell (WARN_BELL);

      if (cursor >= wcol - 1)
         litnnum (getstring (SCOL), cursor + 1, COL_MSG);
      else if (prev_cursor >= wcol - 1)
         msgstr (SNULL, COL_MSG);

      position_cursor (row, cursor + POOPCOL - first);
      prev_cursor = cursor;

      /* Get a character or a command token */
      c = gettok (NO);

      if (c >= 0 || c == TT_LITERAL) {
         /* Literal characters: */
         if (c == TT_LITERAL) {   /* Take next char literally */
            msgstr (SLITERAL, LITERAL_MSG);
            position_cursor (row, cursor + POOPCOL - first);
            
            if ((c = gettok (YES)) == '\r')
               c = NEWLINE;

            msgstr (SNULL, LITERAL_MSG);
            position_cursor (row, cursor + POOPCOL - first);
         }

         if (Insert_mode)
            status = insert (1, &nlpos, cursor, lin);
         else if (cursor >= MAXLINE - 2) {
            status = ERR;
            msgstr (SMARGIN, CHAR_MSG);
         }

         if (status != ERR) {
            lin[cursor++] = c;
            if (nlpos < cursor)
               nlpos = cursor;

            if (c == NEWLINE)
               termcode = TERM_SAME;
         }
      }
      else
         switch (c) {  /* Branch on command token value */

         /* Date and time functions: */
         case TT_DATE:
         case TT_TIME:
         case TT_DAY2:
         case TT_MONTH2:
         case TT_MONTH:
         case TT_YEAR2:
         case TT_YEAR4:
            mkdatestr (spcstr, c);
            status = stuff_string (spcstr, &nlpos, &cursor, lin);
            break;
            
         /* Miscellanous string functions: */
         case TT_CURLN:
            sprintf ((char *)spcstr, "%d", Curln);
            status = stuff_string (spcstr, &nlpos, &cursor, lin);
            break;

         case TT_TOPLN:
            sprintf ((char *)spcstr, "%d", Topln);
            status = stuff_string (spcstr, &nlpos, &cursor, lin);
            break;

         case TT_LASTLN:
            sprintf ((char *)spcstr, "%d", Lastln);
            status = stuff_string (spcstr, &nlpos, &cursor, lin);
            break;
            
         case TT_FILENAME:
            if ((savfil = get_filename ()) != NULL)
               status = stuff_string (savfil, &nlpos, &cursor, lin);
            break;
            
         case TT_USERNAME:
            status = stuff_string (usrname (), &nlpos, &cursor, lin);
            break;
            
         case TT_HOSTNAME:
            status = stuff_string (sysname (), &nlpos, &cursor, lin);
            break;
            
         /* Case mapping functions: */
         case TT_UPPER:
         case TT_LOWER:
            chr = lin[cursor];
            
            if (c == TT_UPPER && islower (chr))
               chr = toupper (chr);
            else if (c == TT_LOWER && isupper (chr)) 
               chr = tolower (chr);

            lin[cursor] = chr;

            break;
            
         /* Leftward cursor functions: */
         case TT_LEFT:
            status = set_cursor (cursor - 1, &cursor, &nlpos, lin);
            break;

         case TT_TAB_LEFT:
            tab_pos = scan_tab (SCAN_LEFT, cursor, &status);
            if (status != ERR)
               cursor = tab_pos;
            break;

         case TT_HOME:
            cursor = 0;
            break;

         case TT_FIRST_CHAR:
            for (cursor = 0; lin[cursor] == ' '; cursor++)
               ;
               
            if (cursor == nlpos)    /* Did we reach end-of-line ? */
               cursor = 0;
               
            break;
            
         case TT_SCAN_LEFT:
            scan_pos = scan_char (c, YES, cursor, nlpos, lin, &status);

            if (status != ERR)
               cursor = scan_pos;
            break;

         case TT_DEL_LEFT:
            status = set_cursor (cursor - 1, &cursor, &nlpos, lin);
            if (status != ERR)
               gobble (1, cursor, &status, &nlpos, lin);
            break;

         case TT_G_TAB_LEFT:
            tab_pos = scan_tab (SCAN_LEFT, cursor, &status);
            if (status != ERR) {
               cursor = tab_pos;
               gobble (prev_cursor - tab_pos, cursor, &status, &nlpos, lin);
            }
            break;

         case TT_KILL_LEFT:
            cursor = 0;
            gobble (prev_cursor /* - 1 */, cursor, &status, &nlpos, lin);
            break;

         case TT_G_SCAN_LEFT:
            scan_pos = scan_char (c, NO, cursor, nlpos, lin, &status);
            if (status != ERR) {
               cursor = scan_pos;
               gobble (prev_cursor - scan_pos, cursor, &status, &nlpos, lin);
            }
            break;

         /* Rightward cursor functions: */
         case TT_RIGHT:
            status = set_cursor (cursor + 1, &cursor, &nlpos, lin);
            break;

         case TT_TAB_RIGHT:
            tab_pos = scan_tab (SCAN_RIGHT, cursor, &status);
            if (status != ERR)
               status = set_cursor (tab_pos, &cursor, &nlpos, lin);
            break;

         case TT_END:
            cursor = nlpos;
            first = col1;
            break;

         case TT_LAST_CHAR:
            for (cursor = nlpos - 1; cursor > 0 && lin[cursor] == ' '; cursor--)
               ;
               
            if (cursor <= 0)
               cursor = nlpos;   /* Did we reach start-of-line ? */
            else
               cursor++;         /* Just beyond last non-blank char */
               
            first = col1;
            break;

         case TT_SCAN_RIGHT:
            scan_pos = scan_char (c, YES, cursor, nlpos, lin, &status);
            if (status != ERR)
               cursor = scan_pos;
            break;

         case TT_DEL_RIGHT:
            gobble (1, cursor, &status, &nlpos, lin);
            break;

         case TT_G_TAB_RIGHT:
            tab_pos = scan_tab (SCAN_RIGHT, cursor, &status);
            if (status != ERR)
               gobble (tab_pos - cursor, cursor, &status, &nlpos, lin);
            break;

         case TT_KILL_RIGHT:
            gobble (nlpos - cursor, cursor, &status, &nlpos, lin);
            break;

         case TT_G_SCAN_RIGHT:
            scan_pos = scan_char (c, NO, cursor, nlpos, lin, &status);
            if (status != ERR)
               gobble (scan_pos - cursor, cursor, &status, &nlpos, lin);
            break;

         /* Line termination functions: */
         case TT_T_SKIP_RIGHT:
            cursor = nlpos;
            termcode = TERM_SAME;
            break;

         case TT_T_KILL_RIGHT:
            nlpos = cursor;
            termcode = TERM_SAME;
            break;

         case TT_FUNNY:
            termcode = TERM_FUNNY;
            break;
            
         case TT_UP:
            termcode = TERM_UP;
            break;
            
         case TT_DOWN:
            termcode = TERM_DOWN;
            break;
            
         case TT_PAGE_UP:
            termcode = TERM_PGUP;
            break;
            
         case TT_PAGE_DOWN:
            termcode = TERM_PGDN;
            break;

         case TT_SCROLL_UP:
            termcode = TERM_SCUP;
            break;
            
         case TT_SCROLL_DOWN:
            termcode = TERM_SCDN;
            break;

         case TT_TOP:
            termcode = TERM_TOP;
            break;
            
         case TT_BOT:
            termcode = TERM_BOT;
            break;
            
         /* Insertion functions: */
         case TT_INSERT_BLANK:
            status = insert (1, &nlpos, cursor, lin);
            if (status != ERR)
               lin[cursor] = ' ';
            break;

         case TT_INSERT_NEWLINE:
            status = insert (1, &nlpos, cursor, lin);
            if (status != ERR) {
               lin[cursor] = NEWLINE;
               termcode = TERM_UP;
            }
            break;

         case TT_INSERT_TAB:
            while (lin[cursor] == ' ' || lin[cursor] == '\t')
               cursor++;
            tab_pos = scan_tab (SCAN_RIGHT, cursor, &status);
            if (status != ERR)
               status = insert (tab_pos - cursor, &nlpos, cursor, lin);
            if (status != ERR)
               for (; cursor < tab_pos; cursor++)
                  lin[cursor] = ' ';
            cursor = prev_cursor;
            break;

         /* Miscellaneous control functions: */
         case TT_TRANSPOSE:
            break;
            
         case TT_UNDO:
            break;
            
         case TT_TOGGLE_INSERT_MODE:
            toggle (&Insert_mode, SINSERT, SNULL, INS_MSG);
            shape_cursor (Insert_mode ? CUR_INSERT: CUR_NORMAL);
            break;

         case TT_SHIFT_CASE:
            toggle (&Invert_case, SCASE, SNULL, CASE_MSG);
            break;

         case TT_KILL_ALL:
            nlpos = cursor = 0;
            break;

         case TT_FIX_SCREEN:
            restore_screen ();
            break;

         case TT_ASCII:
            if (lin[cursor] == EOS)
               mesg ((uchar *)"NEWLINE", CHAR_MSG);
            else {
               sprintf ((char *)spcstr, "0x%02x", lin[cursor]);
               mesg (spcstr, CHAR_MSG);
            }
            status = EOF;  /* Clear CHAR_MSG on next keypress */
            break;
            
         case TT_IDENTIFY:
            identify_key ();
            break;

         case TT_NOP:
            break;
            
         case TT_UNKNOWN:
            status = ERR;
            msgstr (SWHAT, CHAR_MSG);
            break;
            
         case TT_NOTBOUND:
            status = ERR;
            msgstr (SNOTBOUND, CHAR_MSG);
            break;
            
         default:
            error (YES, "in getcmd: shouldn't happen");
            break;
         }     /* end switch */

   }        /* while (termcode == EOF) */

   lin[nlpos] = NEWLINE;
   lin[nlpos + 1] = EOS;

   /* leave the screen looking tidy... */
   load (BARSYM, row, BARCOL, BAR_ZONE);
   if (nlpos <= col1)
      loadstr ((uchar *)"", row, POOPCOL, Ncols - 1, CMD_ZONE);
   else
      loadstr (&lin[col1], row, POOPCOL, Ncols - 1, CMD_ZONE); 

   if (cursor >= wcol - 1)
      litnnum (getstring (SCOL), cursor + 1, COL_MSG);
   else if (prev_cursor >= wcol - 1)
      msgstr (SNULL, COL_MSG);

   *curpos = cursor;
   
   return (termcode);
}


/* show_lnum --- display line number according to 'Nchoise' */

static void show_lnum ()
{
   uchar str[10];     /* For 'ol%' */
   long int pc;
   static string dollar = "$=";
   static string hash   = "#=";

   switch (Nchoise) {
   case CURLINE:
      litnnum (getstring (SLINE), Curln, LINE_MSG);
      break;
   case LASTLINE:
      litnnum (dollar, Lastln, LINE_MSG);
      break;
   case TOPLINE:
      litnnum (hash, Topln, LINE_MSG);
      break;
   case PERCENT:        /* Note that we avoid F.P. arithmetic here */
      if (Lastln == 0)        /* DON'T divide by zero ! */
         strucpy (str, "0%");
      else {
         pc = ((long int)Curln * 100L) / (long int)Lastln;
         sprintf ((char *)str, "%ld%%", pc);
      }

      mesg (str, LINE_MSG);
      break;
   default:
      msgstr (SNULL, LINE_MSG);
      break;
   }
}


/* scan_char --- scan current line for a character */

static int scan_char (chr, wrap, cursor, nlpos, lin, status)
int chr;
bool wrap;
int cursor;
int nlpos;
const uchar *lin;   
int *status;
{
   register uchar c;
   register int inc, scan_pos;

   c = gettok (YES);

   if (c == chr)
      c = Last_char_scanned;

   Last_char_scanned = c;

   if (chr == SCAN_LEFT)
      inc = -1;
   else
      inc = 1;

   /* NOTE:  modify this code AT YOUR OWN RISK! */
   scan_pos = cursor;
   do {
      if (scan_pos < 0) {
         if (wrap)
            scan_pos = nlpos;
         else
            break;
      }
      else if (scan_pos > nlpos) {
         if (wrap)
            scan_pos = 0;
         else
            break;
      }
      else
         scan_pos += inc;

      if (-1 < scan_pos && scan_pos < nlpos && lin[scan_pos] == c)
         break;
   } while (scan_pos != cursor);

   if (scan_pos < 0 || scan_pos >= nlpos || lin[scan_pos] != c) {
      *status = ERR;
      msgstr (SNOCHAR, CHAR_MSG);
   }

   return (scan_pos);
}


/* scan_tab --- scan left or right for a tabstop */

static int scan_tab (dir, cursor, status)
int dir;
int cursor;
int *status;
{
   register int inc, tab_pos;

   if (dir == SCAN_LEFT) {
      inc = -1;
      tab_pos = cursor - 1;
   }
   else {
      inc = 1;
      tab_pos = cursor + 1;
   }

   for (; -1 < tab_pos && tab_pos < MAXLINE; tab_pos += inc)
      if (Tabstops[tab_pos] == YES)
         break;

   if (tab_pos < 0 || tab_pos >= MAXLINE - 1) {
      *status = ERR;
      msgstr (SMARGIN, CHAR_MSG);
   }

   return (tab_pos);
}


/* gobble --- delete characters starting at the current cursor position */

static void gobble (len, cursor, status, nlpos, lin)
int len;
int cursor;
int *status;
int *nlpos;
uchar *lin;
{
   if (cursor + len > *nlpos) {
      *status = ERR;
      msgstr (SMARGIN, CHAR_MSG);
   }
   else if (len > 0) {
      strucpy (&lin[cursor], &lin[cursor + len]);
      *nlpos -= len;
   }
}


/* insert --- shift characters right starting at the current cursor position */

static int insert (len, nlpos, cursor, lin)
register int len;
register int *nlpos;
int cursor;
register uchar *lin;
{
   register int fr, to;

   if (*nlpos + len >= MAXLINE - 1) {
      msgstr (SMARGIN, CHAR_MSG);
      return (ERR);
   }
   else {
      for (fr = *nlpos, to = *nlpos + len; fr >= cursor; fr--, to--)
         lin[to] = lin[fr];

      *nlpos += len;
      return (OK);
   }
}


/* set_cursor --- move the cursor, extend line if necessary */

static int set_cursor (pos, cursor, nlpos, lin)
register int pos;
register int *cursor;
register int *nlpos;
register uchar *lin;
{
   if (pos < 0 || pos >= MAXLINE - 1) {
      msgstr (SMARGIN, CHAR_MSG);
      return (ERR);
   }
   else {
      *cursor = pos;
      for (; *nlpos < *cursor; (*nlpos)++)
         lin[*nlpos] = ' ';
         
      return (OK);
   }
}


/* stuff_string --- type in a string as if the user had typed it */

static int stuff_string (str, nlp, cursor, lin)
const uchar *str;
int *nlp;
int *cursor;
uchar *lin;
{
   int len;
   register int i;
   int status = OK;
   
   len = strulen (str);
   
   if (Insert_mode)
      status = insert (len, nlp, *cursor, lin);
   else if (*cursor >= MAXLINE - (len + 1)) {
      status = ERR;
      msgstr (SMARGIN, CHAR_MSG);
   }
            
   if (status != ERR) {
      for (i = 0; i < len; i++)
         lin[(*cursor)++] = str[i];
               
      if (*nlp < *cursor)
         *nlp = *cursor;
   }
   
   return (status);
}
