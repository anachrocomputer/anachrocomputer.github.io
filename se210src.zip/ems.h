/* ems --- header file for EMS library functions            20/07/1989 */
/* Copyright (c) 1989 BJ, Froods Software Development                  */

#define ENULL        0L

/* EMS memory pointer */
typedef unsigned long int emsptr;


int emsinit (long int limit);
int emsclose (void);
emsptr emsalloc (unsigned int sz);
void emsfree (emsptr p);
int emsread (void *mem, unsigned int sz, emsptr ems);
int emswrite (const void *mem, unsigned int sz, emsptr ems);

#ifdef DB
void DumpFreeChain (void);
#endif   /* DB */
