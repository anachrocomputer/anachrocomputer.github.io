/* xdisplay --- X-Windows driver for 'se'                   11/02/1992 */
/* Copyright (c) 1992 BJ, Froods Software Development                  */

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

#include "keys.h"
#include "se0.xbm"   /* Normal icon */
#include "se1.xbm"   /* Inverse video icon */

/* #define DB */
#define MAXZONE 20

#define NORMAL       0
#define INVERSE      1
#define UNDERLINE    2
#define BOLD         4

#define BLACK           0
#define BLUE            1
#define GREEN           2
#define CYAN            3
#define RED             4
#define MAGENTA         5
#define YELLOW          6
#define WHITE           7
#define BRIGHT          8

struct Screen {
   unsigned char ch;
   unsigned char zn;
};

string Smachine = "X Windows";

static struct Screen Screen_image[MAXROWS][MAXCOLS];
static struct Screen Blanks[MAXCOLS];
static int Currow, Curcol;

static bool Started = NO;
static Display *Dpy;
static Window Win;
static GC Zone_gc[MAXZONE];     /* GCs for each screen zone  */
static GC Clrz_gc[MAXZONE];     /* GCs for 'clear_to_eol ()' */
static GC CursorGc;
static int Fonth;
static int Fontw;
static int Fontd;
static bool In_focus = NO;

#if NO_PROTOTYPES
static void clear_to_eol ();
static void repaint_rect ();
static bool keyhit ();
static bool mclick ();
static void draw_cursor ();
#else
static void clear_to_eol (int row, int col, int zone);
static void repaint_rect (int r1, int c1, int r2, int c2);
static bool keyhit (const XKeyEvent *xk, int *pk);
static bool mclick (const XButtonEvent *xb, int *pk);
static void draw_cursor (bool draw);
#endif


/* load --- load a character into the screen image */

void load (ch, row, col, zone)
register int ch;
register int row, col;
int zone;
{
   struct Screen chz;
   char tmp[2];
   
   if (ch < ' ' || ch == DEL) {
      chz.ch = Unprintable;
      chz.zn = UPRT_ZONE;
   }
   else {
      chz.ch = ch;
      chz.zn = zone;
   }
   
   tmp[0] = chz.ch;
   tmp[1] = EOS;

   if (Screen_image[row][col].ch != chz.ch || Screen_image[row][col].zn != chz.zn) {
      Screen_image[row][col] = chz;
      XDrawImageString (Dpy, Win, Zone_gc[chz.zn], col * Fontw, (row * Fonth) + Fontd, tmp, 1);
   }
   
   /* Did we scribble over the cursor ? */
   if (row == Currow && col == Curcol)
      draw_cursor (YES);
}


/* loadstr --- load a string into a field of the screen */

void loadstr (str, row, stcol, endcol, zone)
register const uchar *str;
int row, stcol, endcol;
int zone;
{
   struct Screen chz;
   char tmp[2];
   register int p, c, limit;

   if (row >= 0 && row < Nrows && stcol >= 0) {
      for (p = 0, c = stcol; str[p] != EOS && c < Ncols; p++, c++) {
         if (str[p] < ' ' || str[p] == DEL) {
            chz.ch = Unprintable;
            chz.zn = UPRT_ZONE;
         }
         else {
            chz.ch = str[p];
            chz.zn = zone;
         }

         tmp[0] = chz.ch;
         tmp[1] = EOS;

         if (Screen_image[row][c].ch != chz.ch || Screen_image[row][c].zn != chz.zn) {
            Screen_image[row][c] = chz;
            XDrawImageString (Dpy, Win, Zone_gc[chz.zn], c * Fontw, (row * Fonth) + Fontd, tmp, 1);
         }
      }

      if (endcol >= Ncols - 1 && c < Ncols - 1)
         clear_to_eol (row, c, zone);
      else {
         chz.ch = ' ';
         chz.zn = zone;
         tmp[0] = chz.ch;
         tmp[1] = EOS;
         
         limit = (endcol < Ncols - 1) ? endcol : Ncols - 1;

         for (; c <= limit; c++)
            if (Screen_image[row][c].ch != chz.ch || Screen_image[row][c].zn != chz.zn) {
               Screen_image[row][c] = chz;
               XDrawImageString (Dpy, Win, Zone_gc[zone], c * Fontw, (row * Fonth) + Fontd, tmp, 1);
            }
      }
   }
   
   if (row == Currow)
      draw_cursor (YES);
}


/* cprow --- copy from one row to another for append */

void cprow (from, to)
register int from, to;
{
   register int col;

   for (col = 0; col < Ncols; col++)
      load (Screen_image[from][col].ch, to, col, TEXT_ZONE);
}


/* mdvd_init --- initialise this module */

void mdvd_init ()
{
   int r, c;
   
   for (c = 0; c < MAXCOLS; c++) {
      Blanks[c].ch = ' ';
      Blanks[c].zn = TEXT_ZONE;
   }

   for (r = 0; r < MAXROWS; r++)
      for (c = 0; c < MAXCOLS; c++) {
         Screen_image[r][c].ch = ' ';
         Screen_image[r][c].zn = TEXT_ZONE;
      }
}


/* shape_cursor --- set cursor shape or size */

void shape_cursor (size)
int size;
{
}


/* ringbell --- generate bleeping noises */

void ringbell (type)
int type;
{
   int vol;
   
   if (Quiet)
      return;
      
   switch (type) {
   case MAIL_BELL:
   case WARN_BELL:
   case CHAR_BELL:
      vol = -50;
      break;
   case ERR_BELL:
      vol = 0;
      break;
   }
   
   XBell (Dpy, vol);
}


/* mvinch --- return character at (r,c) */

int mvinch (r, c)
int r, c;
{
   return (Screen_image[r][c].ch);
}


/* setcolr --- set a zone colour in the colour map */

void setcolr (zone, fg, bg)
int zone;
int fg, bg;
{
}


/* restore_screen --- screen has been garbaged - fix it */

void restore_screen ()
{
   XClearWindow (Dpy, Win);
   repaint_rect (0, 0, Nrows - 1, Ncols - 1);
   msgstr (SNULL, REMARK_MSG);
}


/* shellcolr --- set the colour of the shell */

void shellcolr()
{
}


/* term_init --- send start-up sequence to terminal */

void term_init ()
{
}


/* term_exit --- send close-down sequence to terminal */

void term_exit ()
{
   int i;
   
   if (Started) {
      for (i = 0; i < MAXZONE; i++) {
         XFreeGC (Dpy, Zone_gc[i]);
         XFreeGC (Dpy, Clrz_gc[i]);
      }
         
      XFreeGC (Dpy, CursorGc);
      XDestroyWindow (Dpy, Win);
      XCloseDisplay (Dpy);
   }
}


/* clrscreen --- clear physical screen */

void clrscreen ()
{
   XClearWindow (Dpy, Win);
}


/* position_cursor --- position terminal's cursor to (row, col) */

void position_cursor (row, col)
int row, col;
{
   if (row < Nrows && row >= 0        /* within vertical range? */
       && col < Ncols && col >= 0     /* within horizontal range? */
       && (row != Currow || col != Curcol)) { /* not already there? */

      draw_cursor (NO);    /* Erase old cursor */

      Currow = row;
      Curcol = col;

      draw_cursor (YES);   /* Draw new one */
   }
}


/* inslines --- insert 'n' lines on the screen at 'row' */

void inslines (row, n)
int row, n;
{
   register int i;
   int w, h;
   int srcy, dsty;
   
   w = Ncols * Fontw;
   h = (Nrows - row - n) * Fonth;
   
   srcy = (row) * Fonth;
   dsty = (row + n) * Fonth;
   
   draw_cursor (NO);
   XCopyArea (Dpy, Win, Win, CursorGc, 0, srcy, w, h, 0, dsty);
   XClearArea (Dpy, Win, 0, srcy, w, n * Fonth, False);
   draw_cursor (YES);

   for (i = Nrows - 1; i - n >= row; i--)
      memcpy (Screen_image[i], Screen_image[i - n], Ncols * sizeof (struct Screen));

   for (; i >= row; i--)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (struct Screen));
}


/* dellines --- delete 'n' lines beginning at 'row' */

void dellines (row, n)
int row, n;
{
   register int i;
   int w, h;
   int srcy, dsty;
   
   w = Ncols * Fontw;
   h = (Nrows - row - n) * Fonth;
   
   srcy = (row + n) * Fonth;
   dsty = (row) * Fonth;
   
   draw_cursor (NO);
   XCopyArea (Dpy, Win, Win, CursorGc, 0, srcy, w, h, 0, dsty);
   XClearArea (Dpy, Win, 0, (Nrows - n) * Fonth, w, n * Fonth, False);
   draw_cursor (YES);

   for (i = row; i + n < Nrows; i++)
      memcpy (Screen_image[i], Screen_image[i + n], Ncols * sizeof (struct Screen));

   for (; i < Nrows; i++)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (struct Screen));
}


/* clear_to_eol --- clear screen to end-of-line */

static void clear_to_eol (row, col, zone)
int row, col, zone;
{
   register int c;
   int width;
   bool do_it;
   
   width = (Ncols - col) * Fontw;
   do_it = NO;

   for (c = col; c < Ncols; c++) {
      if (Screen_image[row][c].ch != ' ' || Screen_image[row][c].zn != zone) {
         Screen_image[row][c].ch = ' ';
         Screen_image[row][c].zn = zone;
         do_it = YES;
      }
   }
   
   if (do_it) {
      XFillRectangle (Dpy, Win, Clrz_gc[zone], col * Fontw, row * Fonth, width, Fonth);
   }
}


/* set_term --- initialise terminal parameters and actual capabilities */

int set_term (type, hwinsdel, r, c)
const uchar *type;
bool *hwinsdel;
int *r, *c;
{
   int i;
   long int black, white;
   long int fg, bg;
   int width, height;
   XWMHints hint;
   XSizeHints s_hint;
   static char *wlist[] = {
      "X Screen Editor"
   };
   static char *ilist[] = {
      "XSE"
   };
   XTextProperty wname, iname;
   static char *cnames[] = {
      "black",    /* 0 */
      "blue4",    /* 1 */
      "green4",   /* 2 */
      "cyan4",    /* 3 */
      "red4",     /* 4 */
      "magenta4", /* 5 */
      "yellow4",  /* 6 */
      "gray54",   /* 7 */
      "gray27",   /* 8 */
      "blue",     /* 9 */
      "green",    /* 10*/
      "cyan",     /* 11*/
      "red",      /* 12*/
      "magenta",  /* 13*/
      "yellow",   /* 14*/
      "white"     /* 15*/
   };
   bool mono;
   static int mono_map[MAXZONE] = {
      NORMAL,
      NORMAL,        /* Text                       */
      NORMAL,        /* Bar                        */
      NORMAL,        /* Command line               */
      NORMAL,        /* Line one                   */
      NORMAL,        /* Line $                     */
      NORMAL,        /* Status line                */
      BOLD,          /* Messages on status line    */
      NORMAL,        /* Line numbers               */
      BOLD,          /* Mark column                */
      NORMAL,        /* Current line               */
      NORMAL,        /* Help messages              */
      BOLD,          /* Dashes in 'split-screen'   */
      NORMAL,        /* Prompts                    */
      BOLD,          /* Unprintable characters     */
      NORMAL,        /* Shell                      */
      INVERSE,       /* Source-code comments       */
      BOLD,          /* reserved words             */
      NORMAL,        /* Source-code strings        */
      BOLD           /* Source-code pre-proc cmds  */
   };
   static struct {
      short int fg;
      short int bg;
      short int flags;
   } colour_map[MAXZONE] = {
      {0, 0, 0},
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Text                       */
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Bar                        */
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Command line               */
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Line one                   */
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Line $                     */
      {GREEN   | BRIGHT, BLACK, NORMAL},  /* Status line                */
      {GREEN   | BRIGHT, BLACK, BOLD},    /* Messages on status line    */
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Line numbers               */
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Mark column                */
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Current line               */
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Help messages              */
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Dashes in 'split-screen'   */
      {RED     | BRIGHT, BLACK, NORMAL},  /* Prompts                    */
      {YELLOW  | BRIGHT, BLACK, NORMAL},  /* Unprintable characters     */
      {WHITE   | BRIGHT, BLACK, NORMAL},  /* Shell                      */
      {CYAN    | BRIGHT, BLACK, NORMAL},  /* Source-code comments       */
      {WHITE   | BRIGHT, BLACK, BOLD},    /* Source-code reserved words */
      {MAGENTA | BRIGHT, BLACK, NORMAL},  /* Source-code strings        */
      {RED     | BRIGHT, BLACK, BOLD}     /* Source-code pre-proc cmds. */
   };
   Colormap cmap;
   XColor exact;
   XColor fghue;
   XColor bghue;
   int scr;       /* Screen number */
   static char normal[] = "-misc-fixed-medium-r-normal--13-*-*-*-c-*-iso8859-1";
   static char bold[]   = "-misc-fixed-bold-r-normal--13-*-*-*-c-*-iso8859-1";
   XFontStruct *nfont;
   XFontStruct *bfont;
   char errmsg[MAXLINE];
   char *p;
   
   /* Start with a reasonably big screen */
   *c = 80;
   *r = 25;
   
   /* Open that display */
   if ((Dpy = XOpenDisplay ("")) == NULL)
      error (NO, "Cannot open X display");
      
   scr = DefaultScreen (Dpy);
   
   /* Colour or mono? */
   if (XDisplayPlanes (Dpy, scr) == 1)
      mono = YES;
   else
      mono = NO;
      
   /* Look up resources */
#ifdef DB
   if ((p = XGetDefault (Dpy, "xse", "font")) == NULL)
      printf ("Failed\n");
   else
      printf ("Value is '%s'\n", p);
#endif   /* DB */

   /* Open normal & bold fonts */
   nfont = XLoadQueryFont (Dpy, normal);
   bfont = XLoadQueryFont (Dpy, bold);
   
   if (nfont == NULL) {
      sprintf (errmsg, "cannot open medium font '%s'", normal);
      error (NO, errmsg);
   }
   
   if (bfont == NULL) {
      sprintf (errmsg, "cannot open bold font '%s'", bold);
      error (NO, errmsg);
   }
   
#ifdef DB
   printf ("Normal: ascent = %d, descent = %d\n", nfont->ascent, nfont->descent);
   printf ("Bold:   ascent = %d, descent = %d\n", bfont->ascent, bfont->descent);
   printf ("Normal: width = %d\n", nfont->max_bounds.width);
   printf ("Bold:   width = %d\n", bfont->max_bounds.width);
#endif   /* DB */

   Fonth = nfont->ascent + nfont->descent;
   Fontw = nfont->max_bounds.width;
   Fontd = nfont->ascent;

   width  = Fontw * (*c);
   height = Fonth * (*r);
   
   black = BlackPixel (Dpy, scr);
   white = WhitePixel (Dpy, scr);

   /* Create a window with proper background colour */
   if (mono) {
      fg = black;
      bg = white;
   }
   else {
      fg = white;
      bg = black;
   }
   
   Win = XCreateSimpleWindow (Dpy, DefaultRootWindow (Dpy),
                              0, 0, width, height, 2, fg, bg);

   /* Set up the window and icon names */
   XStringListToTextProperty (wlist, 1, &wname);
   XStringListToTextProperty (ilist, 1, &iname);
   
   XSetWMProperties (Dpy, Win, &wname, &iname, NULL, 0, NULL, NULL, NULL);
   
   /* Set up the icon bitmap */
   hint.flags = IconPixmapHint;
   hint.icon_pixmap = XCreateBitmapFromData (Dpy, Win, se0_bits, se0_width, se0_height);
   XSetWMHints (Dpy, Win, &hint);
   
   /* Set up the resize increment */
   s_hint.flags = PResizeInc /* | PMinSize */;
/* s_hint.min_width = 10 * Fontw; */
/* s_hint.min_height = 4 * Fonth; */
   s_hint.width_inc = Fontw;
   s_hint.height_inc = Fonth;
   XSetWMNormalHints (Dpy, Win, &s_hint);

   /* Start setting colours and fonts in the GC array */
   cmap = XDefaultColormap (Dpy, scr);
   
   for (i = 0; i < MAXZONE; i++) {
      Zone_gc[i] = XCreateGC (Dpy, Win, 0, 0);
      Clrz_gc[i] = XCreateGC (Dpy, Win, 0, 0);

      if (mono) {
         if (mono_map[i] & INVERSE) {
            fg = white;
            bg = black;
         }
         else {
            fg = black;
            bg = white;
         }
         
         if (mono_map[i] & BOLD) {
            XSetFont (Dpy, Zone_gc[i], bfont->fid);
         }
         else {
            XSetFont (Dpy, Zone_gc[i], nfont->fid);
         }
      }
      else {   /* Colour */
         fg = colour_map[i].fg;
         bg = colour_map[i].bg;
         
         XAllocNamedColor (Dpy, cmap, cnames[fg], &fghue, &exact);
         XAllocNamedColor (Dpy, cmap, cnames[bg], &bghue, &exact);
         
         fg = fghue.pixel;
         bg = bghue.pixel;

         if (colour_map[i].flags & BOLD) {
               XSetFont (Dpy, Zone_gc[i], bfont->fid);
         }
         else {
               XSetFont (Dpy, Zone_gc[i], nfont->fid);
         }
      }
      
      XSetBackground (Dpy, Zone_gc[i], bg);
      XSetForeground (Dpy, Zone_gc[i], fg);
      
      /* Same again, but reversed */
      XSetBackground (Dpy, Clrz_gc[i], fg);
      XSetForeground (Dpy, Clrz_gc[i], bg);
   }
   
   CursorGc = XCreateGC (Dpy, Win, 0, 0);
   XSetFont (Dpy, CursorGc, nfont->fid);
   
   /* Make up black & white GCs */
   if (mono) {
      XSetBackground (Dpy, CursorGc, black);
      XSetForeground (Dpy, CursorGc, white);
   }
   else {
      XSetBackground (Dpy, CursorGc, white);
      XSetForeground (Dpy, CursorGc, black);
   }
   
   /* Nominate event masks */
   XSelectInput (Dpy, Win, ButtonPressMask | KeyPressMask | KeyReleaseMask | ExposureMask
                           | FocusChangeMask | StructureNotifyMask);
   
   /* Open the window at last */
   XMapRaised (Dpy, Win);

   Started = YES;
   
   *hwinsdel = YES;

   return (OK);
}


/* term_name --- return the name of the terminal */

uchar *term_name ()
{
   return ((uchar *)"X Window System");
}


void ttyedit ()
{
}


void ttynormal ()
{
}


/* tflush --- clear out the terminal output buffer */

void tflush ()
{
   XSync (Dpy, False);
}


/* readkey --- read a single keystroke */

int readkey (israw)
bool israw;
{
   int key;
   int r1, c1;
   int r2, c2;
   XEvent e;
   KeySym xkey;
   XWMHints hint;
   char text[10];
   int i;
   bool done;
   static char *ilist[2];
   XTextProperty iname;

   /* Flush any buffered output before reading */
   XSync (Dpy, False);

   done = NO;
   key = NOKEY;

   while (done == NO) {
      XNextEvent (Dpy, &e);
      
      switch (e.type) {
      case GraphicsExpose:
/*       printf ("GraphicsExpose: (%d,%d) %d %d\n", e.xexpose.x, e.xexpose.y, e.xexpose.width, e.xexpose.height); */
      case Expose:
         c1 = e.xexpose.x / Fontw;
         r1 = e.xexpose.y / Fonth;
         c2 = (e.xexpose.x + e.xexpose.width) / Fontw;
         r2 = (e.xexpose.y + e.xexpose.height) / Fonth;
   
         repaint_rect (r1, c1, r2, c2);
         break;
      case MappingNotify:
         XRefreshKeyboardMapping (&e);
         break;
      case ButtonPress:
         done = mclick (&e.xbutton, &key);
         break;
      case FocusOut:
#ifdef DB
         puts ("FocusOut");
#endif   /* DB */
         In_focus = NO;
         draw_cursor (YES);
         break;
      case FocusIn:
#ifdef DB
         puts ("FocusIn");
#endif   /* DB */
         In_focus = YES;
         draw_cursor (YES);
         break;
      case ResizeRequest:
#ifdef DB
         puts ("ResizeRequest");
#endif   /* DB */
         break;
      case ConfigureNotify:
         r1 = e.xconfigure.height / Fonth;
         c1 = e.xconfigure.width  / Fontw;

#ifdef DB
         if (r1 != Nrows || c1 != Ncols)
            printf ("Resize: %d %d -> %d %d\n", Nrows, Ncols, r1, c1);
#endif   /* DB */

         break;
      case UnmapNotify:
/*       puts ("UnmapNotify"); */
         if (Buffer_changed)
            hint.icon_pixmap = XCreateBitmapFromData (Dpy, Win, se1_bits, se1_width, se1_height);
         else
            hint.icon_pixmap = XCreateBitmapFromData (Dpy, Win, se0_bits, se0_width, se0_height);

         hint.flags = IconPixmapHint;
         XSetWMHints (Dpy, Win, &hint);

         ilist[0] = (char *)get_filename ();
         XStringListToTextProperty (ilist, 1, &iname);
         XSetWMProperties (Dpy, Win, NULL, &iname, NULL, 0, NULL, NULL, NULL);
         break;
      case MapNotify:
/*       puts ("MapNotify"); */
         break;
      case KeyRelease:
         i = XLookupString (&e, text, 10, &xkey, 0);
/*       printf ("i = %d, xkey = 0x%x - %s\n", i, xkey, XKeysymToString (xkey)); */

         if (xkey == XK_Caps_Lock)
            msgstr (SNULL, CAPS_MSG);
            
         break;
      case KeyPress:
         done = keyhit (&e.xkey, &key);
         break;
      }
   }
   
   return (key);
}



/* repaint_rect --- redraw a portion of the screen */

static void repaint_rect (r1, c1, r2, c2)
int r1, c1;
int r2, c2;
{
   register int r, c, i;
   char lin[2];
   int zone;
   
   for (r = r1; r <= r2; r++) {
      for (c = c1; c <= c2; c++) {
         lin[0] = Screen_image[r][c].ch;
         lin[1] = EOS;
         zone =   Screen_image[r][c].zn;
         
         if (lin[0] == ' ')
            continue;
            
         XDrawImageString (Dpy, Win, Zone_gc[zone], c * Fontw, (r * Fonth) + Fontd, lin, 1);
      }
   }

   draw_cursor (YES);
}


/* keyhit --- deal with all key press events */

static bool keyhit (xk, pk)
const XKeyEvent *xk;
int *pk;
{
   struct keymap {
      KeySym xkey;
      int sekey;
   };
   XComposeStatus cs;
   register int i;
   KeySym xkey;
   char text[10];
   int key;
   struct keymap *tp;
   int lim;
   static struct keymap keytab[] = {
      {XK_F1,        F1},
      {XK_F2,        F2},
      {XK_F3,        F3},
      {XK_F4,        F4},
      {XK_F5,        F5},
      {XK_F6,        F6},
      {XK_F7,        F7},
      {XK_F8,        F8},
      {XK_F9,        F9},
      {XK_F10,       F10},
      {XK_F11,       F11},
      {XK_F12,       F12},
      {XK_F13,       F13},
      {XK_F14,       F14},
      {XK_F15,       F15},
      {XK_F16,       F16},
      {XK_F17,       F17},
      {XK_F18,       F18},
      {XK_F19,       F19},
      {XK_F20,       F20},
      {XK_Left,      CLEFT},
      {XK_Right,     CRIGHT},
      {XK_Up,        CUP},
      {XK_Down,      CDOWN},
      {XK_Prior,     PUP},
      {XK_Next,      PDOWN},
      {XK_Insert,    CINSERT},
      {XK_Delete,    CDELETE},
      {XK_Home,      CHOME},
      {XK_End,       CEND},
      {XK_Help,      CHELP},
      {XK_Undo,      CUNDO}
   };
   static struct keymap ctrlkeytab[] = {
      {XK_F1,        C_F1},
      {XK_F2,        C_F2},
      {XK_F3,        C_F3},
      {XK_F4,        C_F4},
      {XK_F5,        C_F5},
      {XK_F6,        C_F6},
      {XK_F7,        C_F7},
      {XK_F8,        C_F8},
      {XK_F9,        C_F9},
      {XK_F10,       C_F10},
      {XK_F11,       C_F11},
      {XK_F12,       C_F12},
      {XK_F13,       C_F13},
      {XK_F14,       C_F14},
      {XK_F15,       C_F15},
      {XK_F16,       C_F16},
      {XK_F17,       C_F17},
      {XK_F18,       C_F18},
      {XK_F19,       C_F19},
      {XK_F20,       C_F20},
      {XK_Left,      C_CLEFT},
      {XK_Right,     C_CRIGHT},
      {XK_Up,        C_CUP},
      {XK_Down,      C_CDOWN},
      {XK_Prior,     C_PUP},
      {XK_Next,      C_PDOWN},
      {XK_Insert,    C_CINSERT},
      {XK_Home,      C_CHOME},
      {XK_End,       C_CEND}
   };
   static struct keymap shiftkeytab[] = {
      {XK_F1,        S_F1},
      {XK_F2,        S_F2},
      {XK_F3,        S_F3},
      {XK_F4,        S_F4},
      {XK_F5,        S_F5},
      {XK_F6,        S_F6},
      {XK_F7,        S_F7},
      {XK_F8,        S_F8},
      {XK_F9,        S_F9},
      {XK_F10,       S_F10},
      {XK_F11,       S_F11},
      {XK_F12,       S_F12},
      {XK_F13,       S_F13},
      {XK_F14,       S_F14},
      {XK_F15,       S_F15},
      {XK_F16,       S_F16},
      {XK_F17,       S_F17},
      {XK_F18,       S_F18},
      {XK_F19,       S_F19},
      {XK_F20,       S_F20},
   };
   static struct keymap altkeytab[] = {
      {XK_F1,        A_F1},
      {XK_F2,        A_F2},
      {XK_F3,        A_F3},
      {XK_F4,        A_F4},
      {XK_F5,        A_F5},
      {XK_F6,        A_F6},
      {XK_F7,        A_F7},
      {XK_F8,        A_F8},
      {XK_F9,        A_F9},
      {XK_F10,       A_F10},
      {XK_F11,       A_F11},
      {XK_F12,       A_F12},
      {XK_F13,       A_F13},
      {XK_F14,       A_F14},
      {XK_F15,       A_F15},
      {XK_F16,       A_F16},
      {XK_F17,       A_F17},
      {XK_F18,       A_F18},
      {XK_F19,       A_F19},
      {XK_F20,       A_F20},
      {XK_Left,      A_CLEFT},
      {XK_Right,     A_CRIGHT},
      {XK_Up,        A_CUP},
      {XK_Down,      A_CDOWN},
      {XK_Prior,     A_PUP},
      {XK_Next,      A_PDOWN},
      {XK_Insert,    A_CINSERT},
      {XK_Home,      A_CHOME},
      {XK_End,       A_CEND}
   };
#define MAXKEYMAPPINGS(tab) (sizeof (tab) / sizeof (tab[0]))

   *pk = NOKEY;

   i = XLookupString (xk, text, 10, &xkey, &cs);
   
   if (xkey == XK_Caps_Lock)
      msgstr (SCAPS, CAPS_MSG);
      
   if (i == 1) {           /* Single ASCII character */
      key = text[0];

      if (key == DEL)
         key = CDELETE;
      else if (key < ' ')
         key = -key;
      else if (xk->state & Mod1Mask) {    /* ALT pressed */
         if (isalpha (key)) {
            if (isupper (key))
               key = A_A - (key - 'A');
            else
               key = A_A - (key - 'a');
         }
         else if (isdigit (key)) {
            key = A_0 - (key - '0');
         }
         else     /* Unrecognised ALT key */
            key = NOKEY;
      }

      *pk = key;
      return (YES);
   }
   else {         /* Function or cursor control key */
      if (xk->state & ControlMask) {
         tp = ctrlkeytab;
         lim = MAXKEYMAPPINGS(ctrlkeytab);
      }
      else if (xk->state & ShiftMask) {
         tp = shiftkeytab;
         lim = MAXKEYMAPPINGS(shiftkeytab);
      }
      else if (xk->state & Mod1Mask) {
         tp = altkeytab;
         lim = MAXKEYMAPPINGS(altkeytab);
      }
      else {
         tp = keytab;
         lim = MAXKEYMAPPINGS(keytab);
      }

      for (i = 0; i < lim; i++, tp++)
         if (tp->xkey == xkey) {
            *pk = tp->sekey;
            return (YES);
         }
         
#ifdef DB
      printf ("Unknown X key: %x (%s) Modifiers: %x\n", xkey, XKeysymToString (xkey), xk->state);
#endif   /* DB */
   }

   return (NO);
}


/* mclick --- handle mouse button clicks */

static bool mclick (xb, pk)
const XButtonEvent *xb;
int *pk;
{
   int key;
   int i, nb;
   char *p;
   
#ifdef DB
   printf ("Button %d pressed at (%d, %d)\n", xb->button, xb->x, xb->y);
   printf ("Shift is %s\n", (xb->state & ShiftMask) ? "down": "up");
   printf ("Control is %s\n", (xb->state & ControlMask) ? "down": "up");
   printf ("Alt is %s\n", (xb->state & Mod1Mask) ? "down": "up");
#endif

   key = NOKEY;
   
   if (xb->state & ControlMask) {
      switch (xb->button) {
      case 1:
         key = C_LMB;
         break;
      case 2:
         key = C_MMB;
         break;
      case 3:
         key = C_RMB;
         break;
      }
   }
   else if (xb->state & ShiftMask) {
      switch (xb->button) {
      case 1:
         key = S_LMB;
         break;
      case 2:
         key = S_MMB;
         break;
      case 3:
         key = S_RMB;
         break;
      }
   }
   else if (xb->state & Mod1Mask) {
      switch (xb->button) {
      case 1:
         key = A_LMB;
         break;
      case 2:
         key = A_MMB;
         break;
      case 3:
         key = A_RMB;
         break;
      }
   }
   else {
      switch (xb->button) {
      case 1:
         key = LMB;
         break;
      case 2:
         key = MMB;
#ifdef DB
         if ((p = XFetchBytes (Dpy, &nb)) != NULL) {
            printf ("%d bytes to paste: '", nb);
            for (i = 0; i < nb; i++)
               putchar (p[i]);
               
            putchar ('\'');
            putchar ('\n');
            XFree (p);
         }
#endif   /* DB */
         break;
      case 3:
         key = RMB;
         break;
      }
   }
   
   if (key == NOKEY) {
      *pk = NOKEY;
      return (NO);
   }
   else {
      *pk = key;
      return (YES);
   }
}


/* draw_cursor --- display the text cursor */

static void draw_cursor (draw)
bool draw;
{
   char tmp[2];
   int zone;
   GC gc;
   
   tmp[0] = Screen_image[Currow][Curcol].ch;
   tmp[1] = EOS;
   zone   = Screen_image[Currow][Curcol].zn;

   if (In_focus) {
      if (draw)
         gc = CursorGc;
      else
         gc = Zone_gc[zone];

      XDrawImageString (Dpy, Win, gc, Curcol * Fontw, (Currow * Fonth) + Fontd, tmp, 1);
   }
   else {
      gc = Zone_gc[zone];
      XDrawImageString (Dpy, Win, gc, Curcol * Fontw, (Currow * Fonth) + Fontd, tmp, 1);
      if (draw)
         XDrawRectangle (Dpy, Win, gc, Curcol * Fontw, Currow * Fonth, Fontw - 1, Fonth - 1);
   }
}
