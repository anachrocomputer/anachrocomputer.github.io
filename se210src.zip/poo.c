/* poo --- test 'se' on C */

#define JUNK (0) 
 
/* Test comments-in-preproc feature */
#define TAG /* in-line */ (42) /* suffix */

do_int_routine ()
{
   int do_it;
   int int_vec;
   long int int21vec;
   int do1loop;
   char *aint;
   char *aaint;
   char *bint;
   char *bbint;
   char *kint;
   char *lint;
   char *llint;
   char *lllint;
   char *mint;
   char *nint;
   char *nnint;
   char *nnnint;
   char *zint;
   char *zzint;
   char *zzzint;
   long int long_int;
   long int longint;
   
   do {
      do1loop = 42;
      if (long_int)
         mint = 42;

   } while (do_it);
}
