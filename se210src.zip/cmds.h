/* cmds.h --- command and option letters for 'se'           02/06/1989 */

/* Command letters */
#ifdef SWT
#define WINDCOM         '?'
#else
#define WINDCOM         '@'
#endif

#define APPENDCOM       'a'
/*                      'b' */
#define CHANGECOM       'c'
#define DELCOM          'd'
#define UCDELCOM        'D'   /* Upper case */
#define ENTERCOM        'e'
#define FILECOM         'f'
#define GLOBAL          'g'
#define UCGLOBAL        'G'   /* Upper case */
#define HELPCOM         'h'
#define INSERTCOM       'i'
#define JOINCOM         'j'
#define MARKCOM         'k'
#define LOCATECOM       'l'
#define MOVECOM         'm'
#define NAMECOM         'n'
#define OPTCOM          'o'
#define PRINT           'p'
#define QUITCOM         'q'
#define UCQUITCOM       'Q'   /* Upper case */
#define READCOM         'r'
#define SUBSTITUTE      's'
#ifdef SWT
#define COPYCOM         'y'
#else
#define COPYCOM         't'      /* This isn't the 'se' I remember... */
#endif
#define UNDOCOM         'u'
#define OVERLAYCOM      'v'
#define WRITECOM        'w'
#define EXCLUDE         'x'
#define UCEXCLUDE       'X'   /* Upper case */

#ifdef SWT
#define TLITCOM         't'
#else
#define TLITCOM         'y'
#endif

#define MISCCOM         'z'

#ifdef SWT
#define SHELLCOM        '~'
#define PIPECOM         '~'
#else
#define SHELLCOM        '!'
#define PIPECOM         '!'
#endif

#define PRINTCUR        '='
#define PAGECOM         ':'


/* Option letters */
#define CASEOPT         '^'         /* Changed! BJ */
#define WINDOWOPT       '-'
#define PATOPT          '/'         /* BJ */
#define NUMBEROPT       'a'
#define BINDOPT         'b'         /* BJ */
#define CMNTOPT         'c'         /* BJ */
#define DELDIROPT       'd'
/*                      'e' */
#define FILEOPT         'f'         /* Changed! BJ */
#define GLOBOPT         'g'
#define INSDELOPT       'h'
#define INDENTOPT       'i'
#define COLOUROPT       'j'         /* BJ */
#define SAVEDOPT        'k'
#define LINEOPT         'l'
#define MESGOPT         'm'
#define KEYWDOPT        'n'         /* BJ */
#define SWAPOPT         'o'         /* BJ */
#define PROMPTOPT       'p'         /* BJ */
#define QUIETOPT        'q'         /* BJ */
#define VIEWOPT         'r'         /* BJ */
#define SRCOPT          's'
#define TABSOPT         't'
#define UPRNTOPT        'u'
#define OVERLOPT        'v'
#define WARNOPT         'w'
#define XTABSOPT        'x'
#define PATMATCHOPT     'y'         /* BJ */
#define TSTPOPT         'z'
#define INSERTOPT       '_'         /* for Jules */
#define CRYPTOPT        '#'         /* Changed... BJ */


/* Global prefixes */
#define GMARK           '\''
#ifdef SWT
#define XMARK           '!'
#else                
#define XMARK           '~'
#endif

/* Miscellaneous commands */
#define BOXCOM          'b'
#define PRIVCOM         'p'
#define VERCOM          'v'
