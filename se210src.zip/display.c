/* display --- miscellaneous display functions              29/07/1987 */


#include "se.h"
#include "extern.h"

#define MAXPRMT         7        /* Length of prompt strings */

static uchar Cmdprmt[MAXPRMT] = "cmd>";
static uchar Apdprmt[MAXPRMT] = "apd>";
static uchar Waiprmt[MAXPRMT] = "    ";
static uchar Gonprmt[MAXPRMT] = "gone";


/* litnnum --- display literal and number in message area */

void litnnum (lit, num, type)
register const uchar *lit;
register int num, type;
{
   uchar msg[MAXCOLS];

   sprintf ((char *)msg, "%s%d", lit, num);
   mesg (msg, type);
}


/* setprompt --- set one of the 'se' prompts */

int setprompt (type, str)
int type;
register const uchar *str;
{
   uchar *p;
   
   switch (type) {
   case CMD_PRMT:
      p = Cmdprmt;
      break;
   case APD_PRMT:
      p = Apdprmt;
      break;
   case GON_PRMT:
      p = Gonprmt;
      break;
   case WAI_PRMT:
      p = Waiprmt;
      break;
   default:
      return (ERR);
   }
   
   struncpy (p, str, MAXPRMT - 1);
   p[MAXPRMT - 1] = EOS;
   zapnl (p);
   
   return (OK);
}


/* prompt --- load str into margin of command line */

void prompt (type, row)
int type;
register int row;
{
   register uchar *str;
   
   switch (type) {
   case CMD_PRMT:
      str = Cmdprmt;
      break;
   case APD_PRMT:
      str = Apdprmt;
      break;
   case GON_PRMT:
      str = Gonprmt;
      break;
   case WAI_PRMT:
      str = Waiprmt;
      break;
   case NUL_PRMT:
      str = (uchar *)"";
      break;
   }
   
   loadstr (str, row, 0, BARCOL - 1, PRMT_ZONE);
   position_cursor (row, BARCOL - 1);

   tflush ();     /* Make sure the screen is actually updated */
}


/* saynum --- display a number in the message area */

void saynum (n)
register int n;
{
   uchar s[10];

   sprintf ((char *)s, "%d", n);
   mesg (s, REMARK_MSG);
}


/* warn_deleted --- indicate which rows on screen are no longer valid */

void warn_deleted (from, to)
register int from, to;
{
   register int row;

   for (row = Toprow; row <= Botrow; row++)
      if (Topln + row - Toprow >= from
          && Topln + row - Toprow <= to)
         prompt (GON_PRMT, row);
}


/* watch --- keep time displayed on screen for users without watches */

void watch ()
{
   uchar face[10];
   struct TimeInfo ti;

   get_time (&ti);

   if (ti.Tfh)          /* 24 hour */
      sprintf ((char *)face, "%02d%c%02d",
              ti.Hour, ti.TimeSep, ti.Minute);
   else                 /* 12 hour */
      sprintf ((char *)face, "%d%c%02d%c",
               (ti.Hour > 12) ? ti.Hour - 12: ti.Hour,
               ti.TimeSep, ti.Minute,
               (ti.Hour > 11) ? 'p' : 'a');

   mesg (face, TIME_MSG);
}


/* scroll_window --- handle movement of cursor up or down */

void scroll_window (term)
int term;      /* Termination code from 'getcmd' */
{
   int scrows;
   
   scrows = Botrow - Toprow;     /* Height of screen */
   
   switch (term) {
   case TERM_UP:           /* Cursor Up */
      if (Curln > 1)
         Curln--;
      else
         Curln = Lastln;

      adjust_window (Curln, Curln);
      break;

   case TERM_SCUP:         /* Scroll Up */
      if (Curln > 1)
         Curln--;

      if (Topln > 1)
         adjust_window (Topln - 1, Topln + scrows - 1);

      break;
      
   case TERM_PGUP:         /* Page Up */
      if (Topln < scrows) {
         adjust_window (1, scrows);
         Curln = min (1, Lastln);
      }
      else {
         adjust_window (Topln - scrows, Topln);
         Curln = min (Topln + scrows, Lastln);
      }
      break;

   case TERM_TOP:
      Curln = min (1, Lastln);
      adjust_window (Curln, Curln);
      break;

   case TERM_DOWN:         /* Cursor Down */
      if (Curln < Lastln)
         Curln++;
      else
         Curln = min (1, Lastln);

      adjust_window (Curln, Curln);
      break;

   case TERM_SCDN:         /* Scroll Down */
      if (Curln < Lastln)
         Curln++;

      if ((Lastln - Topln) > scrows)
         adjust_window (Topln + 1, Topln + scrows + 1);

      break;

   case TERM_PGDN:         /* Page Down */
      if ((Lastln - Topln) > scrows) {
         adjust_window (Topln + scrows, Topln + (2 * scrows));
         Curln = min (Topln, Lastln);
      }
      else
         Curln = Lastln;

      break;
   
   case TERM_BOT:
      Curln = Lastln;
      adjust_window (Curln, Curln);
      break;
   }
}


/* hwinsdel --- return YES if the terminal has hardware insert/delete */

bool hwinsdel ()
{
   if (No_hardware == YES)
      return (NO);
   else
      return (Terminsdel);
}


/* set_viewflag --- set or clear 'read-only' mode */

void set_viewflag ()
{
   uchar *savfil;
   
   if ((savfil = get_filename ()) != NULL) {
      View = isreadonly (savfil);
      msgstr (View ? SVIEW : SNULL, VIEW_MSG);
   }
}
