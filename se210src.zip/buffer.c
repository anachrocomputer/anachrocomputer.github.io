#ifdef RCS_ID
static char RCSid[] = "$Header: buffer.c,v 2.09 89/12/19 17:00:00 BJ Exp $";
#endif

/*
 * $Log:   buffer.c,v $
 * Revision 2.09 89/12/19  17:00:00  BJ
 *
 * Revision 2.08 89/06/15  14:00:00  BJ
 * Initial split from 'scratch.c'
 *
 */

/*
 * buffer.c
 *
 * Buffer manipulation routines for 'se' screen editor
 *
 */

#include "se.h"
#include "extern.h"


/* bump --- advance line number and corresponding index simultaneously */

void bump (line, k, way)
register Lnum *line;
register LINEDESC **k;
int way;
{
   if (way == FORWARD) {   /* increment line number */
#ifdef OLD_SCRATCH
      *k = (*k)->Nextline;
      if (*k == Line0)
         *line = 0;
      else
         (*line)++;
#else
      (*k)++;
      if (*k == &Buf[Lastln+1]) {
         *line = 0;
         *k = Line0;
      }
      else
         (*line)++;
#endif
   }
   else {  /* decrement line number */
      if (*k == Line0)
         *line = Lastln;
      else
         (*line)--;
#ifdef OLD_SCRATCH
      *k = (*k)->Prevline;
#else
      if (*k == Line0)
         *k = &Buf[Lastln];
      else
         (*k)--;
#endif
   }
}


#ifdef OLD_SCRATCH

/* relink --- rewrite two half links */

void relink (a, x, y, b)
LINEDESC *a;
LINEDESC *x;
LINEDESC *y;
LINEDESC *b;
{
#ifdef DB
   if (x == NULL || y == NULL)
      error (YES, "relink: NULL line pointer (x,y)");

   if (a == NULL || b == NULL)
      error (YES, "relink: NULL line pointer (a,b)");
#endif   /* DB */

   x->Prevline = a;
   y->Nextline = b;

   Buffer_changed = YES;
}

#else

/* blkmove --- use SWT in Pascal line handling */

void blkmove (n1, n2, n3)    /* move block of lines n1..n2 to after n3 */
int n1, n2, n3;
{
/* NOTE: This code is disgustingly slow and contains quiche */
   if (n3 < n1 - 1) {
      reverse (n3 + 1, n1 - 1);
      reverse (n1, n2);
      reverse (n3 + 1, n2);
   }
   else if (n3 > n2) {
      reverse (n1, n2);
      reverse (n2 + 1, n3);
      reverse (n1, n3);
   }
   
   Buffer_changed = YES;
}


/* reverse --- reverse buf[n1]..buf[n2] */

void reverse (n1, n2)
register int n1, n2;
{
   LINEDESC temp;

   while (n1 < n2) {
      temp = Buf[n1];
      Buf[n1] = Buf[n2];
      Buf[n2] = temp;
      n1++;
      n2--;
   }

   Buffer_changed = YES;
}

#endif   /* OLD_SCRATCH */


/* getind --- locate line index in buffer */

LINEDESC *getind (line)
register Lnum line;
{
#ifdef OLD_SCRATCH
   register LINEDESC *k;

   k = Line0;
   line++;
   while (--line)
      k = k->Nextline;

   return (k);
#else
   return (&Buf[line]);     /* Fast... */
#endif   /* OLD_SCRATCH */
}


/* deleteln --- delete lines from through to */

int deleteln (from, to)
Lnum from, to;
{
/*
   BUG: should free memory when Use_scratch == NO
*/
#ifdef OLD_SCRATCH
   LINEDESC *k1, *k2, *j1, *j2, *l1;
#endif
   int status;
   Lnum nlines;

   if (from <= 0) {   /* can't delete line 0 */
      status = ERR;
      Errcode = EORANGE;
   }
   else {
      if (First_affected > from)
         First_affected = from;

#ifdef OLD_SCRATCH
      k1 = getind (prevln (from));
      j1 = k1->Nextline;
      j2 = getind (to);
      k2 = j2->Nextline;
      relink (k1, k2, k1, k2);   /* close chain around deletion */
#else
      blkmove (from, to, MAXBUF - 1); /* stick at end of buffer */
#endif   /* OLD_SCRATCH */

      nlines = (to - from) + 1;  /* Number of lines deleted */
      Lastln -= nlines;          /* Adjust number of last line */

#ifdef OLD_SCRATCH
      if (Limcnt != 0) {      /* Discard lines in limbo */
         l1 = Limbo->Prevline;
         Limbo->Prevline = Free;
         Free = l1;
      }
#endif   /* OLD_SCRATCH */

      Lost_lines += Limcnt;
      Limcnt = nlines;           /* Number of lines "deleted" */

#ifdef OLD_SCRATCH
      Limbo = j1;                /* Put what we just deleted in limbo */
      relink (j2, j1, j2, j1);   /* Close the ring */
#else
      Limbo = MAXBUF - nlines;   /* Point at first deleted */
#endif   /* OLD_SCRATCH */

      status = OK;
      svdel (from, nlines);
      Buffer_changed = YES;
   }

   return (status);
}


/* doundo --- restore last set of lines deleted */

int doundo (dflg)
bool dflg;
{
#ifdef OLD_SCRATCH
   LINEDESC *l1, *l2, *k1, *k2;
#endif
   int oldcnt;
   int status;

   status = ERR;

   if (!dflg && Line1 <= 0)
      Errcode = EORANGE;
   else if (Limcnt == 0)
      Errcode = ENOLIMBO;
   else if (Line1 > Line2)
      Errcode = EBACKWARD;
   else if (Line2 > Lastln)
      Errcode = EORANGE;
   else {
      status = OK;
      Curln = Line2;
#ifdef OLD_SCRATCH
      k1 = getind (Line2);
      k2 = getind (nextln (Line2));
      l1 = Limbo;
      l2 = l1->Prevline;
      relink (k1, l1, l2, k2);
      relink (l2, k2, k1, l1);
      Limbo = NULL;
#else
      blkmove (Limbo, MAXBUF - 1, Line2);
      Limbo = 0;
#endif   /* OLD_SCRATCH */
      svins (Line2, Limcnt);
      oldcnt = Limcnt;
      Limcnt = 0;
      Lastln += oldcnt;

      if (!dflg)
         status = deleteln (Line1, Line2);

      Curln = Line1 + oldcnt - 1;

      if (First_affected > Line1)
         First_affected = Line1;
   }

   return (status);
}
