/* emslib --- EMS library                                   30/06/1989 */
/* Copyright (c) 1989 BJ, Froods Software Development                  */

#include <stdio.h>
#include <string.h>  /* Prototypes for 'memcpy' etc. */
#include <dos.h>
#include "ems.h"

#define YES    1
#define NO     0

#define PAGSIZ       16384L
#define OHEAD        (sizeof (struct BlkEnd) * 2)
#define MINBLOCK     (long)(sizeof (struct BlkHdr) + sizeof (struct BlkEnd))

#define EMS_INT            0x67

#define EMS_GET_STATUS     0x40
#define EMS_GET_PFA        0x41
#define EMS_GET_PAGES      0x42
#define EMS_ALLOCATE       0x43
#define EMS_MAP            0x44
#define EMS_FREE           0x45
#define EMS_GET_VERSION    0x46
#define EMS_SAVE_MAP       0x47
#define EMS_RESTORE_MAP    0x48
#define EMS_GET_NHAND      0x4b
#define EMS_HANDLE_PAGES   0x4c
#define EMS_GET_ALL_PAGES  0x4d
#define EMS_REALLOC        0x51
#define EMS_ATTRIBUTE      0x52
#define EMS_GET_ATTR       0x00
#define EMS_SET_ATTR       0x01
#define EMS_GET_ATTR_CAP   0x02
#define EMS_NAME           0x53
#define EMS_GET_NAME       0x00
#define EMS_SET_NAME       0x01
#define EMS_PHYS_PAGES     0x58
#define EMS_GET_ADDR       0x00
#define EMS_GET_NUM        0x01

#define OFFSET(p)  (int)((p) & 0x03fffL)
#define PAGENO(p)  (int)(((p) >> 14) & 0x07ffL)

#define IN_USE    0xF0F0
#define AVAILABLE 0x00FF

#define UNMAP     0xffff

/* Header in a free block */
struct BlkHdr {
   unsigned int magic;
   unsigned long int size;
   emsptr next;
   emsptr prev;
};

/* End-of-block marker */
struct BlkEnd {
   unsigned long int size;
   unsigned int magic;
};

typedef int bool;

static emsptr tryalloc (unsigned int sz);
static void link_blk (emsptr p, unsigned long int sz);
static void unlink_blk (emsptr p);
static bool stash_blk (emsptr ep, bool used, unsigned long int sz, emsptr next, emsptr prev);
static bool map_page (unsigned int log, unsigned int phys);

static unsigned int Pfa = 0;
static unsigned int Totpag = 0;
static unsigned int Maxpag = 0;
static unsigned int Physpag = 0;
static int Handle = -1;
static int Pages = 0;
static int Ver = 0;
static emsptr Avail;
static emsptr TopBlk;
static int CurPag = -1;
#ifdef PROF
static int BlksInUse = 0;
static long int BytesInUse = 0L;
#endif   /* PROF */


/* emsinit --- initialise EMS subsystem */

int emsinit (limit)
long int limit;
{
   union REGS r;
   FILE *fp;
   int i;
   unsigned long int blksz;
   
   /* See if EMS is installed */
   if ((fp = fopen ("EMMXXXX0", "r")) == NULL)
      return (NO);
   
   fclose (fp);
   
   /* Get EMS status & test for errors */
   r.h.ah = EMS_GET_STATUS;
   int86 (EMS_INT, &r, &r);
   
   if (r.h.ah != 0)
      return (NO);

   /* Get EMS version & test against 3.2 */
   r.h.ah = EMS_GET_VERSION;
   int86 (EMS_INT, &r, &r);
            
   if (r.h.ah != 0)
      return (NO);

   Ver = (10 * (r.h.al >> 4)) + (r.h.al & 0x0f);

   if (Ver < 32)
      return (NO);
      
   /* Get Page Frame address & save it */
   r.h.ah = EMS_GET_PFA;
   int86 (EMS_INT, &r, &r);
            
   if (r.h.ah != 0)
      return (NO);

   Pfa = r.x.bx;

   /* Get number of physical pages & save it */
   r.h.ah = EMS_PHYS_PAGES;
   r.h.al = EMS_GET_NUM;
   int86 (EMS_INT, &r, &r);
            
   if (r.h.ah != 0)
      return (NO);

   Physpag = r.x.cx;
   
   /* Get total number of EMS pages & save it */
   r.h.ah = EMS_GET_PAGES;
   int86 (EMS_INT, &r, &r);
            
   if (r.h.ah != 0)
      return (NO);
   
   Totpag = r.x.dx;
   
   /* Allocate a handle & first page(s) */
   if (limit > 0)
      Maxpag = (int)(limit / PAGSIZ);
   else
      Maxpag = (int)(Totpag - (-limit / PAGSIZ));

   if (Ver >= 40) {
      Pages = 1;           /* Start with just one page */
   }
   else {
      Pages = Maxpag;      /* Grab all of it! */
   }
   
   r.h.ah = EMS_ALLOCATE;
   r.x.bx = Pages;
   int86 (EMS_INT, &r, &r);
            
   if (r.h.ah != 0)
      return (NO);
   
   Handle = r.x.dx;
   
   /* Add fake 'allocated' block at start of EMS */
   stash_blk (2L, YES, MINBLOCK, ENULL, ENULL);

   /* Add fake 'allocated' block at end of EMS */
   TopBlk = (PAGSIZ * Pages) - MINBLOCK;
   stash_blk (TopBlk, YES, MINBLOCK, ENULL, ENULL);
   
   /* Make whole of EMS into a free block */
   Avail = ENULL;
   blksz = (PAGSIZ * Pages) - (MINBLOCK * 2) - 2L;
   link_blk (MINBLOCK + 2L, blksz);
   
#ifdef notdef
   if (Ver >= 40) {                 /* This code should be legal, */
      for (i = 0; i < Physpag; i++) /* but crashes under Windows  */
         map_page (UNMAP, i);
   }
#endif   /* notdef */
   
   return (YES);
}


/* emsclose --- deallocate EMS handle on termination */

int emsclose ()
{
   union REGS r;
   
   if (Handle != -1) {
      r.h.ah = EMS_FREE;
      r.x.dx = Handle;
      int86 (EMS_INT, &r, &r);
      
      if (r.h.ah == 0) {
         Handle = -1;
         return (YES);
      }
   }
   
   return (NO);
}


/* emsalloc --- allocate a block of EMS */

emsptr emsalloc (sz)
unsigned int sz;
{
   emsptr p;
   union REGS r;
   
   sz += OHEAD;
   
   /* Block must be at least big enough to hold pointers when freed */
   if (sz < MINBLOCK)
      sz = (int)MINBLOCK;
   
   if ((p = tryalloc (sz)) == ENULL && Pages < Maxpag) {
#ifdef DB
      puts ("emsalloc: getting some more EMS");
#endif   /* DB */
      
      r.h.ah = EMS_REALLOC;
      r.x.bx = ++Pages;
      r.x.dx = Handle;
      int86 (EMS_INT, &r, &r);
      
      if (r.h.ah != 0)
         return (ENULL);
      
#ifdef DB
      printf ("Now allocated %d (%d) pages\n", r.x.bx, Pages);
#endif   /* DB */
      
      /* Add a fresh block of free space to the 'Avail' list */
      link_blk (TopBlk, PAGSIZ);

      /* Make a new fake block at the very top of memory */
      TopBlk += PAGSIZ;
      stash_blk (TopBlk, YES, MINBLOCK, ENULL, ENULL);

      p = tryalloc (sz);
   }
   
   return (p);
}


/* tryalloc --- try to allocate within current EMS space */

static emsptr tryalloc (sz)
unsigned int sz;
{
   emsptr p;
   unsigned int newsz;
   struct BlkHdr blk;
#ifdef PROF
   int i = 0;
#endif   /* PROF */
   
   /* Search the free chain for the first fit */
   for (p = Avail; p != ENULL; ) {
#ifdef PROF
      i++;
#endif   /* PROF */
      emsread (&blk, sizeof (blk), p);
      
      if (blk.size >= sz)
         break;
         
      p = blk.next;
   }
   
#ifdef PROF
   printf ("tryalloc: %3d loops\n", i);
#endif   /* PROF */
   
   if (p != ENULL) {
      /* New size for this block when 'sz' bytes allocated */
      newsz = (int)(blk.size - sz);

#ifdef DB
      printf ("tryalloc: newsz = %u\n", newsz);
#endif   /* DB */

      if (newsz <= MINBLOCK) {     /* Take the whole block... */
#ifdef DB
         printf ("tryalloc: taking whole block at %08lx\n", p);
#endif   /* DB */

         /* Increase 'sz' to take whole block */
         sz = (int)blk.size;

         unlink_blk (p);
      }
      else {                     /* Chop the block in two... */
#ifdef DB
         printf ("tryalloc: chopping block at %08lx\n", p);
#endif   /* DB */
         stash_blk (p, NO, (long)newsz, blk.next, blk.prev);

         p += newsz;
      }

      /* Mark block as allocated */
      stash_blk (p, YES, (long)sz, ENULL, ENULL);

      /* Make 'p' point to start of user's area of block */
      p += sizeof (struct BlkEnd);
   }
   else {
      p = ENULL;
#ifdef DB
      puts ("Out of memory!");
#endif   /* DB */
   }
      
#ifdef DB
   printf ("tryalloc: returning %08lx\n", p);
#endif   /* DB */

#ifdef PROF
   if (p != ENULL) {
      BlksInUse++;
      BytesInUse += sz;
   }
#endif   /* PROF */
   
   return (p);
}


/* emsfree --- deallocate ems block obtained from 'emsalloc' */

void emsfree (p)
emsptr p;
{
   struct BlkHdr blk;
   struct BlkHdr h;
   struct BlkHdr h1;    /* Header of next free block in chain     */
   struct BlkHdr h2;    /* Header of previous free block in chain */
   struct BlkEnd e;
   emsptr hp;           /* Address of header record */
/* emsptr ep;         *//* Address of end record */
   emsptr f;            /* Address of free block above/below */
   bool above, below;
   
   if (p == ENULL) {
#ifdef DB
      puts ("Trying to free ENULL");
#endif   /* DB */
      return;
   }
   
   above = below = NO;
   
   /* Read header of block to be freed */
   hp = p - sizeof (struct BlkEnd);
   emsread (&blk, sizeof (blk), hp);
   
   if (blk.magic == AVAILABLE) {
#ifdef DB
      puts ("Trying to free block that's already free");
#endif   /* DB */
      return;
   }
   else if (blk.magic != IN_USE) {
#ifdef DB
      puts ("Trying to free random address");
#endif   /* DB */
      return;
   }
   
/* ep = hp + blk.size - sizeof (struct BlkEnd); */
   
#ifdef DB
   printf ("Freeing :%08lx, length = %8ld\n", hp, blk.size);
#endif   /* DB */
   
   /* Look for a free block at lower end of this block */
   emsread (&e, sizeof (e), hp - sizeof (e));
   if (e.magic == AVAILABLE) {
#ifdef DB
      puts ("Free block below");
#endif   /* DB */
      below = YES;
   }
#ifdef DB
   else if (e.magic == IN_USE) {
      puts ("No free block below");
   }
   else
      puts ("Duff block below");
#endif   /* DB */

   /* Look for a free block at upper end of this block */
   emsread (&h, sizeof (h), hp + blk.size);
   if (h.magic == AVAILABLE) {
#ifdef DB
      puts ("Free block above");
#endif   /* DB */
      above = YES;
   }
#ifdef DB
   else if (h.magic == IN_USE) {
      puts ("No free block above");
   }
   else
      puts ("Duff block above");
#endif   /* DB */
      
   /* Decide what to do about it */
   if (above && below) {
#ifdef DB
      puts ("Merging three blocks...");
#endif   /* DB */
      f = hp + blk.size;
      emsread (&h, sizeof (h), f);  /* Read header of block above */
      
      /* First delete the block above from the free chain */
      unlink_blk (f);
      
      /* Now enlarge the block below */
      f = hp - e.size;
#ifdef DB
      printf ("%08lx %08lx %ld\n", f, hp, e.size);
#endif   /* DB */

      emsread (&h1, sizeof (h1), f);
#ifdef DB
      printf ("%ld %ld, %ld\n", h1.size, blk.size, h.size);
#endif   /* DB */

      h1.size += blk.size + h.size;
#ifdef DB
      printf ("%ld %ld, %ld\n", h1.size, blk.size, h.size);
#endif   /* DB */

      stash_blk (f, NO, h1.size, h1.next, h1.prev);
   }
   else if (above) {
#ifdef DB
      puts ("Expanding block above...");
      printf ("%ld %ld\n", h.size, blk.size);
#endif   /* DB */

      h.size += blk.size;
      e.size = h.size;
      
      stash_blk (hp, NO, h.size, h.next, h.prev);

      /* Avail might point at the block we moved */
      if (Avail == hp + blk.size)
         Avail = hp;

      /* Fix backward link of next block */
      if (h.next != ENULL) {
         emsread (&h1, sizeof (h1), h.next);
         h1.prev = hp;
         emswrite (&h1, sizeof (h1), h.next);
      }

      /* Fix forward link of previous block */
      if (h.prev != ENULL) {
         emsread (&h2, sizeof (h2), h.prev);
         h2.next = hp;
         emswrite (&h2, sizeof (h2), h.prev);
      }
   }
   else if (below) {
#ifdef DB
      puts ("Expanding block below...");
#endif   /* DB */
      f = hp - e.size;
      emsread (&h, sizeof (h), f);  /* Read free block's header */
      h.size += blk.size;              /* Increase block's size    */
      stash_blk (f, NO, h.size, h.next, h.prev);
   }
   else {
#ifdef DB
      puts ("Adding block to free chain...");
#endif   /* DB */
      link_blk (hp, blk.size);
   }
   
#ifdef PROF
   BlksInUse--;
   BytesInUse -= blk.size;
#endif   /* PROF */
}


/* link_blk --- add a block to the front of the 'Avail' chain */

static void link_blk (p, sz)
emsptr p;
unsigned long int sz;
{
   struct BlkHdr h;

   stash_blk (p, NO, sz, Avail, ENULL);

   if (Avail != ENULL) {
      emsread (&h, sizeof (h), Avail);
      h.prev = p;
      emswrite (&h, sizeof (h), Avail);
   }

   Avail = p;           /* Avail now points to this block */
}


/* unlink_blk --- remove a block from the free chain */

static void unlink_blk (p)
emsptr p;
{
   struct BlkHdr blk;
   struct BlkHdr h;
   
   emsread (&blk, sizeof (blk), p);
   
   /* Ensure 'Avail' does not point to this block! */
   if (Avail == p)
      Avail = blk.next;

   /* Fix backward link of next block */
   if (blk.next != ENULL) {
      emsread (&h, sizeof (h), blk.next);
      h.prev = blk.prev;
      emswrite (&h, sizeof (h), blk.next);
   }

   /* Fix forward link of previous block */
   if (blk.prev != ENULL) {
      emsread (&h, sizeof (h), blk.prev);
      h.next = blk.next;
      emswrite (&h, sizeof (h), blk.prev);
   }
}


/* stash_blk --- store a complete block in EMS */

static bool stash_blk (ep, used, sz, next, prev)
emsptr ep;
bool used;
unsigned long int sz;
emsptr next;
emsptr prev;
{
   struct BlkHdr h;
   struct BlkEnd e;
   
   h.magic = used ? IN_USE : AVAILABLE;
   h.size  = sz;
   h.next  = next;
   h.prev  = prev;
   
   e.magic = h.magic;
   e.size  = h.size;

   emswrite (&h, sizeof (h), ep);
   emswrite (&e, sizeof (e), ep + sz - sizeof (e));
   
   return (YES);
}


/* emsread --- read an object of 'sz' bytes from EMS */

int emsread (mem, sz, ems)
void *mem;
unsigned int sz;
emsptr ems;
{
   void *p;
   unsigned int page;
   unsigned int ofs;
      
   /* Split 'ems' into page and offset */
   page = PAGENO (ems);
   ofs  = OFFSET (ems);
   
   /* Map two pages, in case block overlaps page boundary */
   if (page != CurPag) {
      map_page (page,     0);
      map_page (page + 1, 1);
      CurPag = page;
   }
   
   /* Make a far pointer to the page frame */
#ifdef __TURBOC__
   p = MK_FP(Pfa, ofs);
#else
   FP_SEG(p) = Pfa;
   FP_OFF(p) = ofs;
#endif
   
   memcpy (mem, p, sz);
   
   return (YES);
}


/* emswrite --- write an object of 'sz' bytes into EMS */

int emswrite (mem, sz, ems)
const void *mem;
unsigned int sz;
emsptr ems;
{
   void *p;
   unsigned int page;
   unsigned int ofs;
      
   /* Split 'ems' into page and offset */
   page = PAGENO (ems);
   ofs  = OFFSET (ems);
   
   /* Map two pages, in case block overlaps page boundary */
   if (page != CurPag) {
      map_page (page,     0);
      map_page (page + 1, 1);
      CurPag = page;
   }
   
   /* Make a far pointer to the page frame */
#ifdef __TURBOC__
   p = MK_FP(Pfa, ofs);
#else
   FP_SEG(p) = Pfa;
   FP_OFF(p) = ofs;
#endif
   
   memcpy (p, mem, sz);
   
   return (YES);
}


/* map_page --- map a single EMS page into the page frame */

static bool map_page (log, phys)
unsigned int log;
unsigned int phys;
{
   union REGS r;
   
   r.h.ah = EMS_MAP;
   r.h.al = phys;
   r.x.bx = log;
   r.x.dx = Handle;
   
   int86 (EMS_INT, &r, &r);
   
   return (r.h.ah == 0);
}


#ifdef DB

/* DumpFreeChain --- display readable dump of EMS free chain */

void DumpFreeChain ()
{
   emsptr p;
   struct BlkHdr blk;
   struct BlkEnd end;
   
#ifdef PROF
   printf ("%8d blocks allocated\n", BlksInUse);
   printf ("%8ld bytes in use\n", BytesInUse);
#endif   /* PROF */   

   puts ("Address  Size     forward  backward");
   puts ("-------- -------- -------- --------");
   
   for (p = Avail; p != ENULL; ) {
      emsread (&blk, sizeof (blk), p);
      printf ("%08lx %8ld %08lx %08lx\n", p, blk.size, blk.next, blk.prev);

      if (blk.magic == IN_USE)
         puts ("Header: Block marked as allocated");
      else if (blk.magic != AVAILABLE)
         puts ("Header: Duff magic number");

      emsread (&end, sizeof (end), p + blk.size - sizeof (end));
      
      if (blk.size != end.size)
         puts ("Size mismatch");
         
      if (blk.magic == IN_USE)
         puts ("End: Block marked as allocated");
      else if (blk.magic != AVAILABLE)
         puts ("End: Duff magic number");

      p = blk.next;
   }
}

#endif   /* DB */
