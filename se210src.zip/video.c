/* video --- machine dependant video driver                 16/03/1989 */

#include "se.h"
#include "extern.h"


#ifdef HARD_TERMS

#include "hardterm.c"

#else

#if IBMPC & MSDOS
#include "ibmpc.c"
#endif

#if IBMPC & MSWIN32
#include "win32tty.c"
#endif

#if SIRIUS
#include "siterm.c"
#endif

#if VMS
#include "vaxtty.c"
#endif

#if ATARI & TOS
#include "atari.c"
#endif

#if UNIX | MINIX | LINUX
#if XWINDOWS
#include "xdisplay.c"
#else
#include "uxterm.c"
#endif /* XWINDOWS */
#endif /* UNIX | MINIX | LINUX */

#if ISERVER
#include "mdvd.c"
#endif

#endif   /* HARD_TERMS */
