/* ctrl.h--- definition of cursor editing functions        06/12/1991 */
/* Copyright (c) 1991 BJ, Froods Software Development                  */

/* Leftward cursor motion */
#define TT_LEFT               (-1)  /* left one column            */
#define TT_TAB_LEFT           (-2)  /* left one tab stop          */
#define TT_HOME               (-3)  /* go to column 1             */
#define TT_SCAN_LEFT          (-4)  /* scan left for a char       */
#define TT_DEL_LEFT           (-5)  /* erase char to left         */
#define TT_G_TAB_LEFT         (-6)  /* erase to prev tab stop     */
#define TT_KILL_LEFT          (-7)  /* erase to column 1          */
#define TT_G_SCAN_LEFT        (-8)  /* scan left and erase        */

/* Rightward cursor motion */
#define TT_RIGHT              (-9)  /* right one column           */
#define TT_TAB_RIGHT          (-10) /* right one tab stop         */
#define TT_END                (-11) /* go to end of line          */
#define TT_SCAN_RIGHT         (-12) /* scan right for char        */
#define TT_DEL_RIGHT          (-13) /* erase over cursor          */
#define TT_G_TAB_RIGHT        (-14) /* erase to next tab          */
#define TT_KILL_RIGHT         (-15) /* erase to end of line       */
#define TT_G_SCAN_RIGHT       (-16) /* scan right and erase       */

/* Line termination */
#define TT_T_SKIP_RIGHT       (-17) /* skip to end and terminate  */
#define TT_T_KILL_RIGHT       (-18) /* erase to end and terminate */
#define TT_FUNNY              (-19) /* take funny return          */

/* Upward motion */
#define TT_UP                 (-20) /* move up one line           */
#define TT_PAGE_UP            (-21) /* move up one page           */
#define TT_SCROLL_UP          (-22) /* Scroll window up           */
#define TT_TOP                (-23) /* Go to top of file          */

/* Downward motion */
#define TT_DOWN               (-24) /* move down one line         */
#define TT_PAGE_DOWN          (-25) /* move down one page         */
#define TT_SCROLL_DOWN        (-26) /* Scroll window down         */
#define TT_BOT                (-27) /* Go to bottom of file       */

/* Insertion */
#define TT_INSERT_BLANK       (-28) /* insert one blank           */
#define TT_INSERT_TAB         (-29) /* insert blanks to next tab  */
#define TT_INSERT_NEWLINE     (-30) /* insert a newline           */

/* Miscellany */
#define TT_TOGGLE_INSERT_MODE (-31) /* toggle insert mode flag    */
#define TT_SHIFT_CASE         (-32) /* toggle case mapping flag   */
#define TT_KILL_ALL           (-33) /* erase entire line          */
#define TT_FIX_SCREEN         (-34) /* clear and restore screen   */
#define TT_LITERAL            (-35) /* Enter literal char         */
#define TT_IDENTIFY           (-36) /* Identify bindable key      */
#define TT_NOP                (-37) /* No operation               */
#define TT_TRANSPOSE          (-38) /* Swap adjascent characters  */
#define TT_UNDO               (-39) /* Undo multi-character del.  */
#define TT_ASCII              (-40) /* Display ASCII code         */

/* Error codes */
#define TT_NOTBOUND           (-41) /* Unbound function key       */
#define TT_UNKNOWN            (-42) /* Unparseable ESC sequence   */

/* Date and time functions */
#define TT_DATE               (-43) /* Date function              */
#define TT_TIME               (-44) /* Time function              */
#define TT_FILENAME           (-45) /* File name function         */
#define TT_USERNAME           (-46) /* User name function         */
#define TT_HOSTNAME           (-47) /* Host machine name          */
#define TT_YEAR4              (-48) /* Year as four digits        */
#define TT_YEAR2              (-49) /* Year as two digits         */
#define TT_DAY2               (-50) /* Date as two digits         */
#define TT_MONTH2             (-51) /* Month as two digits        */
#define TT_MONTH              (-52) /* Month as word              */

/* Case conversion */
#define TT_UPPER              (-53) /* Map to upper case          */
#define TT_LOWER              (-54) /* Map to lower case          */

/* Line numbers */
#define TT_CURLN              (-55) /* Current line number        */
#define TT_TOPLN              (-56) /* Top-of-screen line number  */
#define TT_LASTLN             (-57) /* End-of-file line number    */

#define TT_FIRST_CHAR         (-58) /* Leftmost non-blank char    */
#define TT_LAST_CHAR          (-59) /* Rightmost non-blank char   */
