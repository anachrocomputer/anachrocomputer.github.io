/* bind --- read key tokens and bind them to functions      02/11/1990 */
/* Copyright (c) 1990 BJ, Froods Software Development                  */

#include "se.h"
#include "extern.h"

#include "ctrl.h"
#include "keys.h"

/* #define DB */

#define MAXBIND 256

static int *Bindtab[MAXBIND];

static struct {   /* Default binding table */
   int kcode;
   int token;
} defbind[] = {
   {C_A,       TT_TOGGLE_INSERT_MODE},
   {C_B,       TT_G_SCAN_RIGHT},
   {C_C,       TT_INSERT_BLANK},
   {C_D,       TT_UP},
   {C_E,       TT_TAB_LEFT},
   {C_F,       TT_FUNNY},
   {C_G,       TT_RIGHT},
   {C_H,       TT_LEFT},            /* a.k.a. backspace */
   {C_I,       TT_TAB_RIGHT},
   {C_J,       TT_SCAN_RIGHT},
   {C_K,       TT_DOWN},
   {C_L,       TT_SCAN_LEFT},
   {C_M,       TT_T_KILL_RIGHT},
   {C_N,       TT_G_SCAN_LEFT},
   {C_O,       TT_END},
   {C_P,       TT_IDENTIFY},
   {C_Q,       TT_PAGE_UP},        /* Remove this */
   {C_R,       TT_DEL_RIGHT},
   {C_S,       TT_PAGE_DOWN},      /* and this */
   {C_T,       TT_KILL_RIGHT},
   {C_U,       TT_DEL_LEFT},
   {C_V,       TT_T_SKIP_RIGHT},
   {C_W,       TT_HOME},
   {C_X,       TT_INSERT_TAB},
   {C_Y,       TT_KILL_LEFT},
   {C_Z,       TT_LITERAL},
/* {C_OBRA,    TT_LITERAL},            ESC   Leave this one unbound */
   {C_BSLA,    TT_G_TAB_LEFT},      /* FS */
   {C_CBRA,    TT_FIX_SCREEN},      /* GS */
   {C_UPAR,    TT_G_TAB_RIGHT},     /* RS */
   {C_UNDE,    TT_INSERT_NEWLINE},  /* US */
   {CDELETE,   TT_KILL_ALL},
   {ERASE,     TT_DEL_RIGHT},
   {CINSERT,   TT_TOGGLE_INSERT_MODE},
   {CUP,       TT_UP},
   {CDOWN,     TT_DOWN},
   {CLEFT,     TT_LEFT},
   {CRIGHT,    TT_RIGHT},
   {CHOME,     TT_HOME},
   {CEND,      TT_END},
   {PUP,       TT_PAGE_UP},
   {PDOWN,     TT_PAGE_DOWN},
   {NOKEY,     TT_UNKNOWN}
};
#define MAXDEFBIND (sizeof (defbind) / sizeof (defbind[0]))

struct tok {      /* Function name table */
   char *tokname;
   int token;
};

static struct tok nametab[] = {
   {"ascii",               TT_ASCII},
   {"bottom",              TT_BOT},
   {"curln",               TT_CURLN},
   {"date",                TT_DATE},
   {"day2",                TT_DAY2},
   {"del_left",            TT_DEL_LEFT},
   {"del_right",           TT_DEL_RIGHT},
   {"down",                TT_DOWN},
   {"end",                 TT_END},
   {"enter",               TT_T_KILL_RIGHT},
   {"filename",            TT_FILENAME},
   {"first_char",          TT_FIRST_CHAR},
   {"fix_screen",          TT_FIX_SCREEN},
   {"funny",               TT_FUNNY},
   {"g_scan_left",         TT_G_SCAN_LEFT},
   {"g_scan_right",        TT_G_SCAN_RIGHT},
   {"g_tab_left",          TT_G_TAB_LEFT},
   {"g_tab_right",         TT_G_TAB_RIGHT},
   {"identify",            TT_IDENTIFY},
   {"home",                TT_HOME},
   {"hostname",            TT_HOSTNAME},
   {"insert_blank",        TT_INSERT_BLANK},
   {"insert_newline",      TT_INSERT_NEWLINE},
   {"insert_tab",          TT_INSERT_TAB},
   {"kill_all",            TT_KILL_ALL},
   {"kill_left",           TT_KILL_LEFT},
   {"kill_right",          TT_KILL_RIGHT},
   {"lastln",              TT_LASTLN},
   {"last_char",           TT_LAST_CHAR},
   {"left",                TT_LEFT},
   {"literal",             TT_LITERAL},
   {"lower",               TT_LOWER},
   {"month",               TT_MONTH},
   {"month2",              TT_MONTH2},
   {"nop",                 TT_NOP},
   {"page_down",           TT_PAGE_DOWN},
   {"page_up",             TT_PAGE_UP},
   {"right",               TT_RIGHT},
   {"scan_left",           TT_SCAN_LEFT},
   {"scan_right",          TT_SCAN_RIGHT},
   {"scroll_down",         TT_SCROLL_DOWN},
   {"scroll_up",           TT_SCROLL_UP},
   {"shift_case",          TT_SHIFT_CASE},
   {"t_kill_right",        TT_T_KILL_RIGHT},
   {"t_skip_right",        TT_T_SKIP_RIGHT},
   {"tab_left",            TT_TAB_LEFT},
   {"tab_right",           TT_TAB_RIGHT},
   {"time",                TT_TIME},
   {"toggle_insert_mode",  TT_TOGGLE_INSERT_MODE},
   {"top",                 TT_TOP},
   {"topln",               TT_TOPLN},
   {"transpose",           TT_TRANSPOSE},
   {"undo",                TT_UNDO},
   {"up",                  TT_UP},
   {"upper",               TT_UPPER},
   {"username",            TT_USERNAME},
   {"year2",               TT_YEAR2},
   {"year4",               TT_YEAR4}
};
#define MAXFNNAMES (sizeof (nametab) / sizeof (nametab[0]))

static struct keyname {    /* Key name table */
   char *kname;
   int kcode;
} keytab[] = {
   {"DELETE",  CDELETE},
   {"UP",      CUP},
   {"DOWN",    CDOWN},
   {"LEFT",    CLEFT},
   {"RIGHT",   CRIGHT},
   {"HOME",    CHOME},
   {"END",     CEND},
   {"PUP",     PUP},
   {"PDOWN",   PDOWN},
   {"INSERT",  CINSERT},
   {"ERASE",   ERASE},
   {"C-UP",    C_CUP},        /* Control... */
   {"C-DOWN",  C_CDOWN},
   {"C-LEFT",  C_CLEFT},
   {"C-RIGHT", C_CRIGHT},
   {"C-HOME",  C_CHOME},
   {"C-END",   C_CEND},
   {"C-PUP",   C_PUP},
   {"C-PDOWN", C_PDOWN},
   {"C-INSERT",C_CINSERT},
   {"C-ERASE", C_ERASE},
   {"A-UP",    A_CUP},        /* Alt... */
   {"A-DOWN",  A_CDOWN},
   {"A-LEFT",  A_CLEFT},
   {"A-RIGHT", A_CRIGHT},
   {"A-HOME",  A_CHOME},
   {"A-END",   A_CEND},
   {"A-PUP",   A_PUP},
   {"A-PDOWN", A_PDOWN},
   {"A-INSERT",A_CINSERT},
   {"A-ERASE", A_ERASE},
   {"A-=",     A_EQ},         /* Oddities... */
   {"A--",     A_DASH},
   {"HELP",    CHELP},
   {"UNDO",    CUNDO},
   {"F1",      F1},           /* Function keys... */
   {"F2",      F2},
   {"F3",      F3},
   {"F4",      F4},
   {"F5",      F5},
   {"F6",      F6},
   {"F7",      F7},
   {"F8",      F8},
   {"F9",      F9},
   {"F10",     F10},
   {"F11",     F11},
   {"F12",     F12},
   {"F13",     F13},
   {"F14",     F14},
   {"F15",     F15},
   {"F16",     F16},
   {"F17",     F17},
   {"F18",     F18},
   {"F19",     F19},
   {"F20",     F20},
   {"S-F1",    S_F1},
   {"S-F2",    S_F2},
   {"S-F3",    S_F3},
   {"S-F4",    S_F4},
   {"S-F5",    S_F5},
   {"S-F6",    S_F6},
   {"S-F7",    S_F7},
   {"S-F8",    S_F8},
   {"S-F9",    S_F9},
   {"S-F10",   S_F10},
   {"S-F11",   S_F11},
   {"S-F12",   S_F12},
   {"S-F13",   S_F13},
   {"S-F14",   S_F14},
   {"S-F15",   S_F15},
   {"S-F16",   S_F16},
   {"S-F17",   S_F17},
   {"S-F18",   S_F18},
   {"S-F19",   S_F19},
   {"S-F20",   S_F20},
   {"A-F1",    A_F1},
   {"A-F2",    A_F2},
   {"A-F3",    A_F3},
   {"A-F4",    A_F4},
   {"A-F5",    A_F5},
   {"A-F6",    A_F6},
   {"A-F7",    A_F7},
   {"A-F8",    A_F8},
   {"A-F9",    A_F9},
   {"A-F10",   A_F10},
   {"A-F11",   A_F11},
   {"A-F12",   A_F12},
   {"A-F13",   A_F13},
   {"A-F14",   A_F14},
   {"A-F15",   A_F15},
   {"A-F16",   A_F16},
   {"A-F17",   A_F17},
   {"A-F18",   A_F18},
   {"A-F19",   A_F19},
   {"A-F20",   A_F20},
   {"C-F1",    C_F1},
   {"C-F2",    C_F2},
   {"C-F3",    C_F3},
   {"C-F4",    C_F4},
   {"C-F5",    C_F5},
   {"C-F6",    C_F6},
   {"C-F7",    C_F7},
   {"C-F8",    C_F8},
   {"C-F9",    C_F9},
   {"C-F10",   C_F10},
   {"C-F11",   C_F11},
   {"C-F12",   C_F12},
   {"C-F13",   C_F13},
   {"C-F14",   C_F14},
   {"C-F15",   C_F15},
   {"C-F16",   C_F16},
   {"C-F17",   C_F17},
   {"C-F18",   C_F18},
   {"C-F19",   C_F19},
   {"C-F20",   C_F20},
   {"A-A",     A_A},
   {"A-B",     A_B},
   {"A-C",     A_C},
   {"A-D",     A_D},
   {"A-E",     A_E},
   {"A-F",     A_F},
   {"A-G",     A_G},
   {"A-H",     A_H},
   {"A-I",     A_I},
   {"A-J",     A_J},
   {"A-K",     A_K},
   {"A-L",     A_L},
   {"A-M",     A_M},
   {"A-N",     A_N},
   {"A-O",     A_O},
   {"A-P",     A_P},
   {"A-Q",     A_Q},
   {"A-R",     A_R},
   {"A-S",     A_S},
   {"A-T",     A_T},
   {"A-U",     A_U},
   {"A-V",     A_V},
   {"A-W",     A_W},
   {"A-X",     A_X},
   {"A-Y",     A_Y},
   {"A-Z",     A_Z},
   {"C-A",     C_A},
   {"C-B",     C_B},
   {"C-C",     C_C},
   {"C-D",     C_D},
   {"C-E",     C_E},
   {"C-F",     C_F},
   {"C-G",     C_G},
   {"C-H",     C_H},
   {"C-I",     C_I},
   {"C-J",     C_J},
   {"C-K",     C_K},
   {"C-L",     C_L},
   {"C-M",     C_M},
   {"C-N",     C_N},
   {"C-O",     C_O},
   {"C-P",     C_P},
   {"C-Q",     C_Q},
   {"C-R",     C_R},
   {"C-S",     C_S},
   {"C-T",     C_T},
   {"C-U",     C_U},
   {"C-V",     C_V},
   {"C-W",     C_W},
   {"C-X",     C_X},
   {"C-Y",     C_Y},
   {"C-Z",     C_Z},
   {"ESC",     C_OBRA},    /* Synonym for C-[ */
   {"C-[",     C_OBRA},
/* {"FS",      C_BSLA}, */
   {"C-\\",    C_BSLA},
/* {"GS",      C_CBRA}, */
   {"C-]",     C_CBRA},
/* {"RS",      C_UPAR}, */
   {"C-^",     C_UPAR},
/* {"US",      C_UNDE}, */
   {"C-_",     C_UNDE},
   {"A-0",     A_0},
   {"A-1",     A_1},
   {"A-2",     A_2},
   {"A-3",     A_3},
   {"A-4",     A_4},
   {"A-5",     A_5},
   {"A-6",     A_6},
   {"A-7",     A_7},
   {"A-8",     A_8},
   {"A-9",     A_9},
   {"LMB",     LMB},
   {"MMB",     MMB},
   {"RMB",     RMB},
   {"S-LMB",   S_LMB},
   {"S-MMB",   S_MMB},
   {"S-RMB",   S_RMB},
   {"C-LMB",   C_LMB},
   {"C-MMB",   C_MMB},
   {"C-RMB",   C_RMB},
   {"A-LMB",   A_LMB},
   {"A-MMB",   A_MMB},
   {"A-RMB",   A_RMB}
};
#define MAXKEYNAMES  (sizeof (keytab) / sizeof (keytab[0]))

#if NO_PROTOTYPES
static int addbind ();
#else
static int addbind (int, const int *);
#endif


/* bind_init --- initialise this module */

void bind_init ()
{
   int i;
   int toks[2];
   
   for (i = 0; i < MAXBIND; i++)
      Bindtab[i] = NULL;
      
   for (i = 0; i < MAXDEFBIND; i++) {
      toks[0] = defbind[i].token;
      toks[1] = 0;
      addbind (defbind[i].kcode, toks);
   }
}


/* gettok --- read a single 'se' function token */

int gettok (raw)
bool raw;
{
#ifdef DB
   int i;
#endif
   int tok;
   static int *bindptr;
   
   if (raw) {
      tok = readkey (YES);
   }
   else {
      if (bindptr != NULL) {
         tok = *(bindptr++);

         if (*bindptr == 0)
            bindptr = NULL;
      }
      else if (Peekc) {       /* Pop END off the input stream */
         tok = TT_END;
         Peekc = NO;
      }
      else {
         tok = readkey (NO);
         
#ifdef DB
         printf ("readkey returned %d\r\n", tok);
#endif
         
         if (tok < 0) {       /* It's a bindable key */
            if (Bindtab[-tok] != NULL) {
               bindptr = Bindtab[-tok];
               tok = *(bindptr++);

               if (*bindptr == 0)
                  bindptr = NULL;
            }
            else {
               tok = TT_NOTBOUND;
            }
         }
      }
   }
   
#ifdef DB
   for (i = 0; i < MAXFNNAMES; i++)
      if (tok == nametab[i].token) {
         mesg ((uchar *)nametab[i].tokname, CHAR_MSG);
         break;
      }
#endif

   return (tok);
}


/* identify_key --- display name of a bindable key */

void identify_key ()
{
   int ktok;
   int i;

   /* Prompt on status line */
   msgstr (SIDPRMPT, REMARK_MSG);

   /* Read a keystroke */
   ktok = readkey (NO);

   if (ktok == NOKEY) {
      msgstr (SKEYBAD, REMARK_MSG);
      return;
   }

   /* Look up name of the key */
   for (i = 0; ktok != keytab[i].kcode && i < MAXKEYNAMES; i++)
      ;

   if (i < MAXKEYNAMES) {
      mesg ((uchar *)keytab[i].kname, REMARK_MSG);
   }
   else {
      msgstr (SNOTBIND, REMARK_MSG);
   }
}


/* dobind --- parse and execute a key binding command */

int dobind (lin)
const uchar *lin;
{
   int i, j, k;
   int ktok;            /* Code for key we're binding           */
   int ftok;            /* Code for functions found on cmd line */
   uchar keyname[20];   /* Name of key as text                  */
   int ftoks[MAXLINE];  /* Token string that key is bound to    */
   int delim;           /* Quoted string delimiter              */
   
   i = 0;
   SKIPBL(lin, i);
   
   /* Check for initial '[' */
   if (lin[i++] != '[') {
      Errcode = EBADBIND;
      return (ERR);
   }
   
   j = 0;
   while (lin[i] != ']' && lin[i] != NEWLINE)
      keyname[j++] = lin[i++];
      
   keyname[j] = EOS;
   
   if (lin[i] == NEWLINE) {
      Errcode = EBADBIND;
      return (ERR);
   }
   
   i++;  /* Skip the ']' */
   
   /* Look up name of the key we're binding */
   for (j = 0, ktok = NOKEY; j < MAXKEYNAMES; j++)
      if (strucmpi (keyname, keytab[j].kname) == 0)
         ktok = keytab[j].kcode;
   
#ifdef DB
   printf ("keyname = '%s' ktok = %d\n", keyname, ktok);
#endif

   if (ktok == NOKEY) {
      Errcode = EBINDKEY;     /* Key not recognised */
      return (ERR);
   }
      
   SKIPBL(lin, i);

   if (lin[i] == NEWLINE) {   
      Errcode = EBADBIND;     /* Nothing to bind it to... */
      return (ERR);
   }
   
   j = 0;
   
   /* Loop along remainer of cmd line, parsing functions and strings */
   while (lin[i] != NEWLINE) {
      if (lin[i] == '"' || lin[i] == '\'') {
         delim = lin[i++];
         while (lin[i] != delim && lin[i] != NEWLINE)
            ftoks[j++] = lin[i++];
            
         if (lin[i] == NEWLINE) {
            Errcode = EBINDQU;      /* Mismatched quotes */
            return (ERR);
         }
            
         i++;
      }
      else {
         k = 0;
         while (lin[i] != ' ' && lin[i] != TAB && lin[i] != NEWLINE)
            keyname[k++] = lin[i++];
            
         keyname[k] = EOS;
         ftok = TT_UNKNOWN;
   
         for (k = 0; k < MAXFNNAMES; k++)
            if (strucmpi (keyname, nametab[k].tokname) == 0)
               ftok = nametab[k].token;
   
#ifdef DB
         printf ("keyname = '%s' ftok = %d\n", keyname, ftok);
#endif

         if (ftok == TT_UNKNOWN) {
            Errcode = EBINDFUN;     /* Unknown function */
            return (ERR);
         }

         ftoks[j++] = ftok;
      }        
      
      SKIPBL(lin, i);
   }
   
   ftoks[j] = 0;

   if (addbind (ktok, ftoks) == ERR) {
      Errcode = EBINDMEM;
      return (ERR);
   }
   
   return (OK);
}


/* addbind --- add a binding to the bind table */

static int addbind (key, toks)
int key;
const int *toks;
{
   int tlen;
   int *p;
   
   key = -key;
   
   /* Count the length of the token array */
   for (tlen = 0; toks[tlen] != 0; tlen++)
      ;
      
   tlen++;     /* Add one for terminating zero */
   
   if ((p = (int *)malloc (tlen * sizeof (int))) == NULL)
      return (ERR);
      
   memcpy (p, toks, tlen * sizeof (int));
   
   /* Free the old binding */
   if (Bindtab[key] != NULL)
      free ((char *)Bindtab[key]);
      
   /* Install the new binding */
   Bindtab[key] = p;

   return (OK);
}
