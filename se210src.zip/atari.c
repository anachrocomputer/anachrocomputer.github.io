/* atari --- machine-dependant routines for Atari ST        19/12/1987 */
/* Copyright (c) 1987 BJ, Froods Software Development                  */

#include <osbind.h>
#include <bios.h>
#include <xbios.h>

#include "keys.h"

/* Screen sizes */
#define LOW_NROWS      25
#define LOW_NCOLS      40
#define MED_NROWS      25
#define MED_NCOLS      80
#define HIGH_NROWS     25
#define HIGH_NCOLS     80

#define HUE(fg, bg)     (fg | (bg << 4))


typedef unsigned int scancode;


/* Export name of machine */
string Smachine = "Atari ST";

#if NO_PROTOTYPES
static void set_colour ();
static void sendch ();
static void capslite ();
static unsigned int getscan ();
#else
static void set_colour (int c);
static void sendch (int ch);
static void capslite (void);
static unsigned int getscan (void);
#endif

static unsigned int Screen_image[MAXROWS][MAXCOLS];
static int Currow;                     /* Vertical cursor coordinate   */
static int Curcol;                     /* Horizontal cursor coordinate */   
static unsigned int Blanks[MAXCOLS];   /* Blanks for filling in lines  */
static int Cur_size = CUR_NORMAL;      /* Cursor state                 */
static bool Cur_on = YES;
static int Curhue = -1;
static int Colours[20];    /* Colour settings */

static int Lowdefcols[20] = {
         0,
         HUE(15, 0),    /* Text                       */
         HUE(15, 0),    /* Bar                        */
         HUE(15, 0),    /* Command line               */
         HUE(15, 0),    /* Line one                   */
         HUE(15, 0),    /* Line $                     */
         HUE(5,  0),    /* Status line                */
         HUE(2,  0),    /* Messages on status line    */
         HUE(15, 0),    /* Line numbers               */
         HUE(15, 0),    /* Mark column                */
         HUE(15, 0),    /* Current line               */
         HUE(15, 0),    /* Help messages              */
         HUE(15, 0),    /* Dashes in 'split-screen'   */
         HUE(1,  0),    /* Prompts                    */
         HUE(13, 0),    /* Unprintable characters     */
         HUE(15, 0),    /* Shell calls                */
         HUE(9,  0),    /* Source-code comments       */
         HUE(7,  0),    /* Source-code reserved words */
         HUE(12, 0),    /* Source-code strings        */
         HUE(1,  0)     /* Source-code pre-proc cmds. */
};

static int Meddefcols[20] = {
         0,
         HUE(3, 0),     /* Text                       */
         HUE(3, 0),     /* Bar                        */
         HUE(3, 0),     /* Command line               */
         HUE(3, 0),     /* Line one                   */
         HUE(3, 0),     /* Line $                     */
         HUE(2, 0),     /* Status line                */
         HUE(2, 0),     /* Messages on status line    */
         HUE(3, 0),     /* Line numbers               */
         HUE(3, 0),     /* Mark column                */
         HUE(3, 0),     /* Current line               */
         HUE(3, 0),     /* Help messages              */
         HUE(3, 0),     /* Dashes in 'split-screen'   */
         HUE(1, 0),     /* Prompts                    */
         HUE(3, 0),     /* Unprintable characters     */
         HUE(3, 0),     /* Shell calls                */
         HUE(0, 3),     /* Source-code comments       */
         HUE(2, 0),     /* Source-code reserved words */
         HUE(3, 0),     /* Source-code strings        */
         HUE(1, 0)      /* Source-code pre-proc cmds. */
};

static int Hidefcols[20] = {
         0,
         HUE(1, 0),     /* Text                       */
         HUE(1, 0),     /* Bar                        */
         HUE(1, 0),     /* Command line               */
         HUE(1, 0),     /* Line one                   */
         HUE(1, 0),     /* Line $                     */
         HUE(1, 0),     /* Status line                */
         HUE(1, 0),     /* Messages on status line    */
         HUE(1, 0),     /* Line numbers               */
         HUE(1, 0),     /* Mark column                */
         HUE(1, 0),     /* Current line               */
         HUE(1, 0),     /* Help messages              */
         HUE(1, 0),     /* Dashes in 'split-screen'   */
         HUE(1, 0),     /* Prompts                    */
         HUE(1, 0),     /* Unprintable characters     */
         HUE(1, 0),     /* Shell calls                */
         HUE(0, 1),     /* Source-code comments       */
         HUE(1, 0),     /* Source-code reserved words */
         HUE(1, 0),     /* Source-code strings        */
         HUE(1, 0)      /* Source-code pre-proc cmds. */
};


/* mdvd_init --- initialise this module */

void mdvd_init ()
{
   register int row, col;
   
   /* Initialise array of blanks */
   for (col = 0; col < MAXCOLS; col++)
      Blanks[col] = (1 << 8) | ' ';
   
   /* Clear virtual screen array */
   for (row = 0; row < MAXROWS; row++)
      for (col = 0; col < MAXCOLS; col++)
         Screen_image[row][col] = (1 << 8) | ' ';
}


/* set_term --- initialise terminal parameters and actual capabilities */

int set_term (type, hwinsdel, r, c)
const uchar *type;
bool *hwinsdel;
int *r, *c;
{
   int rows, cols;
   
   /* Sort out video modes */
   switch (Getrez ()) {
   case GR_LOW:
      rows = LOW_NROWS;
      cols = LOW_NCOLS;
      memcpy (Colours, Lowdefcols, sizeof (Colours));
      break;
   case GR_MED:
      rows = MED_NROWS;
      cols = MED_NCOLS;
      memcpy (Colours, Meddefcols, sizeof (Colours));
      break;
   case GR_HIGH:
      rows = HIGH_NROWS;
      cols = HIGH_NCOLS;
      memcpy (Colours, Hidefcols, sizeof (Colours));
      break;
   }            

   *hwinsdel = YES;
   *r = rows;
   *c = cols;
   
   return (OK);
}


/* term_init --- send start-up sequence to terminal */

void term_init ()
{
   Cursconf (CC_SHOW, 0);
   Cursconf (CC_NBLNK, 0);
   Bconout (BC_CON, ESC);  /* Auto-wrap */
   Bconout (BC_CON, 'v');
   
   /* Force 'Curhue' to a legal state */
   set_colour (HUE(1, 0));
}                
                  

/* term_exit --- send close-down sequence to terminal */
                    
void term_exit ()
{                     
   Cursconf (CC_BLNK, 0);

   /* Restore default colours */
   switch (Getrez ()) {
   case GR_LOW:
      set_colour (HUE(15, 0));
      break;
   case GR_MED:
      set_colour (HUE(3, 0));
      break;
   case GR_HIGH:
      set_colour (HUE(1, 0));
      break;
   }
}


/* setcolr --- set the colour of a screen zone */

void setcolr (zone, fg, bg)
int zone;
int fg, bg;
{
   Colours[zone] = HUE(fg, bg);
}


/* shellcolr --- fix colour of screen for TOS shell */

void shellcolr ()
{
   set_colour (Colours[SHELL_ZONE]);
}


/* mvinch --- read a character back from the screen image */

int mvinch (r, c)
int r, c;
{
   return (Screen_image[r][c] & 0xff);
}


/* cprow --- copy from one row to another for append */

void cprow (from, to)
register int from, to;
{
   register int col;

   for (col = 0; col < Ncols; col++)
      load (Screen_image[from][col] & 0xff, to, col, TEXT_ZONE);
}


/* load --- load a character onto the screen at given coordinates */

void load (chr, row, col, zone)
register unsigned char chr;
register int row, col;
int zone;
{
   register unsigned int ch;

   if (chr < ' ')
      ch = (Colours[UPRT_ZONE] << 8) | Unprintable;
   else
      ch = (Colours[zone] << 8) | chr;

   if (row >= 0 && row < Nrows && col >= 0 && col < Ncols
       && Screen_image[row][col] != ch) {
      Screen_image[row][col] = ch;
      position_cursor (row, col);
      set_colour (ch >> 8);
      sendch (ch & 0xff);
   }
}


/* loadstr --- load a string into a field of the screen */

void loadstr (str, row, stcol, endcol, zone)
register unsigned char *str;
int row, stcol, endcol;
int zone;
{
   register unsigned int ch;
   register int p, c, limit;

   if (row >= 0 && row < Nrows && stcol >= 0) {
      for (p = 0, c = stcol; str[p] != EOS && c < Ncols; p++, c++) {

         if (str[p] < ' ')
            ch = (Colours[UPRT_ZONE] << 8) | (Unprintable & 0xff);
         else
            ch = (Colours[zone] << 8) | str[p];
         
         if (Screen_image[row][c] != ch) {
            Screen_image[row][c] = ch;
            position_cursor (row, c);
            set_colour (ch >> 8);
            sendch (ch & 0xff);
         }
      }

      ch = (Colours[zone] << 8) | ' ';
      set_colour (Colours[zone]);
      
      if (endcol >= Ncols - 1 && c < Ncols - 1)
         clear_to_eol (row, c, zone);
      else {
         limit = (endcol < Ncols - 1) ? endcol : Ncols - 1;
         for (; c <= limit; c++)
            if (Screen_image[row][c] != ch) {
               Screen_image[row][c] = ch;
               position_cursor (row, c);
               sendch (' ');
            }
      }
   }
}


/* restore_screen --- screen has been garbaged; fix it */

void restore_screen ()
{
   register int row, col;
   register unsigned int ch;

   clrscreen ();

   for (row = 0; row < Nrows && ! intrpt (); row++)
      for (col = 0; col < Ncols; col++) {
         ch = Screen_image[row][col];

         if (ch != (' ' | (1 << 8))) {
            position_cursor (row, col);
            set_colour (ch >> 8);
            sendch (ch & 0xff);
         }
      }

   msgstr (SNULL, REMARK_MSG);   /* get rid of 'type control-q....' */
}


/* ringbell --- generate loud beeping noises */

void ringbell (type)
int type;               /* Different noises for different errors */
{
   if (!Quiet)
      Bconout (BC_CON, '\007');
}


/* clear_to_eol --- clear from current cursor position to end of line */

void clear_to_eol (row, col, zone)
int row, col;
int zone;
{
   register int c;
   bool flag;
   register unsigned int space;

   flag = NO;

   space = (Colours[zone] << 8) | ' ';
   
   for (c = col; c < Ncols; c++)
      if (Screen_image[row][c] != space) {
         Screen_image[row][c] = space;
         flag = YES;
      }

   if (flag) {
      position_cursor (row, col);
      set_colour (Colours[zone]);

      Bconout (BC_CON, ESC);  /* Clear to end */
      Bconout (BC_CON, 'K');
   }
}


/* position_cursor --- move the cursor to (row, col) */

void position_cursor (row, col)
register int row, col;              /* Row and col to move to */
{
   register int dist;
   
   /* Are we already there ? */
   if (row == Currow && col == Curcol)
      return;
      
   dist = col - Curcol;
   
   if (dist < 0)
      dist = -dist;
      
   if (row == Currow && dist < 2) { /* 4 chars for absolute position */
      while (Curcol < col) {        /* vs. 2 chars for relative */
         Bconout (BC_CON, ESC);  /* Cursor right */
         Bconout (BC_CON, 'C');
         Curcol++;
      }
      
      while (Curcol > col) {
         Bconout (BC_CON, ESC);  /* Cursor left */
         Bconout (BC_CON, 'D');
         Curcol--;
      }
   }
   else {      /* Quicker to use absolute positioning */
      Bconout (BC_CON, ESC);
      Bconout (BC_CON, 'Y');
      Bconout (BC_CON, row + ' ');
      Bconout (BC_CON, col + ' ');
   }
   
   Currow = row;
   Curcol = col; 
}


/* show_cursor --- show or hide the text cursor */

void show_cursor (on)
bool on;
{
   Cur_on = on;
}


/* shape_cursor --- set cursor size or style */

void shape_cursor (size)
int size;
{
   Cur_size = size;
}


/* clrscreen --- clear the physical screen */

void clrscreen ()
{
   Bconout (BC_CON, ESC);
   Bconout (BC_CON, 'E');

   Currow = 0;
   Curcol = 0;
}


/* inslines --- insert 'n' lines on the screen at 'row' */

void inslines (row, n)
int row, n;
{
   register int i;

   position_cursor (row, 0);

   for (i = 0; i < n; i++) {
      Bconout (BC_CON, ESC);
      Bconout (BC_CON, 'L');
   }

   for (i = Nrows - 1; i - n >= Currow; i--)
      memcpy (Screen_image[i], Screen_image[i - n], Ncols * sizeof (unsigned));

   for (; i >= Currow; i--)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
}


/* dellines --- delete 'n' lines beginning at 'row' */

void dellines (row, n)
int row, n;
{
   register int i;

   position_cursor (row, 0);

   for (i = 0; i < n; i++) {
      Bconout (BC_CON, ESC);
      Bconout (BC_CON, 'M'); 
   }

   for (i = Currow; i + n < Nrows; i++)
      memcpy (Screen_image[i], Screen_image[i + n], Ncols * sizeof (unsigned));

   for (; i < Nrows; i++)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
}


/* term_name --- return the name of the terminal */

uchar *term_name ()
{
   return ("ST");
}


/* readkey --- read keystrokes and map for cursor keys */

int readkey (raw)
bool raw;
{
   static keycode ktab[] = {
/*00*/NOKEY,   NOKEY,   NOKEY,   C_2,     NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*08*/NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*10*/A_Q,     A_W,     A_E,     A_R,     A_T,     A_Y,     A_U,     A_I,
/*18*/A_O,     A_P,     NOKEY,   NOKEY,   NOKEY,   NOKEY,   A_A,     A_S,
/*20*/A_D,     A_F,     A_G,     A_H,     A_J,     A_K,     A_L,     NOKEY,
/*28*/NOKEY,   C_BQT,   NOKEY,   NOKEY,   A_Z,     A_X,     A_C,     A_V,
/*30*/A_B,     A_N,     A_M,     NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*38*/NOKEY,   C_SPACE, NOKEY,   F1,      F2,      F3,      F4,      F5,
/*40*/F6,      F7,      F8,      F9,      F10,     NOKEY,   NOKEY,   CHOME,
/*48*/CUP,     NOKEY,   NOKEY,   CLEFT,   NOKEY,   CRIGHT,  NOKEY,   NOKEY,
/*50*/CDOWN,   NOKEY,   CINSERT, NOKEY,   S_F1,    S_F2,    S_F3,    S_F4,
/*58*/S_F5,    S_F6,    S_F7,    S_F8,    S_F9,    S_F10,   NOKEY,   NOKEY,
/*60*/NOKEY,   CUNDO,   CHELP,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*68*/NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*70*/NOKEY,   NOKEY,   NOKEY,   C_CLEFT, C_CRIGHT,NOKEY,   NOKEY,   C_CHOME,
/*78*/A_1,     A_2,     A_3,     A_4,     A_5,     A_6,     A_7,     A_8,
/*80*/A_9,     A_0,     A_DASH,  A_EQ,    NOKEY,   NOKEY,   NOKEY,   NOKEY
   };
#if 0
   static struct {
      scancode scode;
      keycode kcode;
   } ktab[] = {
/*    {0x0100, A_ESC}, */
/*    {0x0200, A_1},*/
      {0x0300, C_2},
/*    {0x0400, A_3},*/
/*    {0x0500, A_4},*/
/*    {0x0600, A_5},*/
/*    {0x0700, A_6},*/
/*    {0x0800, A_7},*/
/*    {0x0900, A_8},*/
/*    {0x0a00, A_9},*/
/*    {0x0b00, A_0},*/
/*    {0x0c00, A_DASH},*/
/*    {0x0d00, A_EQ},*/
/*    {0x0e00, A_BS}, */
/*    {0x0f00, A_TAB}, */
      {0x1000, A_Q},
      {0x1100, A_W},
      {0x1200, A_E},
      {0x13F0, A_R},
      {0x1400, A_T},
      {0x1500, A_Y},
      {0x1600, A_U},
      {0x1700, A_I},
      {0x1800, A_O},
      {0x1900, A_P},
/*    {0x1a00, A_OSQB}, */
/*    {0x1b00, A_CSQB}, */
/*    {0x1c00, A_CR}, */
/*    {0x1d00, CTRL}, */
      {0x1e00, A_A},
      {0x1f00, A_S},
      {0x2000, A_D},
      {0x2100, A_F},
      {0x2200, A_G},
      {0x2300, A_H},
      {0x2400, A_J},
      {0x2500, A_K},
      {0x2600, A_L},
/*    {0x2700, A_SEMI}, */
/*    {0x2800, A_SQT}, */
      {0x2900, C_BQT},
/*    {0x2a00, SHIFT}, */
/*    {0x2b00, A_HASH}, */
      {0x2c00, A_Z},
      {0x2d00, A_X},
      {0x2e00, A_C},
      {0x2f00, A_V},
      {0x3000, A_B},
      {0x3100, A_N},
      {0x3200, A_M},
/*    {0x3300, A_COMMA}, */
/*    {0x3400, A_DOT}, */
/*    {0x3500, A_SLASH}, */
/*    {0x3600, SHIFT}, */
/*    {0x3700, -}, */
/*    {0x3800, ALT}, */
      {0x3900, C_SPACE},
/*    {0x3a00, CAPS}, */
      {0x3b00, F1},
      {0x3c00, F2},
      {0x3d00, F3},
      {0x3e00, F4},
      {0x3f00, F5},
      {0x4000, F6},
      {0x4100, F7},
      {0x4200, F8},
      {0x4300, F9},
      {0x4400, F10},
/*    {0x4500, -}, */
/*    {0x4600, -}, */
      {0x4700, CHOME},
      {0x4800, CUP},
/*    {0x4900, -}, */
/*    {0x4a00, A_DASH}, */
      {0x4b00, CLEFT},
/*    {0x4c00, -}, */
      {0x4d00, CRIGHT},
/*    {0x4e00, A_PLUS}, */
/*    {0x4f00, -}, */
      {0x5000, CDOWN},
/*    {0x5100, -}, */
      {0x5200, CINSERT},
      {0x5300, CDELETE},
      {0x5400, S_F1},
      {0x5500, S_F2},
      {0x5600, S_F3},
      {0x5700, S_F4},
      {0x5800, S_F5},
      {0x5900, S_F6},
      {0x5a00, S_F7},
      {0x5b00, S_F8},
      {0x5c00, S_F9},
      {0x5d00, S_F10},
/*    {0x5e00, -}, */
/*    {0x5f00, -}, */
/*    {0x6000, A_BSLASH}, */
      {0x6100, CUNDO},
      {0x6200, CHELP},
/*    {0x6300, A_ORB}, */
/*    {0x6400, A_CRB}, */
/*    {0x6500, A_SLASH}, */
/*    {0x6600, A_STAR}, */
/*    {0x6700, A_7}, */
/*    {0x6800, A_8}, */
/*    {0x6900, A_9}, */
/*    {0x6a00, A_4}, */
/*    {0x6b00, A_5}, */
/*    {0x6c00, A_6}, */
/*    {0x6d00, A_1}, */
/*    {0x6e00, A_2}, */
/*    {0x6f00, A_3}, */
/*    {0x7000, A_0}, */
/*    {0x7100, A_DOT}, */
/*    {0x7200, A_ENTER}, */
      {0x7300, C_CLEFT},
      {0x7400, C_CRIGHT},
/*    {0x7500, -}, */
/*    {0x7600, -}, */
      {0x7700, C_CHOME},
      {0x7800, A_1},
      {0x7900, A_2},
      {0x7a00, A_3},
      {0x7b00, A_4},
      {0x7c00, A_5},
      {0x7d00, A_6},
      {0x7e00, A_7},
      {0x7f00, A_8},
      {0x8000, A_9},
      {0x8100, A_0},
      {0x8200, A_DASH},
      {0x8300, A_EQ}
   };
#endif
   scancode scode;
   int ascii;
   
   /* Busy-wait for a keystroke so we can simulate a CAPS-LOCK light */
   for (;;) {
      capslite ();
      
      if (Bconstat (BC_CON))  /* Now see if there's a key pressed */
         break;
   }
   
   scode = getscan ();
   ascii = scode & 0xff;
   
   if (raw)
      return (ascii);
   else if (ascii != 0x00) {
      if (ascii < ' ')
         return (-ascii);
      else if (ascii == DEL)
         return (CDELETE);
      else
         return (ascii);
   }
   else {
      scode >>= 8;
      
      if (scode < (sizeof (ktab) / sizeof (ktab[0])))
         return (ktab[scode]);
      else
         return (NOKEY);   /* Unknown scan code */
   }

#if 0
   /* Sort out extended scan codes */
   switch (scancode) {
      case 0x5200:
         tok = 0x01;    /* ^A */
         break;
      case 0x4700:
         tok = 23;      /* ^W */
         break;
      case 0x4800:
         tok = 0x04;    /* ^D */
         break;
      case 0x4b00:
         tok = 0x08;    /* ^H */
         break;
      case 0x4d00:
         tok = 0x07;    /* ^G */
         break;
      case 0x4f00:
         tok = 0x0f;    /* ^O */
         break;
      case 0x5000:
         tok = 0x0b;    /* ^K */
         break;
      default:
         if ((scancode & 0x00ff) == 0x00)
            tok = 0x00;
         else
            tok = scancode & 0x00ff;
         break;
   }
   
   /* Fix control chars */
   if (tok < ' ')
      tok = -tok;
#endif
}


/* set_colour --- set text colour */

static void set_colour (c)
int c;
{
   if (c != Curhue) {
      Bconout (BC_CON, ESC);
      Bconout (BC_CON, 'b');
      Bconout (BC_CON, c & 0x0f);

      Bconout (BC_CON, ESC);
      Bconout (BC_CON, 'c');
      Bconout (BC_CON, (c & 0xf0) >> 4);

      Curhue = c;
   }
}


/* sendch --- put a printable character at current position */

static void sendch (ch)
int ch;
{
   if (Currow == Nrows - 1 && Curcol == Ncols - 1)
      return;

   Bconout (BC_CON, ch);
   
   Curcol++;
   if (Curcol >= Ncols) {
      Curcol = 0;
      Currow++;
   }
}


/* capslite --- display a 'caps lock' indicator */

static void capslite ()
{
   static bool lock = NO;
   int row, col;
   bool stat;
   
   stat = (Getshift (-1) & GS_CAPS) != 0;

   if (stat != lock) {
      row = Currow;     /* Remember where we are... */
      col = Curcol;
      
      msgstr (stat ? SCAPS : SNULL, CAPS_MSG);
      lock = stat;
      
      position_cursor (row, col);   /* ...go back there */
   }
}


/* getscan --- read a single keystroke */

static unsigned int getscan ()
{
   long val;
   unsigned int ch, scan;
   
   /* Use BIOS to read keyboard to disable ^C */
   val = Bconin (BC_CON);
   ch = val & 0x00ff;
   scan = (val >> 16) & 0x00ff;
   
   return (val | (scan << 8));
}
