/* docmd1 --- first command module */

#include "se.h"
#include "extern.h"

/*
 * Revision 2.08 89/03/16  00:00:00  BJ
 * Called 'getsefile' to get help file name
 *
 * Revision 2.05 88/05/17  00:00:00  BJ
 * Added version number to help file
 *
 */


/* dohelp --- display documentation about editor */

int dohelp (lin, i)
const uchar *lin;
int i;
{
#ifdef u3b2
   char buf[BUFSIZ]; /* 3B2 seems to have problems with stdio and malloc... */
#endif
   FILE *fp;
   uchar pat[MAXLINE];
   uchar str[MAXLINE];
   bool found;
   uchar helpfile[MAXPATH];
   extern uchar Sversion[];      /* Defined in 'MAIN.C' */

   if (Nlines != 0) {
      Errcode = EBADLNR;
      return (ERR);
   }
   
   if (!getsefile (HELP_FILE, helpfile)) {
      Errcode = ENOHELP;
      return (ERR);
   }

   SKIPBL (lin, i);
   if (lin[i] == NEWLINE)
      strucpy (pat, "elp\n");    /* Default help script */
   else
      strucpy (pat, &lin[i]);    /* Name from cmd line */

   /* Map to lower case */
   strmap (pat, 'l');
   
   if ((fp = fopen ((char *)helpfile, READ)) == NULL) {
      Errcode = ENOHELP;  /* Couldn't find file */
      return (ERR);
   }
   
#ifdef u3b2
   setbuf (fp, buf);
#endif

   /* Check help file version */
   if (fgets ((char *)str, MAXLINE, fp) == NULL ||
       struncmp (str, Sversion, strulen (Sversion)) != 0) {
      Errcode = ENOHELP;
      fclose (fp);
      return (ERR);
   }
   
   found = NO;
   while (fgets ((char *)str, MAXLINE, fp) != NULL) {
      if (strucmp (pat, str) == 0) {
         found = YES;
         break;
      }
   }
   
   if (found) {
      display_help (fp);   /* Display the help script */
      fclose (fp);
      return (OK);
   }
   else {
      Errcode = ENOHELP;      /* Found file OK but didn't  */
      fclose (fp);            /* find correct script in it */
      return (ERR);
   }
}


/* doprnt --- set Curln, locate window */

int doprnt (from, to)
int from, to;
{
   if (from <= 0) {
      Errcode = EORANGE;
      return (ERR);
   }

   adjust_window (from, to);
   Curln = to;

   return (OK);
}


/* dotlit --- transliterate characters */

int dotlit (sub, allbut)
const uchar *sub;
bool allbut;
{
   uchar new[MAXLINE];
   uchar txt[MAXLINE];
   bool collap;
   register int i, j;
   int x, line, lastsub;
   int ret;
   LINEDESC *k;

   ret = ERR;
   if (Line1 <= 0) {
      Errcode = EORANGE;
      return (ret);
   }

   if (First_affected > Line1)
      First_affected = Line1;

   lastsub = strulen (sub) - 1;

   if ((strulen (Tlpat) - 1) > lastsub || allbut)
      collap = YES;
   else
      collap = NO;

   k = getind (Line1);
   
   for (line = Line1; line <= Line2; line++, k = NEXTLINE (k)) {
      if (intrpt ())  /* check for interrupts */
         return (ERR);

      gtxt (k, txt);    /* Get text of line into txt */

      for (i = j = 0; txt[i] != EOS && txt[i] != NEWLINE; i++) {
         x = xindex (Tlpat, txt[i], allbut, lastsub);

         if (collap && x >= lastsub && lastsub >= 0) {    /* collapse */
            new[j++] = sub[lastsub];

            for (i++; txt[i] != EOS && txt[i] != NEWLINE; i++) {
               x = xindex (Tlpat, txt[i], allbut, lastsub);
               if (x < lastsub)
                  break;
            }
         }

         if (txt[i] == EOS || txt[i] == NEWLINE)
            break;

         if (x >= 0 && lastsub >= 0)     /* transliterate */
            new[j++] = sub[x];
         else if (x < 0)    /* copy */
            new[j++] = txt[i];
         /* else
            delete */
      }

      if (txt[i] == NEWLINE)     /* add a newline, if necessary */
         new[j++] = NEWLINE;

      new[j] = EOS;      /* add the EOS */

      if ((ret = changeln (k, new, line == Line2)) == ERR)
         break;

      ret = OK;
   }

   Curln = Line2;
   
   return (ret);
}


/* doshell --- escape to the nearest shell to run one or more commands */

int doshell (lin, i)
uchar lin[];
register int i;
{
/*
 * Emulate vi: if running just a shell, redraw the screen as
 * soon as the shell exits. If running a program, let the user
 * redraw the screen when he/she is ready.
 *
 * Also emulate USG Unix 5.0 ed: a ! as the first character is
 * replaced by the previous shell command; an unescaped % is replaced
 * by the saved file name. The expanded command is echoed.
 */
   int j, k;
   int ret;
   uchar *savfil;
   uchar new_command[MAXLINE];
   static uchar sav_com[MAXLINE] = "";
   bool expanded = NO;
   bool auto_redraw = NO;
   int old_nrows, old_ncols;
   int c;

   if (Nlines != 0) {
      Errcode = EBADLNR;
      return (ERR);
   } 
   
   /* Check for leading ! */
   if (lin[i] == HIST_CH) {
      if (sav_com[0] != EOS) {
         for (j = 0; sav_com[j] != EOS; i++, j++)
            lin[i] = sav_com[j];  /* Copy saved cmd to command line */
         
         lin[i++] = NEWLINE;
         lin[i] = EOS;

         Peekc = YES;
         Errcode = ESHELLCMD;    /* Let user edit old shell cmd */
      }
      else
         Errcode = ENOCMD;       /* No saved shell cmd */

      return (ERR);
   }

   auto_redraw = (lin[i] == NEWLINE) ? YES : NO;

   for (j = 0; lin[i] != EOS; i++) {
      if (lin[i] == ESCAPE) {
         if (lin[i + 1] != FNAME_CH) {
            new_command[j++] = ESCAPE;
            new_command[j++] = lin[++i];
         }
         else
            new_command[j++] = lin[++i];
      }
      else if (lin[i] == FNAME_CH && (savfil = get_filename ()) != NULL) {
         for (k = 0; savfil[k] != EOS; k++)
            new_command[j++] = savfil[k];

         expanded = YES;
      }
      else
         new_command[j++] = lin[i];
   }

   if (new_command[j - 1] == NEWLINE)
      j--;

   new_command[j] = EOS;

   if (new_command[0] != EOS)    /* If it's a non-null command, */
      strucpy (sav_com, new_command);                /* save it */

   /* Warn user if the buffer isn't saved */
   if (Buffer_changed)
      msgstr (SNOWRITE, REMARK_MSG);
      
   old_nrows = Nrows;
   old_ncols = Ncols;

   position_cursor (Nrows - 1, 0);  /* Bottom left corner */

   term_exit ();
   ttynormal ();

   puts ("\n");               /* Clear out a line */
   shellcolr ();              /* Set colours up */
   
   if (expanded)
      puts ((char *)new_command);
      
   fflush (stdout);

   ret = call_shell (new_command);
   
   /* a la vi: */
   if (! auto_redraw) {
      fputs ((char *)getstring (STYPERETURN), stderr);
      while ((c = getchar()) != NEWLINE && c != EOF)
         ;
   }

   ttyedit ();
   term_init ();
   
   if (Nrows != old_nrows || Ncols != old_ncols) {
      Botrow = Nrows - 3;     /* Screen size changed */
      Cmdrow = Botrow + 1;
      Sclen = -1;

      cprow (old_nrows - 1, Nrows - 1);

      First_affected = Topln;
      adjust_window (Curln, Curln);
      updscreen ();
   }

   restore_screen ();

   if (Insert_mode)     /* Reset cursor logic */
      shape_cursor (CUR_INSERT);
   else
      shape_cursor (CUR_NORMAL);

   set_viewflag ();  /* User may have changed file attributes or */
                     /* given himself super-user status          */

   return (ret);
}
