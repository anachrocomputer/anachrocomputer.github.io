/* os --- operating system interface module                 03/08/1987 */

#include "se.h"
#include "extern.h"

#include <signal.h>

/*
 * Note: if the value of 'LIBDIR' is unsuitable for your system,
 * it can be overridden from the makefile with '-DLIBDIR=...'
 */

#if MSDOS
#include <dos.h>
#include <process.h>
#include <errno.h>
#include <time.h>

#if TCC
#include <dir.h>     /* We need 'findfirst' */
#include <io.h>      /* and '_chmod' */
#define FA_NORMAL    0x00
#endif

#define INTERNATIONAL_CALL    0x38
#define COMMIT_FILE           0x68

struct Nation {      /* Returned by International Call */
   unsigned int dtform; /* Date/time format    */
   uchar csym[5];       /* Currency symbol     */
   uchar thou[2];       /* Thousands separator */
   uchar deci[2];       /* Decimal point char. */
   uchar dsep[2];       /* Date separator      */
   uchar tsep[2];       /* Time separator      */
   uchar cflags;        /* Currency flags      */
   uchar cplaces;       /* Currency decimals   */
   uchar tflag;         /* 24 hour flag        */
   uchar casemap[4];    /* Case mapping call   */
   uchar lsep[2];       /* List separator      */
};

/* Novell NetWare Server Information block */
/* Note: some of the fields in this struct are integer values stored
   in 68000 byte order.  They have been declared as two-byte arrays
   to avoid word-alignment and to remind the user to swap the bytes */
struct ServerInfo {
   int Len;
   uchar ServName[48];
   uchar NetWareVer;
   uchar NetWareSub;
   uchar MaxConns[2];   /* 68000 byte order */
   uchar UsedConns[2];  /* 68000 byte order */
   uchar MaxVols[2];    /* 68000 byte order */
   uchar Revision;
   uchar SFTLevel;
   uchar TTSLevel;
   uchar PeakConn[2];   /* 68000 byte order */
   uchar AccountVer;
   uchar VAPVer;
   uchar QueueVer;
   uchar PrintServVer;
   uchar VirtualVer;
   uchar SecurityVer;
   uchar BridgeVer;
   uchar Reserved[60];
};

string Sopsys = "MS-DOS";     /* Export name of OS */
static struct Nation Nat;     /* National date/time info */

#if NO_PROTOTYPES

static void setlocal ();
#if IBMPC
static int netware ();
#endif   /* IBMPC */
static bool getvlab ();

#else

static void setlocal (struct Nation *);
#if IBMPC
static int netware (const void *, void *);
#endif   /* IBMPC */
static bool getvlab (char *);

#endif   /* NO_PROTOTYPES */

#endif   /* MSDOS */

#if MSWIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

string Sopsys = "Win32";     /* Export name of OS */
#endif

#if TOS
#include <sys\types.h>
#include <sys\stat.h>
#include <osbind.h>     /* TOS function call bindings */

#define DEFAULT_PATH    "C:\\bin\\msh.prg"

#define VOL_LAB   0x08

string Sopsys = "TOS";     /* Export name of OS */

#if NO_PROTOTYPES
static bool getvlab ();
#else
static bool getvlab (char *);
#endif
#endif   /* TOS */


#if UNIX | MINIX | LINUX
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#if MINIX
_PROTOTYPE( FILE *popen, (const char *cmd, const char *mode));
_PROTOTYPE( void sync,   (void)                             );
#include <unistd.h>
#else
#include <sys/file.h>
#endif
#include <pwd.h>           /* For 'struct passwd' */

#if BSD4_2
#include <sys/time.h>
#else
#include <time.h>
#endif   /* BSD4_2 */

#ifndef LIBDIR
#define LIBDIR "/usr/local/lib"
#endif

/* Locate the directory that holds mailboxes */
#if BSD | MINIX | LINUX
#define MAILBOX_DIRECTORY  "/usr/spool/mail/"   /* BSD style */
#else
#define MAILBOX_DIRECTORY  "/usr/mail/"         /* System V style */
#endif

/* Make your mind up about which shell to use... */
#if BSD
#define DEFAULT_PATH    "/bin/csh"     /* C-Shell */
#define DEF_SHELL       "csh"
#else
#define DEFAULT_PATH    "/bin/sh"      /* Bourne Shell */              
#define DEF_SHELL       "sh"
#endif   /* BSD */

#if USG | S5R2 | LINUX
#include <sys/utsname.h>        /* stuff to find out who we are */
#endif

#ifndef L_cuserid
#define L_cuserid (32)     /* Just in case it's not defined */
#endif

#if MINIX
string Sopsys = "Minix";      /* Export name of OS */
#else
#if LINUX
string Sopsys = "Linux";      /* Export name of OS */
#else
string Sopsys = "UNIX";       /* Export name of OS */
#endif
#endif
#endif   /* UNIX | MINIX | LINUX */


#if VMS
#include <types.h>
#include <stat.h>
#include <time.h>
#include <descrip.h>
#include <clidef.h>
#include <lnmdef.h>
#include <ssdef.h>
#include <errno.h>

#ifndef LIBDIR
#define LIBDIR "SYS$LIBRARY"
#endif

#define FAILED(s)   (((s)&1)==0)   /* Check system call for failure */

struct ITMLST { 
   unsigned short    buffer_length; 
   unsigned short    item_code; 
   char              *buffer_address; 
   unsigned long     *return_length_address; 
}; 
 
struct SDES { 
   struct dsc$descriptor_s    descrip; 
   char                       name[MAXLINE]; 
}; 
 
static unsigned short spawn_chan; 
static unsigned int exit_status; 
#ifdef NO_PROTOTYPES
static int setdes ();
#else
static int setdes (struct SDES *sdes, char *str);
#endif

string Sopsys = "VMS";     /* Export name of OS */
#endif   /* VMS */


#if ISERVER
#include <iocntrl.h>
#include <time.h>
string Sopsys = "iserver";    /* Export name of OS */
#endif   /* ISERVER */

/* Fix a few bit-masks... */
#ifndef W_OK
#define W_OK     2
#endif

#ifndef R_OK
#define R_OK     4
#endif

#ifndef S_IWUSR
#define S_IWUSR  0200         /* Write permission bit for owner */
#endif

#ifndef S_IRUSR
#define S_IRUSR  0400         /* Read permission bit for owner */
#endif

#ifndef S_IWGRP
#define S_IWGRP  0020         /* Write permission bit for group */
#endif

#if MSDOS | TOS
static char shell[MAXLINE];
static char pstat = EOS;
static char tmp[MAXPATH] = "\\se_pipe.tmp";
static int sys_rc;
#endif

#if NO_PROTOTYPES
#ifdef LOG_USAGE
static void log_usage ();
#endif

#else    /* NO_PROTOTYPES */

#ifdef LOG_USAGE
static void log_usage (void);
#endif
#endif   /* NO_PROTOTYPES */


/* os_init --- initialise this module */

void os_init ()
{
#if MSDOS
   setlocal (&Nat);
   
   Dirsep = '\\';
   Filsep = '.';
#endif

#if MSWIN32
   Dirsep = '\\';
   Filsep = '.';
#endif

#if TOS
   Dirsep = '\\';
   Filsep = '.';
#endif

#if UNIX | MINIX | LINUX
   Dirsep = '/';
   Filsep = '.';
#endif

#if VMS
   Dirsep = '/';
   Filsep = '.';
#endif

#if ISERVER
   Dirsep = '/';
   Filsep = '.';
#endif

#ifdef LOG_USAGE
   log_usage ();     /* Log who used the program */
#endif
}


/* get_time --- return the time as a structure */

void get_time (t)
struct TimeInfo *t;
{
#if UNIX | MINIX | LINUX | ISERVER | VMS
   time_t clock;
   struct tm *now;

   time (&clock);
   now = localtime (&clock);

   t->Day = now->tm_mday;
   t->Month = now->tm_mon;
   t->Year = now->tm_year + 1900;
   t->Hour = now->tm_hour;
   t->Minute = now->tm_min;
   t->Second = now->tm_sec;
   t->WkDay = now->tm_wday;

   t->Tfh = YES;     /* Don't really know any of these... */
   t->DateFmt = DDMMYY;
   t->TimeSep = ':';
   t->DateSep = '/';
#endif   /* UNIX | MINIX | LINUX | ISERVER | VMS */

#if MSDOS
/* 
 * MS-DOS knows about 12 hour or 24 hour time according to
 * nationality.  The call '_dos_gettime' is a Microsoft library
 * function that gives us the hours & minutes; we must test
 * the 24 hour flag before building the time string
 */
#if MSC
   struct dostime_t tm;
   struct dosdate_t dt;
   
   _dos_gettime (&tm);
   _dos_getdate (&dt);
   
   t->Day = dt.day;
   t->Month = dt.month - 1;
   t->Year  = dt.year;
   
   t->Hour = tm.hour;
   t->Minute = tm.minute;
   t->Second = tm.second;
   
   t->WkDay = dt.dayofweek;

   t->Tfh = Nat.tflag ? YES : NO;
   t->DateFmt = DDMMYY;
   t->TimeSep = Nat.tsep[0];
   t->DateSep = Nat.dsep[0];
#endif   /* MSC */
#if TCC
   struct time tm;
   struct date dt;
   
   gettime (&tm);
   getdate (&dt);
   
   t->Day   = dt.da_day;
   t->Month = dt.da_mon - 1;
   t->Year  = dt.da_year;
   
   t->Hour   = tm.ti_hour;
   t->Minute = tm.ti_min;
   t->Second = tm.ti_sec;
   
   t->WkDay = 0;  /* XXX */

   t->Tfh = YES;  /* XXX */
   t->DateFmt = DDMMYY;
   t->TimeSep = ':'; /* XXX */
   t->DateSep = '/'; /* XXX */
#endif   /* TCC */
#endif   /* MSDOS */

#if MSWIN32
   SYSTEMTIME buf;

   GetLocalTime (&buf);

   t->Day = buf.wDay;
   t->Month = buf.wMonth - 1;
   t->Year = buf.wYear;
   t->Hour = buf.wHour;
   t->Minute = buf.wMinute;
   t->Second = buf.wSecond;
   t->WkDay = buf.wDayOfWeek;

   t->Tfh = YES;     /* Must find out how to get these... */
   t->DateFmt = DDMMYY;
   t->TimeSep = ':';
   t->DateSep = '/';
#endif

#if TOS
/* 
 * 'Tgettime' returns the current time in a packed format,
 * hence the bit-shifting code to unpack it.
 */
   unsigned int tm;
   unsigned int dt;
   
   tm = Tgettime ();
   dt = Tgetdate ();

   t->Day = dt & 0x1f;
   t->Month = (dt >> 5) & 0x0f;
   t->Year  = ((dt >> 9) & 0x7f) + 1980;
   
   t->Hour = (tm >> 11) & 0x1f;
   t->Minute = (tm >> 5) & 0x3f;
   t->Second = (tm & 0x1f) * 2;
   
   t->WkDay = 0;

   t->Tfh = YES;     /* Don't really know any of these... */
   t->DateFmt = DDMMYY;
   t->TimeSep = ':';
   t->DateSep = '/';
#endif   /* TOS */
}


/* isreadonly --- return YES if a file is read-only */

bool isreadonly (file)
const uchar *file;
{
#if MSDOS
/* 
 * MS-DOS has a simple 'read-only' bit that can be set to
 * prevent writing into a file.
 */
#if MSC
/* 
 * '_dos_getfileattr' is a Microsoft C
 * library call that returns file attribute bits.
 */
   unsigned int attrib;
   
   if (_dos_getfileattr ((char *)file, &attrib) != 0)
      return (NO);
      
   if (attrib & _A_RDONLY)
      return (YES);
   else
      return (NO);
#endif   /* MSC */
#if TCC
/* 
 * '_chmod' is a Borland Turbo C library
 * call that returns file attribute bits.
 */
   unsigned int attrib;
   
   attrib = _chmod ((char *)file, 0);
      
   if (attrib & FA_RDONLY)
      return (YES);
   else
      return (NO);
#endif   /* TCC */
#endif   /* MSDOS */

#if MSWIN32
   DWORD attrib;

   attrib = GetFileAttributes (file);

   if (attrib == 0xffffffff)
      return (NO);
   else
      return (attrib & FILE_ATTRIBUTE_READONLY);
#endif

#if TOS
/* 
 * TOS is just like MS-DOS, but the library call is 'Fattrib'
 */
   long int ret;
   
   ret = Fattrib (file, 0, 0);
   
   if (ret < 0L || (ret & 0x01L) == 0L)
      return (NO);
   else
      return (YES);
#endif   /* TOS */

#if UNIX | MINIX | LINUX
/* 
 * UNIX has proper file protection
 */
   struct stat buf;
   
   if ((getuid () == 0) || (geteuid () == 0))
      return (NO);   /* Root can write *anything* ! */
      
   /* Check permissions for real user & group IDs */
   if (access ((char *)file, W_OK) == 0)
      return (NO);
      
   /* Now we need the actual protection bits... */
   if (stat ((char *)file, &buf) != 0)
      return (NO);
      
   /* Does the effective UID or GID give us any extra rights? */
   if ((buf.st_mode & S_IWUSR) && (buf.st_uid == geteuid ()))
      return (NO);
   else if ((buf.st_mode & S_IWGRP) && (buf.st_gid == getegid ()))
      return (NO);
   else
      return (YES);
#endif   /* UNIX | MINIX | LINUX */

#if VMS
   /* This is a bit UNIX-like for a VAX */
   struct stat buf;
   
   if (stat (file, &buf) != 0)
      return (NO);
      
   if (buf.st_mode & S_IWUSR)
      return (NO);
   else
      return (YES);
#endif   /* VMS */

#if ISERVER
   file = file;
   return (NO);   /* Can't tell */
#endif
}


/* setreadonly --- set a file to read-only */

bool setreadonly (file, ro)
const uchar *file;
bool ro;
{
#if MSDOS
/* 
 * Simply set or clear the 'read-only' bit as required.
 */
#if MSC
/* 
 * Once again, '_dos_setfileattr' is a Microsoft library function.
 */
   unsigned int attrib;
   
   if (_dos_getfileattr (file, &attrib) != 0)
      return (NO);
      
   if (ro)
      attrib |= _A_RDONLY;
   else
      attrib &= ~(_A_RDONLY);

   if (_dos_setfileattr (file, attrib) == 0)
      return (YES);
   else
      return (NO);
#endif   /* MSC */
#if TCC
/* 
 * Once again, '_chmod' is a Borland library function.
 */
   unsigned int attrib;
   
   attrib = _chmod ((char *)file, 0);
      
   if (ro)
      attrib |= FA_RDONLY;
   else
      attrib &= ~(FA_RDONLY);

   _chmod ((char *)file, 1, attrib);

   return (YES);
#endif   /* TCC */
#endif   /* MSDOS */

#if MSWIN32
   if (SetFileAttributes (file, ro ? FILE_ATTRIBUTE_READONLY : FILE_ATTRIBUTE_NORMAL))
      return (YES);
   else
      return (NO);
#endif

#if TOS
/* 
 * More bit-twiddling. 'Fattrib' can both set and read attributes.
 */
   int attrib;
   
   if ((attrib = Fattrib (file, 0, 0)) < 0)
      return (NO);
      
   if (ro)
      attrib |= 0x01; 
   else
      attrib &= ~0x01;
      
   if (Fattrib (file, 1, attrib) < 0L)
      return (NO);
   else
      return (YES);
#endif   /* TOS */

#if UNIX | MINIX | LINUX | VMS
   if (chmod ((char *)file, ro ? S_IRUSR : (S_IRUSR | S_IWUSR)) != 0)
      return (NO);
   else
      return (YES);
#endif   /* UNIX | MINIX | LINUX | VMS */

#if ISERVER
   ro = ro;
   file = file;
   return (NO);   /* No can do */
#endif
}


/* sysname --- return the name of the host computer */

uchar *sysname ()
{
   static uchar unknown[] = "unknown";

#if V7 | ISERVER  /* Version 7 or 'iserver' */
   return (unknown);
#endif   /* V7 */

#if MSDOS | TOS      /* CP/M-like */
/* 
 * There's no proper machine name in TOS or MS-DOS, so we return
 * the volume label of the current disk.  If we're lucky,
 * it will be set to a sensible name.
 */
   static char buf[65] = "";

   if (getvlab (buf))      /* See if there's a volume label */
      return ((uchar *)buf);
   else
      return (unknown);
#endif   /* MSDOS | TOS */

#if MSWIN32
   static char buf[MAX_COMPUTERNAME_LENGTH + 1];
   DWORD nb;

   nb = MAX_COMPUTERNAME_LENGTH;

   if (GetComputerName (buf, &nb) == FALSE)
      return (unknown);
   else
      return (buf);
#endif

#if USG | S5R2 | LINUX     /* System V */
   static struct utsname whoarewe;

   uname (&whoarewe);
   return (whoarewe.nodename);
#endif   /* USG | S5R2 */

#if BSD4_2   /* Berkeley 4.2 */
   static uchar buf[MAXLINE] = "";
   int j;

   if (buf[0] != EOS)       /* Been called before ? */
      return (buf);

   j = sizeof (buf);
   if (gethostname (buf, &j) == 0)
      return (buf);
   else
      return (unknown);
#else
#if BSD   /* Berkeley 4.1 */
   static char buf[MAXLINE] = "";
   int i;
   int c;
   FILE *fp;
   char *cp;

   if (buf[0] != EOS)
      return (buf);

   if ((fp = fopen ("/usr/include/whoami.h", READ)) == NULL)
      return (unknown);
   else {
      /*
       * file should contain a single line:
       * #define sysname "......"
       */
      while ((c = getc (fp)) != '"' && c != EOF)
         ;

      if (c == EOF)
         cp = unknown;
      else {
         for (i = 0; (c = getc (fp)) != '"' && c != EOF; i++)
            buf[i] = c;
         buf[i] = EOS;
         if (c == EOF && i == 0)
            cp = unknown;
         else
            cp = buf;
      }

      fclose (fp);

      return (cp);
   }
#endif   /* BSD */
#endif   /* BSD4_2 */

#if VMS
   char *ep;
   
   if ((ep = getenv ("SYS$NODE")) != NULL)
      return (ep);
   else
      return (unknown);
#endif   /* VMS */

#if MINIX
   return (unknown);
#endif   /* MINIX */
}


/* usrname --- return the name of the user */

uchar *usrname ()
{
   static uchar *p = NULL;

#if UNIX | MINIX | LINUX
#if BSD
   char *getlogin ();

   if (p == NULL)
      p = (uchar *)getlogin ();
#else
   static char buf[L_cuserid];
   char *cuserid ();    /* This function may go away in POSIX */

   if (p == NULL)
      p = (uchar *)cuserid (buf);
#endif   /* BSD */

#else
#if MSWIN32
   static char buf[256];
   DWORD nb;

   nb = 256;

   if (GetUserName (buf, &nb) == FALSE)
      p = (uchar *)"unknown";
   else
      p = buf;
#else
   if (p == NULL) {
      if ((p = (uchar *)getenv ("USER")) == NULL)
         p = (uchar *)"unknown";
   }
#endif   /* MSWIN32 */
#endif   /* UNIX | MINIX | LINUX */

   return (p);
}


/* shell_open --- open a file to/from a pipe */

FILE *shell_open (cmd, mode)
const uchar *cmd;
const char *mode;
{
#if MSDOS | TOS
   FILE *fp;
   
   switch (mode[0]) {
   case 'r':
   case 'R':
      sprintf (shell, "%s >%s", cmd, tmp);
      sys_rc = system (shell); 
      pstat = 'r';
      fp = fopen (tmp, READ);
      break;
   case 'w':
   case 'W':
      sprintf (shell, "%s <%s", cmd, tmp);
      pstat = 'w';
      fp = fopen (tmp, WRITE);
      break;
   default:
      fp = NULL;
      break;
   }
   
   return (fp);
#endif   /* MSDOS | TOS */

#if MSWIN32
   return (NULL);
#endif

#if UNIX | MINIX | LINUX
   return (popen ((char *)cmd, mode));
#endif

#if VMS
   struct SDES    mbx_des; 
   struct SDES    cmd_des; 
   unsigned int   status; 
   int            flags = CLI$M_NOWAIT; 
   FILE           *fp; 
   char           buf[MAXLINE]; 
   char           efn = 1; 
    
   setdes (&mbx_des, tmpnam(NULL)); 
    
   /* Build a descriptor for the command */ 
   setdes (&cmd_des, cmd); 
    
   /* Create the mailbox */ 
   status = sys$crembx (0, &spawn_chan, 0, 0, 0, 0, &mbx_des, 0); 
   if (FAILED (status)) 
      return (NULL); 
       
   /* Ready the event flag */ 
   status = sys$clref ((long) efn); 
   if (FAILED (status)) { 
      sys$delmbx (spawn_chan); 
      return (NULL);
   } 
    
   /* Prepare our end of the mailbox */ 
   if (mode[0] == 'r') { 
      fp = fopen (mbx_des.descrip.dsc$a_pointer, "r"); 
       
      if (fp == NULL) { 
         sys$delmbx (spawn_chan); 
         return (NULL); 
      } 
 
      status = lib$spawn (&cmd_des, 0, &mbx_des, &flags, 0, 0, 
                                 &exit_status, &efn, 0, 0, 0, 0); 
   } 
   else { 
      fp = fopen (mbx_des.descrip.dsc$a_pointer, "w"); 
       
      if (fp == NULL) { 
         sys$delmbx (spawn_chan); 
         return (NULL);
      } 
 
      status = lib$spawn (&cmd_des, &mbx_des, 0, &flags, 0, 0, 
                                 &exit_status, &efn, 0, 0, 0, 0); 
   } 
 
   if (FAILED (status)) { 
      sys$delmbx (spawn_chan); 
      return (NULL); 
   } 
    
   return (fp); 
#endif   /* VMS */

#if ISERVER
   return (NULL);
#endif
}


/* shell_close --- close the pipe opened by 'shell_open' */

int shell_close (fp)
FILE *fp;
{
#if MSDOS | TOS
   switch (pstat) {
   case EOS:
      return (-1);
      break;
   case 'r':
      fclose (fp);
      unlink (tmp);
      break;
   case 'w':
      fclose (fp);
      sys_rc = system (shell);
      unlink (tmp);
      break;
   }

   pstat = EOS;
   return (sys_rc);
#endif   /* MSDOS | TOS */

#if MSWIN32
   return (-1);
#endif

#if UNIX | MINIX | LINUX
   return (pclose (fp));
#endif

#if VMS
   char           efn = 1; 
   unsigned int   status; 
    
   /* Wait for the completion event flag to be set */ 
   status = sys$waitfr ((long) efn); 
    
   sys$delmbx (spawn_chan); 
    
   fclose (fp); 
    
   return (0);
#endif   /* VMS */

#if ISERVER
   return (-1);
#endif
}


#if VMS
static int setdes (sdes, str)
struct SDES *sdes;
char *str;
{
   register struct dsc$descriptor   *dsc = &sdes->descrip;
   
   strcpy (sdes->name, str);
   
   /* Now fill in the descriptor */
   dsc->dsc$w_length  = strlen (sdes->name);
   dsc->dsc$b_dtype   = DSC$K_DTYPE_T;
   dsc->dsc$b_class   = DSC$K_CLASS_S;
   dsc->dsc$a_pointer = sdes->name;
   
   return (0);
}
#endif   /* VMS */


#if UNIX | MINIX | LINUX

/* gethomedir --- return name of user's home directory */

uchar *gethomedir (user)
const uchar *user;
{
   struct passwd *p;

   if (*user == EOS)
      p = getpwuid (getuid ());
   else
      p = getpwnam ((char *)user);
      
   if (p == NULL)
      return (NULL);
   else
      return ((uchar *)p->pw_dir);
}

#endif   /* UNIX | MINIX | LINUX */


#if MSDOS | TOS

/* getvlab --- read the volume label */

static bool getvlab (str)
register char *str;
{
#if MSDOS
#if MSC
   struct find_t buf;
#endif
#if TCC
   struct ffblk buf;
#endif
   char *ep;
#if IBMPC
   struct ServerInfo serv;
   struct Request {
      int Len;
      uchar SubF;
   } req;

   /* First get the Novell NetWare file server name */
   req.Len = 1;
   req.SubF = 0x11;
   
   serv.Len = sizeof (struct ServerInfo);
   serv.NetWareVer = 0xff;
   serv.NetWareSub = 0xff;
   
   netware (&req, &serv);

   if (serv.NetWareVer != 0xff && serv.NetWareSub != 0xff) {
      struncpy (str, serv.ServName, 48);
      strcat (str, "\\");
   }
   else              /* No NetWare, so no file server name */
      str[0] = EOS;
#else
   /* Don't bother with networks on the Sirius... */
   str[0] = EOS;
#endif   /* IBMPC */
      
   /* Now append the volume label */
#if MSC
   if (_dos_findfirst ("*.*", _A_VOLID, &buf) == 0) {
      if ((ep = strchr (buf.name, '.')) != NULL) {
         *ep = EOS;                /* Get rid of dot in middle of filename */
         strcat (str, buf.name);
         strcat (str, ++ep);
      }
      else                         /* Too short to have a dot */
         strcat (str, buf.name);
   }
#endif   /* MSC */
#if TCC
   if (findfirst ("*.*", &buf, FA_LABEL) == 0) {
      if ((ep = strchr (buf.ff_name, '.')) != NULL) {
         *ep = EOS;                /* Get rid of dot in middle of filename */
         strcat (str, buf.ff_name);
         strcat (str, ++ep);
      }
      else                         /* Too short to have a dot */
         strcat (str, buf.ff_name);
   }
#endif   /* TCC */
   
   return (*str != EOS);
#endif   /* MSDOS */

#if TOS
   DMABUFFER buf;
   char *olddta;

   olddta = (char *)Fgetdta();
   Fsetdta (&buf);

   if (Fsfirst ("\\*.*", VOL_LAB) < 0)
      *str = EOS;
   else
      strcpy (str, buf.d_fname);

   Fsetdta (olddta);

   return (*str != EOS);
#endif   /* TOS */
}

#endif   /* MSDOS | TOS */


#if MSDOS

/* setlocal --- set local date/time format */

static void setlocal (p)
struct Nation *p;
{
   union REGS r;
   struct SREGS s;
   
   if (_osmajor >= 3) {    /* Ask the OS */
      segread (&s);
      r.h.ah = INTERNATIONAL_CALL;
      r.h.al = 0;
      r.x.dx = FP_OFF (p);
      s.ds   = FP_SEG (p);
      intdosx (&r, &r, &s);
   }
   else {                  /* Set up some defaults */
      p->tsep[0] = ':';       /* Use ':' for time separator */
      p->tsep[1] = EOS;
      p->tflag   = YES;       /* Use 24 hour time           */
   }
}


#if IBMPC

/* netware --- call Novell NetWare via INT 21 */

static int netware (req, buf)
const void *req;
void *buf;
{
   union REGS r;
   struct SREGS s;
   
   segread (&s);
   
   r.h.ah = 0xe3;          /* Call NetWare via INT 21H, function E3H */

   s.ds   = FP_SEG(req);   /* DS:SI -> request packet */
   r.x.si = FP_OFF(req);

   s.es   = FP_SEG(buf);   /* ES:DI -> reply packet */
   r.x.di = FP_OFF(buf);

   intdosx (&r, &r, &s);

   return (0);
}

#endif   /* IBMPC */

#endif   /* MSDOS */


/* call_shell --- invoke command interpreter with optional command line */

int call_shell (cmdlin)
const uchar *cmdlin;
{
   int forkstatus;   /* Status of invokation of the shell      */
   int childstatus;  /* Status of command run from shell, nonzero == ERR */
#if VMS
   int status;
   int flags = 0;
   int sub_proc_id;
   int i;
   char line[128], *lp;
   $DESCRIPTOR(cmd, line);          /* How about some comments on */
   $DESCRIPTOR(prompt, "Se [1] ");  /* this $DESCRIPTOR stuff, Bob ? */
   
   lp = cmdlin;
   for (i = 0; *lp != NEWLINE && *lp != EOS; i++)
      line[i] = *lp++;
      
   cmd.dsc$w_length = i;
   
   if (i == 0)             /* No command */
      puts ("\nType EOJ or LOgout to return to Se");
 
   status = lib$spawn (&cmd, 0, 0, &flags, 0, &sub_proc_id, 
                       0, 0, 0, 0, &prompt, 0);
   
   /* ...and is this the status of the shell or the command itself ? */
   if (!(status & 1))
      return (ERR);

#endif   /* VMS */

#if UNIX | MINIX | LINUX
   int i;
   void (*save_quit)(), (*save_int)();
   char *path, *name, *p;
   uchar buf[MAXLINE];

   /* UNIX -- fork off a new process */
   
   if ((p = getenv ("SHELL")) == NULL || strcmp (p, DEFAULT_PATH) == 0) {
      path = DEFAULT_PATH;
      name = DEF_SHELL;       /* default */
   }
#if BSD
   /* on Berkeley systems, check the other shell */
   else if (strcmp (p, "/bin/sh") == 0) {
      path = "/bin/sh";
      name = "sh";
   }
#endif
   else {
      if (p[0] == Dirsep) {      /* full pathname there */
         path = p;             /* work backwards to find just name */
         i = strlen (p);
         while (p[i] != Dirsep)
            i--;

         i++;       /* skip '/' */
         name = &p[i];
      }
      else {
         sprintf ((char *)buf, "unknown shell, using %s", DEF_SHELL);
         mesg (buf, REMARK_MSG);
         path = DEFAULT_PATH;
         name = DEF_SHELL;
      }
   }

   forkstatus = fork ();

   if (forkstatus == -1) {    /* the fork failed */
      Errcode = ECANTFORK;
      return (ERR);
   }

   if (forkstatus == 0) {     /* we're in the child process */
      signal (SIGINT, SIG_DFL);
      signal (SIGQUIT, SIG_DFL);

#if BSD
      if (strcmp (name, "sh") != 0)   /* not /bin/sh */
         signal (SIGTSTP, SIG_DFL);
      else
         signal (SIGTSTP, SIG_IGN);
#endif

      if (*cmdlin == EOS) {      /* No params; run a shell */
         execl (path, name, 0);
#if MINIX
         exit (EXIT_FAILURE);         /* exec failed, notify parent */
#else
         _exit (EXIT_FAILURE);         /* exec failed, notify parent */
#endif
      }
      else {
         execl (path, name, "-c", cmdlin, 0);
#if MINIX
         exit (EXIT_FAILURE);         /* exec failed, notify parent */
#else
         _exit (EXIT_FAILURE);         /* exec failed, notify parent */
#endif
      }
   }

   /* we're in the parent process here */
   save_int = signal (SIGINT, SIG_IGN);   /* ignore interrupts */
   save_quit = signal (SIGQUIT, SIG_IGN);

   while (wait (&childstatus) != forkstatus)
      ;

   save_int = signal (SIGINT, save_int);       /* catch interupts */
   save_quit = signal (SIGQUIT, save_quit);

   if ((childstatus >> 8) != 0) {
      Errcode = ENOSHELL;
      return (ERR);
   }
   
#endif   /* UNIX | MINIX | LINUX */
   
#if MSDOS
   char *op;             /* Old DOS prompt                */   
   char *np;             /* New prompt MUST be malloc()ed */
   char *p;

   if (*cmdlin == EOS) {
      np = malloc (80); /* Dynamic space for new prompt */
      op = malloc (80);
      
      if (op != NULL && np != NULL) {
         strcpy (np, "PROMPT=");
         strcpy (op, "PROMPT=");

         if ((p = getenv ("PROMPT")) == NULL) {
            strcat (np, "[1] $n$g");     /* [1] A> */
            strcat (op, "$n$g");         /* A> */
         }
         else {                  /* User already has a prompt */
            
            if (p[0] == '[' && p[2] == ']') { /* Assume 'se' set it */
               strcat (np, p);               
               np[8]++;
            }
            else {                              /* Prepend '[1] ' */
               strcat (np, "[1] ");
               strcat (np, p);
            }
            
            strcat (op, p);
         }
            
         putenv (np);      /* Temporary prompt with [n] */
      }

      forkstatus = spawnl (P_WAIT, getenv ("COMSPEC"), "command", NULL);

      if (op != NULL && np != NULL) {
         putenv (op);   /* Restore original prompt */
         free (op);
         free (np);
      }
   }
   else
      forkstatus = system ((char *)cmdlin);

   /* Did the 'fork' fail ? */
   if (forkstatus == -1) {
      if (errno == ENOMEM || errno == E2BIG)
         Errcode = ECANTFORK;
      else
         Errcode = ENOSHELL;
         
      return (ERR);
   }

   childstatus = forkstatus;

#endif   /* MSDOS */

#if MSWIN32
   forkstatus = childstatus = -1;
#endif

#if TOS
   char pasc[MAXLINE];     /* Pascal-type string */

   /* On the Atari, invoke Mark Williams shell and hope it works */
   sprintf (pasc, "%c%s", (char)(strlen (cmdlin)), cmdlin);
   
   forkstatus = Pexec (0, DEFAULT_PATH, pasc, 0L);

   if (forkstatus == -33 || forkstatus == -39) {  /* Did Pexec fail ? */
      if (forkstatus == -33)
         Errcode = ENOSHELL;     /* File not found */
      else
         Errcode = ECANTFORK;    /* Can't fork (no memory) */

      return (ERR);
   }
   
   childstatus = forkstatus;
   
#endif   /* TOS */

#if ISERVER
   forkstatus = childstatus = -1;
   cmdlin = cmdlin;
#endif

   /* Now look at the return value of the child process */
   if (childstatus != 0) {
      Errcode = ESHELLERR;
      return (ERR);
   }

   return (OK);
}


/* mswait --- message waiting subroutine */

void mswait ()
{
/* Should be some MSDOS code here to work on NetWare... */
#if UNIX | MINIX | LINUX
/*
 * If the user wants to be notified, and the mail file is readable,
 * and there is something in it, then he is given the message.   
 * The 'om' command toggles Notify, controlling notification.
 */
   struct stat buf;
   struct passwd *p;
   static char *mbox = NULL;
   static bool first = YES;
   static unsigned long mtime = 0L;
   static char fname[MAXPATH] = MAILBOX_DIRECTORY;

   if (! Notify)
      return;

   if (first) {
      first = NO;
      mbox = getenv ("MAIL");
      if (mbox == NULL) {
         p = getpwuid (getuid ());

         if (p != NULL)
            strcat (fname, p->pw_name);

         mbox = fname;
      }
      
      if (access (mbox, R_OK) == 0) {
         if (stat (mbox, &buf) >= 0) {
            mtime = buf.st_mtime;

            if (buf.st_size > 0)
               msgstr (SHAVEMAIL, REMARK_MSG);
         }
      }
   }
   else if (stat (mbox, &buf) >= 0 && buf.st_mtime > mtime) {
      mtime = buf.st_mtime;
      if (buf.st_size != 0L) {      /* Empty file means no mail */
         msgstr (SNEWMAIL, REMARK_MSG);
         ringbell (MAIL_BELL);
      }
   }
#endif   /* UNIX | MINIX | LINUX */
}


/* getsefile --- search for 'se's standard files */

bool getsefile (type, path)
int type;
uchar *path;
{
   register int i;
   char names[5][MAXPATH];
   char *svar;
   char *file;
   char *e;
#if TOS | MSDOS | MSWIN32
   char boot;
#endif
   
   /* Start with all names null */
   for (i = 0; i < 5; i++)
      names[i][0] = EOS;
      
   /* Set up environment variable name and file base name */
   switch (type) {
   case SERC_FILE:
      svar = "SE_RC";
#if MSDOS | TOS | ISERVER | MSWIN32
      file = "se.rc";
#endif
#if UNIX | MINIX | LINUX
      file = ".serc";
#endif
#if VMS
      file = "SE_RC";
#endif
      break;
   case MESG_FILE:
      svar = "SE_MSG";
#if MSDOS | TOS | ISERVER | MSWIN32
      file = "se.msg";
#endif
#if UNIX | MINIX | LINUX
      file = "se.msg";
#endif
#if VMS
      file = "SE_MSG";
#endif
      break;
   case HELP_FILE:
      svar = "SE_HLP";
#if MSDOS | TOS | ISERVER | MSWIN32
      file = "se.hlp";
#endif
#if UNIX | MINIX | LINUX
      file = "se.hlp";
#endif
#if VMS
      file = "SE_HLP";
#endif
      break;
   case TEMP_FILE:
      svar = "SE_TMP";
      file = "se.tmp";
      break;
   }

   /* Look for a specific environment variable */
   if ((e = getenv (svar)) != NULL)
      sprintf (names[0], "%s", e);

   /* Look for the file in the current directory */
   sprintf (names[1], "%s", file);
   
   /* Look in the 'se' directory */
   if ((e = getenv ("SE")) != NULL)
      sprintf (names[2], "%s%c%s", e, Dirsep, file);
   
   /* Look in the home directory */
   if ((e = getenv ("HOME")) != NULL)
      sprintf (names[3], "%s%c%s", e, Dirsep, file);
   
   /* Look in the system-wide default place */
#if MSDOS | MSWIN32
   if ((e = getenv ("COMSPEC")) != NULL)  /* Get boot drive letter */
      boot = *e;
   else
      boot = 'C';

   sprintf (names[4], "%c:%c%s", boot, Dirsep, file);
#endif

#if TOS
   if (Drvmap () & 0x0004L)
      boot = 'C';    /* C: present so use it */
   else
      boot = 'A';    /* No C: so assume A: */
      
   sprintf (names[4], "%c:%c%s", boot, Dirsep, file);
#endif

#if UNIX | MINIX | LINUX
   sprintf (names[4], "%s%c%s", LIBDIR, Dirsep, file);
#endif

#if ISERVER
   sprintf (names[4], "%s%c%s", LIBDIR, Dirsep, file); /* Needs fix... */
#endif

#if VMS
   sprintf (names[4], "%s%c%s", LIBDIR, ':', file);
#endif

#ifdef DB
   for (i = 0; i < 5; i++)
      printf ("%d: %s\n", i, names[i]);

   gets (path);
#endif
   
   /* Find that file... */
   for (i = 0; i < 5; i++) {
      if (names[i][0] == EOS)
         continue;
         
      if (file_exists ((uchar *)names[i])) {
         (void)strucpy (path, names[i]);
         return (YES);
      }
   }

   return (NO);
}


/* file_exists --- test for existance of a file */

bool file_exists (file)
const uchar *file;
{
#if MSDOS
#if MSC
   struct find_t buf;

   if (_dos_findfirst ((char *)file, _A_NORMAL, &buf) == 0)
      return (YES);
#endif /* MSC */
#if TCC
   struct ffblk buf;

   if (findfirst ((char *)file, &buf, FA_NORMAL) == 0)
      return (YES);
#endif /* TCC */
#endif

#if MSWIN32
   WIN32_FIND_DATA buf;
   HANDLE h;

   if ((h = FindFirstFile (file, &buf)) != INVALID_HANDLE_VALUE) {
      FindClose (h);
      return (YES);
   }
#endif

#if UNIX | VMS | MINIX | TOS | LINUX
   struct stat buf;
   
   if (stat ((char *)file, &buf) == 0)
      return (YES);
#endif

#if ISERVER
   filedes fd;
   
   if ((fd = open ((char *)file, O_RDONLY)) != -1) {
      close (fd);
      return (YES);
   }
#endif

   return (NO);
}


/* getflen --- return length of a file in bytes */

long int getflen (file)
const uchar *file;
{
#if MSDOS
#if MSC
   struct find_t buf;
   
   if (_dos_findfirst ((char *)file, _A_NORMAL, &buf) != 0)
      return (-1L);
   else
      return (buf.size);
#endif   /* MSC */
#if TCC
   struct ffblk buf;
   
   if (findfirst ((char *)file, &buf, FA_NORMAL) != 0)
      return (-1L);
   else
      return (buf.ff_fsize);
#endif   /* TCC */
#endif   /* MSDOS */

#if MSWIN32
   WIN32_FIND_DATA buf;
   HANDLE h;

   h = FindFirstFile (file, &buf);

   FindClose (h);

   return (buf.nFileSizeLow);
#endif

#if TOS
   DMABUFFER buf; /* GEMDOS directory structure defined in MWC stat.h */
   char *olddta;
   int ret;
   
   olddta = (char *)Fgetdta ();     /* Get Device Transfer Address */
   Fsetdta (&buf);                  /* Set DTA -> buf              */
   ret = Fsfirst ((char *)file, 0); /* Search for file             */
   Fsetdta (olddta);                /* Restore original DTA        */
   
   if (ret == -33)               
      return (-1);               /* File not found */
   else
      return (buf.d_fsize);
#endif   /* TOS */

#if UNIX | MINIX | LINUX | VMS
   struct stat buf;
   
   if (stat ((char *)file, &buf) != 0)
      return (-1L);
   else
      return (buf.st_size);
#endif   /* UNIX | MINIX | LINUX | VMS */

#if ISERVER
   filedes fd;
   long int len;
   
   if ((fd = open ((char *)file, O_RDONLY)) == -1)
      len = -1L;
   else {
      len = filesize (fd);
      close (fd);
   }
   
   return (len);
#endif
}


/* commit_file --- ensure file blocks are actually written to disk */

void commit_file (fp)
FILE *fp;
{
#if MSDOS
   union REGS r;
#endif
   filedes fd;
   
   fd = fileno (fp);
   
#if UNIX
   fsync (fd);
#endif

#if MSDOS
   /* In MS-DOS 3.30 or higher, we can do this */
   if (_osmajor > 3 || (_osmajor == 3 && _osminor > 30)) {
      r.h.ah = COMMIT_FILE;
      r.x.bx = fd;
   
      intdos (&r, &r);
   }
#endif   /* MSDOS */
}


/* sync_disk --- flush file system buffers */

void sync_disk ()
{
#if UNIX | MINIX | LINUX
   /* Sync the file system */
   sync ();
#endif
}


#ifdef LOG_USAGE

/* log_usage --- log se usage */

static void log_usage ()
{
/*
 * This code has little chance of working under MSDOS or TOS
 */
#if MSDOS | TOS
   static char logfile[] = "C:\\se.log";        /* a file */
#endif

#if UNIX | MINIX | LINUX
   static char logfile[] = "/u/bj/se.log";      /* a public file */
#endif

#if VMS
   static char logfile[] = "DISK$POO:[file.stuff]";
#endif

#if ISERVER
   static char logfile[] = "se.log";
#endif

   char tod[26];    /* tod => time of day */
   uchar ver[MAXLINE];
   time_t clock;
   FILE *fp;
#if UNIX | MINIX | LINUX
   int old_umask;
#endif

   time (&clock);
   strcpy (tod, ctime (&clock));    /* See the manual on ctime(3C)  */
   tod[24] = EOS;                   /* Delete the NEWLINE at the end */

#if UNIX | MINIX | LINUX
   old_umask = umask (0);     /* Allow writes for everyone        */
#endif                        /* when first call creates the file */

   if ((fp = fopen (logfile, APPEND)) != NULL) {
      verstr (ver);       /* All ok, write out statistics */
      fprintf (fp, "%s@%s: se %s: %s\n", usrname (), sysname (), ver, tod);
      fclose (fp);
   }
   /* else
      don't do anything */

#if UNIX | MINIX | LINUX
   umask (old_umask);
#endif
}
#endif   /* LOG_USAGE */
