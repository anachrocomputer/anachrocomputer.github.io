/* siterm --- video driver for Sirius 1/Victor 9000         09/09/1989 */
/* Copyright (c) 1989 Bob Green, Froods Software Development           */

#include <dos.h>

/* Display constants */
#define REVERSE         0x8000          /* Reverse video bit    */
#define LOW_INTENSITY   0x4000          /* Normal intensity bit */
#define UNDERLINE       0x2000          /* Underline bit        */
#define HIGH_INTENSITY  0               /* High intensity       */

#define FONT_BASE       100

#define SCADD      0xF0000000l

/* Registers in the CRTC */
#define CURSOR_START    10
#define CURSOR_END      11
#define START_HIGH      12
#define START_LOW       13
#define CURSOR_HIGH     14
#define CURSOR_LOW      15

/* Types of cursor */
#define STEADY_CURSOR   0x00
#define BLINKING_CURSOR 0x60
#define NO_CURSOR       0x40

/* Screen size */
#define NROWS           25
#define NCOLS           80

string Smachine = "Victor/Sirius";

static unsigned int Screen_image[MAXROWS][MAXCOLS];
static unsigned int Blanks[MAXCOLS];   /* Blanks for filling lines  */
static int Cur_size = CUR_NORMAL;  /* Cursor state              */
static int Cur_on = YES;

static int Colours[20] = {
   0,
   LOW_INTENSITY,             /* Text                       */
   LOW_INTENSITY,             /* Bar                        */
   LOW_INTENSITY,             /* Command line               */
   LOW_INTENSITY,             /* Line one                   */
   LOW_INTENSITY,             /* Line $                     */
   LOW_INTENSITY,             /* Status line                */
   LOW_INTENSITY,             /* Messages on status line    */
   LOW_INTENSITY,             /* Line numbers               */
   LOW_INTENSITY,             /* Mark column                */
   LOW_INTENSITY,             /* Current line               */
   LOW_INTENSITY,             /* Help messages              */
   LOW_INTENSITY,             /* Dashes in 'split-screen'   */
   HIGH_INTENSITY,            /* Prompts                    */
   LOW_INTENSITY,             /* Unprintable characters     */
   LOW_INTENSITY,             /* MS-DOS shell               */
   HIGH_INTENSITY,            /* Source-code comments       */
   HIGH_INTENSITY,            /* Source-code reserved words */
   LOW_INTENSITY,             /* Source-code strings        */
   UNDERLINE|LOW_INTENSITY    /* Source-code pre-proc cmds. */
};


/* mdvd_init --- initialise this module */

void mdvd_init ()
{
   register int row, col;
   
   opendisplay ();
   
   /* Initialise array of blanks */
   for (col = 0; col < MAXCOLS; col++)
      Blanks[col] = LOW_INTENSITY | ' ';       /* Set to white blanks */
      
   /* Clear virtual screen array */
   for (row = 0; row < MAXROWS; row++)
      for (col = 0; col < MAXCOLS; col++)
         Screen_image[row][col] = LOW_INTENSITY | ' ';
}


/* setcolr --- set the colour of a screen zone */

void setcolr (zone, fg, bg)
int zone;
int fg, bg;
{
   Colours[zone] = fg;
}


/* shellcolr --- fix colour of screen for DOS shell */

void shellcolr ()
{
}


/* mvinch --- read a character back from the screen image */

int mvinch (r, c)
int r, c;
{
   return (Screen_image[r][c] & 0xff);
}


/* cprow --- copy from one row to another for append */

void cprow (from, to)
register int from, to;
{
   register int col;

   for (col = 0; col < Ncols; col++)
      load (Screen_image[from][col] & 0xff, to, col, TEXT_ZONE);
}


/* load --- load a character onto the screen at given coordinates */

void load (chr, row, col, zone)
register int chr;
register int row, col;
int zone;
{
   register unsigned int ch;

   if (chr < ' ')
      ch = Colours[UPRT_ZONE] | Unprintable;
   else
      ch = Colours[zone] | chr;

   if ((row >= 0) && (row < Nrows) && (col >= 0) && (col < Ncols)
                                   && (Screen_image[row][col] != ch)) {
      Screen_image[row][col] = ch;
      mvaddch (row, col, ch);
   }
/*   mvaddch(row,col,ch); */
}


/* loadstr --- load a string into a field of the screen */

void loadstr (str, row, stcol, endcol, zone)
register const uchar *str;
int row, stcol, endcol;
int zone;
{
   register unsigned int ch;
   register int p, c, limit;

   if ((row >= 0) && (row < Nrows) && (stcol >= 0)) {
      for (p = 0, c = stcol; str[p] != EOS && c < Ncols; p++, c++) {

         if (str[p] < ' ')
            ch = Colours[UPRT_ZONE] | (Unprintable & 0xff);
         else
            ch = Colours[zone] | str[p];
         
         if (Screen_image[row][c] != ch) {
            Screen_image[row][c] = ch;
            mvaddch (row, c, ch);
         }
      }

      ch = Colours[zone] | ' ';
      
      if (endcol >= Ncols - 1 && c < Ncols - 1)
         clear_to_eol (row, c, zone);
      else {
         limit = (endcol < Ncols - 1) ? endcol : Ncols - 1;
         for (; c <= limit; c++)
            if (Screen_image[row][c] != ch) {
               Screen_image[row][c] = ch;
               mvaddch (row, c, ch);
            }
      }
   }
}


/* restore_screen --- screen has been garbaged; fix it */

void restore_screen ()
{
   register int row, col;

   clrscreen ();

   for (row = 0; row < Nrows && ! intrpt (); row++)
      for (col = 0; col < Ncols; col++)
         mvaddch (row, col, Screen_image[row][col]);

   msgstr (SNULL, REMARK_MSG);   /* get rid of 'type control-q....' */
}


/* ringbell --- generate loud beeping noises */

void ringbell (type)
int type;               /* Different noises for different errors */
{
   if (!Quiet)
      putch (BEL);
}


/* clear_to_eol --- clear from current cursor position to end of line */

void clear_to_eol (row, col, zone)
int row, col;
int zone;
{
   register int c;
   register unsigned int space;

   space = Colours[zone] | ' ';
   
   for (c = col; c < Ncols; c++)
      if (Screen_image[row][c] != space)  {
         Screen_image[row][c] = space;
         mvaddch (row, c, space);
      }
}


/* inslines --- insert 'n' lines on the screen at 'row' */

void inslines (row, n)
int row, n;
{
   register int i;
   int screen_end  = (Nrows*Ncols)-1;
   int screen_base = screen_end - (n * Ncols);
   int word_count  = (Nrows - row - n) * Ncols;
   int blank_base  = row * Ncols;

   for (i = Nrows - 1; i - n >= row; i--)
      memcpy (Screen_image[i], Screen_image[i - n], Ncols * sizeof (unsigned));

   for (; i >= row; i--)     
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
      
   screen_down (screen_base << 1, screen_end << 1, word_count);
   screen_blanks (blank_base << 1, n * Ncols);
}


/* dellines --- delete 'n' lines beginning at 'row' */

void dellines (row, n)
int row, n;
{
   register int i;
   int screen_dest = row * Ncols;
   int screen_src  = screen_dest + (n * Ncols);
   int word_count  = (Nrows - row - n) * Ncols;
   int blank_base  = (Nrows - n) * Ncols;

   for (i = row; i + n < Nrows; i++)
      memcpy (Screen_image[i], Screen_image[i + n], Ncols * sizeof (unsigned));

   for (; i < Nrows; i++)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
      
   screen_up (screen_src << 1, screen_dest << 1, word_count);
   screen_blanks (blank_base << 1, n * Ncols);
}


/* show_cursor --- show or hide the text cursor */

void show_cursor (on)
bool on;
{
   unsigned char start_reg = peek_crtc (CURSOR_START);
   
   if (on)
      switch (Cur_size) {
      case CUR_NORMAL:
         start_reg = ((start_reg & 0x1f) | STEADY_CURSOR);
         break;
         
      case CUR_INSERT:
         start_reg = ((start_reg & 0x1f) | BLINKING_CURSOR);
         break;
      }
   else
      start_reg = ((start_reg & 0x1f) | NO_CURSOR); 
      
   poke_crtc (CURSOR_START, start_reg);
}


/* shape_cursor --- change the cursor */

void shape_cursor (size)
int size;
{
   Cur_size = size;
   
   if (Cur_on)
      show_cursor (YES);
}


/* set_term --- initialise terminal parameters and actual capabilities */

int set_term (type, hwinsdel, r, c)
const uchar *type;
bool *hwinsdel;
int *r, *c;
{
   *hwinsdel = YES;
   *r = NROWS;
   *c = NCOLS;
   
   return (OK);
}


/* mapkey --- read keystrokes and map for cursor keys and mouse */

unsigned int mapkey ()
{
   while (YES) {
      if (chkinp ())  /* Now see if there's a key pressed */
         return (t1in ());
   }
}


/* term_init --- send start-up sequence to terminal */

void term_init ()
{
}


/* term_exit --- send close-down sequence to terminal */

void term_exit ()
{
}


/* position_cursor --- move the cursor on the screen */

void position_cursor (row, col)
int row, col;
{
   int offset = (row * Ncols) + col;
   
   poke_crtc (CURSOR_LOW,  offset);
   poke_crtc (CURSOR_HIGH, offset >> 8);
}     
