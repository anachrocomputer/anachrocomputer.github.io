/* atari --- machine-dependant routines for Atari ST        19/12/1987 */
/* Copyright (c) 1987 BJ, Froods Software Development                  */

#include <gemdefs.h>
#include <obdefs.h>
#include <osbind.h>
#include <bios.h>
#include <xbios.h>

#include "keys.h"
#include "gse.h"

/* Screen sizes */
#define LOW_NROWS      20
#define LOW_NCOLS      35
#define MED_NROWS      20
#define MED_NCOLS      70
#define HIGH_NROWS     20
#define HIGH_NCOLS     70

#define HUE(fg, bg)     (fg | (bg << 4))

/*                (NAME | CLOSER | MOVER | FULLER | SIZER | UPARROW | \
                   DNARROW | VSLIDE | LFARROW | RTARROW | HSLIDE | INFO) */
#define WIN_FLAGS (NAME | CLOSER | MOVER | FULLER | SIZER | UPARROW | \
                   DNARROW | VSLIDE)

#define WA_UPPAGE 0
#define WA_DNPAGE 1
#define WA_UPLINE 2
#define WA_DNLINE 3
#define WA_LFPAGE 4
#define WA_RTPAGE 5
#define WA_LFLINE 6
#define WA_RTLINE 7

/* GEM globals */
int contrl[12], intin[128], ptsin[128], intout[128], ptsout[128];

/* Application control globals */
static int Appl;
static int Win;
static int Vdi;
static OBJECT *Menu;
static int Fonth, Fontw;
static int Wposx, Wposy, Wwd, Wht;
static int Wx0, Wy0, Ww0, Wh0;
static int Fposx, Fposy, Fwd, Fht;
static int Full = NO;

typedef unsigned int scancode;


/* Export name of machine */
string Smachine = "Atari ST (GEM)";

#if NO_PROTOTYPES
static void clear_to_eol ();
static void capslite ();
static void gemtext ();
static void gemrect ();
static unsigned int event_loop ();
static unsigned int msg_event ();
static void but_event ();
static void mou_event ();
static void move_win ();
static void flip_rect ();
static void redraw_rect ();
static void send_redraw ();
static void slidersiz ();
static unsigned int do_arrow ();
static void do_menu ();
static void do_aboutbox ();
static void move_thumb ();
#else
static void clear_to_eol (int row, int col, int zone);
static void capslite (void);
static void gemtext (int colr, int r, int c, const char *s);
static void gemrect (int colr, int r1, int c1, int r2, int c2);
static unsigned int event_loop (void);
static unsigned int msg_event (const int msg[]);
static void but_event (int mx, int my, int mb, int mcount);
static void mou_event (int m1);
static void move_win (int wh, int x, int y, int w, int h);
static void flip_rect (int x, int y, int w, int h);
static void redraw_rect (int r1, int c1, int r2, int c2);
static void send_redraw (int r1, int c1, int r2, int c2);
static void slidersiz (int obj);
static unsigned int do_arrow (int dir);
static void do_menu (int title, int item);
static void do_aboutbox (void);
static void move_thumb (int ftop, int fbot, int sctop, int scbot);
#endif   /* NO_PROTOTYPES */

static unsigned int Screen_image[MAXROWS][MAXCOLS];
static int Endcol[MAXROWS];
static int Currow;                     /* Vertical cursor coordinate   */
static int Curcol;                     /* Horizontal cursor coordinate */   
static unsigned int Blanks[MAXCOLS];   /* Blanks for filling in lines  */
static int Cur_size = CUR_NORMAL;      /* Cursor state                 */
static bool Cur_on = YES;
static int Colours[20];    /* Colour settings */

static int Lowdefcols[20] = {
   0,
   HUE(15, 0),    /* Text                       */
   HUE(15, 0),    /* Bar                        */
   HUE(15, 0),    /* Command line               */
   HUE(15, 0),    /* Line one                   */
   HUE(15, 0),    /* Line $                     */
   HUE(5,  0),    /* Status line                */
   HUE(2,  0),    /* Messages on status line    */
   HUE(15, 0),    /* Line numbers               */
   HUE(15, 0),    /* Mark column                */
   HUE(15, 0),    /* Current line               */
   HUE(15, 0),    /* Help messages              */
   HUE(15, 0),    /* Dashes in 'split-screen'   */
   HUE(1,  0),    /* Prompts                    */
   HUE(13, 0),    /* Unprintable characters     */
   HUE(15, 0),    /* Shell calls                */
   HUE(9,  0),    /* Source-code comments       */
   HUE(7,  0),    /* Source-code reserved words */
   HUE(12, 0),    /* Source-code strings        */
   HUE(1,  0)     /* Source-code pre-proc cmds. */
};

static int Meddefcols[20] = {
   0,
   HUE(3, 0),     /* Text                       */
   HUE(3, 0),     /* Bar                        */
   HUE(3, 0),     /* Command line               */
   HUE(3, 0),     /* Line one                   */
   HUE(3, 0),     /* Line $                     */
   HUE(2, 0),     /* Status line                */
   HUE(2, 0),     /* Messages on status line    */
   HUE(3, 0),     /* Line numbers               */
   HUE(3, 0),     /* Mark column                */
   HUE(3, 0),     /* Current line               */
   HUE(3, 0),     /* Help messages              */
   HUE(3, 0),     /* Dashes in 'split-screen'   */
   HUE(1, 0),     /* Prompts                    */
   HUE(3, 0),     /* Unprintable characters     */
   HUE(3, 0),     /* Shell calls                */
   HUE(0, 3),     /* Source-code comments       */
   HUE(2, 0),     /* Source-code reserved words */
   HUE(3, 0),     /* Source-code strings        */
   HUE(1, 0)      /* Source-code pre-proc cmds. */
};

static int Hidefcols[20] = {
   0,
   HUE(1, 0),     /* Text                       */
   HUE(1, 0),     /* Bar                        */
   HUE(1, 0),     /* Command line               */
   HUE(1, 0),     /* Line one                   */
   HUE(1, 0),     /* Line $                     */
   HUE(1, 0),     /* Status line                */
   HUE(1, 0),     /* Messages on status line    */
   HUE(1, 0),     /* Line numbers               */
   HUE(1, 0),     /* Mark column                */
   HUE(1, 0),     /* Current line               */
   HUE(1, 0),     /* Help messages              */
   HUE(1, 0),     /* Dashes in 'split-screen'   */
   HUE(1, 0),     /* Prompts                    */
   HUE(1, 0),     /* Unprintable characters     */
   HUE(1, 0),     /* Shell calls                */
   HUE(0, 1),     /* Source-code comments       */
   HUE(1, 0),     /* Source-code reserved words */
   HUE(1, 0),     /* Source-code strings        */
   HUE(1, 0)      /* Source-code pre-proc cmds. */
};


/* mdvd_init --- initialise this module */

bool mdvd_init ()
{
   register int row, col;
   
   /* Initialise array of blanks */
   for (col = 0; col < MAXCOLS; col++)
      Blanks[col] = (1 << 8) | ' ';
   
   /* Clear virtual screen array */
   for (row = 0; row < MAXROWS; row++) {
      for (col = 0; col < MAXCOLS; col++)
         Screen_image[row][col] = (1 << 8) | ' ';
      
      Endcol[row] = MAXCOLS;
   }

   return (YES);
}


/* set_term --- initialise terminal parameters and actual capabilities */

int set_term (type)
const uchar *type;
{
   int work_in[12], work_out[57];
   int i, junk;
   int x, y, w, h;
   
   /* Sort out video modes */
   switch (Getrez ()) {
   case GR_LOW:
      Fonth = 8;
      Fontw = 8;
      Nrows = LOW_NROWS;
      Ncols = LOW_NCOLS;
      memcpy (Colours, Lowdefcols, sizeof (Colours));
      break;
   case GR_MED:
      Fonth = 8;
      Fontw = 8;
      Nrows = MED_NROWS;
      Ncols = MED_NCOLS;
      memcpy (Colours, Meddefcols, sizeof (Colours));
      break;
   case GR_HIGH:
      Fonth = 16;
      Fontw = 8;
      Nrows = HIGH_NROWS;
      Ncols = HIGH_NCOLS;
      memcpy (Colours, Hidefcols, sizeof (Colours));
      break;
   }            

   /* Start up GEM windows */
   Appl = -1;
   
   if ((Appl = appl_init ()) == -1) {
      puts ("APPL_INIT failed");
      return (ERR);
   }
   
   for (i = 0; i < 10; i++)
      work_in[i] = 1;
   
   work_in[10] = 0;
   
   if (v_opnvwk (work_in, &Vdi, work_out) == 0) {
      puts ("V_OPNVWK failed");
      appl_exit ();
      return (ERR);
   }
   
   graf_mouse (BUSY_BEE, NULL);
  
   if (rsrc_load ("gse.rsc") == 0) {
      form_alert (1, "[1][Cannot find resource file][OK]");
      v_clsvwk (Vdi);
      appl_exit ();
      return (ERR);
   }
  
   /* Find out size of desktop */
   wind_get (0, WF_WORKXYWH, &Fposx, &Fposy, &Fwd, &Fht);

   x = Fposx;
   y = Fposy;
   
   wind_calc (WC_BORDER, WIN_FLAGS, x, y, Ncols * Fontw, Nrows * Fonth,
                                    &junk, &junk, &w, &h);
                                    
   Win = wind_create (WIN_FLAGS, x, y, w, h);
     
   if (Win < 0) {
      puts ("Could not open window");
      return (ERR);
   }
   
   wind_set (Win, WF_NAME, " GSE ", 0, 0);
/* wind_set (Win, WF_INFO, "", 0, 0); */
   wind_open (Win, x, y, w, h);
   wind_calc (WC_WORK, WIN_FLAGS, x, y, w, h, &Wx0, &Wy0, &Ww0, &Wh0);
   
   Wposx = x;
   Wposy = y;
   Wwd   = w;
   Wht   = h;

   if (rsrc_gaddr (R_TREE, MENUBAR, &Menu) == 0) {
      puts ("Lost menu bar");
      return (ERR);
   }
   
   menu_bar (Menu, YES);
   vst_point (Vdi, 15, &junk, &junk, &junk, &junk);

   graf_mouse (ARROW, NULL);
   
   return (OK);
}


/* ttyedit --- set up ST for 'se' */

void ttyedit ()
{
}                
                  

/* ttynormal --- return ST to normal */
                    
void ttynormal ()    
{                     
   /* Restore default colours */
   switch (Getrez ()) {
   case GR_LOW:
      break;
   case GR_MED:
      break;
   case GR_HIGH:
      break;
   }

   v_clsvwk (Vdi);
   
   wind_close (Win);
   wind_delete (Win);
   
   appl_exit ();
}


/* setcolr --- set the colour of a screen zone */

void setcolr (zone, fg, bg)
int zone;
int fg, bg;
{
   Colours[zone] = HUE(fg, bg);
}


/* shellcolr --- fix colour of screen for TOS shell */

void shellcolr ()
{
}


/* mvinch --- read a character back from the screen image */

int mvinch (r, c)
int r, c;
{
   return (Screen_image[r][c] & 0xff);
}


/* cprow --- copy from one row to another for append */

void cprow (from, to)
register int from, to;
{
   register int col;

   for (col = 0; col < Ncols; col++)
      load (Screen_image[from][col] & 0xff, to, col, TEXT_ZONE);
}


/* load --- load a character onto the screen at given coordinates */

void load (chr, row, col, zone)
register unsigned char chr;
register int row, col;
int zone;
{
   register unsigned int ch;

   if (chr < ' ')
      ch = (Colours[UPRT_ZONE] << 8) | Unprintable;
   else
      ch = (Colours[zone] << 8) | chr;

   if (row >= 0 && row < Nrows && col >= 0 && col < Ncols
       && Screen_image[row][col] != ch) {
      Screen_image[row][col] = ch;
      send_redraw (row, col, row, col);
      if (col >= Endcol[row])
         Endcol[row] = col + 1;
   }
}


/* loadstr --- load a string into a field of the screen */

void loadstr (str, row, stcol, endcol, zone)
register unsigned char *str;
int row, stcol, endcol;
int zone;
{
   register unsigned int ch;
   register int p, c, limit;
   int lc, rc;
   
   if (row >= 0 && row < Nrows && stcol >= 0) {
      lc = -1;
      rc = -1;
   
      for (p = 0, c = stcol; str[p] != EOS && c < Ncols; p++, c++) {

         if (str[p] < ' ')
            ch = (Colours[UPRT_ZONE] << 8) | (Unprintable & 0xff);
         else
            ch = (Colours[zone] << 8) | str[p];
         
         if (Screen_image[row][c] != ch) {
            Screen_image[row][c] = ch;
            rc = c;
            if (lc == -1)
               lc = c;
         }
      }

      if (rc != -1)
         send_redraw (row, lc, row, rc);

      ch = (Colours[zone] << 8) | ' ';
      Endcol[row] = MAXCOLS;
      
      if (endcol >= Ncols - 1 && c < Ncols - 1) {
         clear_to_eol (row, c, zone);
         Endcol[row] = c;
      }
      else {
         limit = (endcol < Ncols - 1) ? endcol : Ncols - 1;
         for (; c <= limit; c++)
            if (Screen_image[row][c] != ch) {
               Screen_image[row][c] = ch;
               send_redraw (row, c, row, c);
            }
      }
   }
}


/* tflush --- clear out the terminal output buffer */

void tflush ()
{
   /* Nothing to do -- no buffering */
}


/* restore_screen --- screen has been garbaged; fix it */

void restore_screen ()
{
/* clrscreen (); */

   send_redraw (0, 0, Nrows - 1, Ncols - 1);

   msgstr (SNULL, REMARK_MSG);   /* get rid of 'type control-q....' */
}


/* ringbell --- generate loud beeping noises */

void ringbell (type)
int type;               /* Different noises for different errors */
{
   if (!Quiet)
      Bconout (BC_CON, '\007');
}


/* clear_to_eol --- clear from current cursor position to end of line */

static void clear_to_eol (row, col, zone)
int row, col;
int zone;
{
   register int c;
   register unsigned int space;
   int lc, rc;

   space = (Colours[zone] << 8) | ' ';
   lc = col;
   rc = -1;
   
   for (c = col; c < Ncols; c++)
      if (Screen_image[row][c] != space) {
         Screen_image[row][c] = space;
         rc = c;
      }

   if (rc != -1)
      send_redraw (row, lc, row, rc);
}


/* position_cursor --- move the cursor to (row, col) */

void position_cursor (row, col)
register int row, col;              /* Row and col to move to */
{
   /* Are we already there ? */
   if (row == Currow && col == Curcol)
      return;
      
   Currow = row;
   Curcol = col; 
}


/* show_cursor --- show or hide the text cursor */

void show_cursor (on)
bool on;
{
   Cur_on = on;
}


/* shape_cursor --- set cursor size or style */

void shape_cursor (size)
int size;
{
   Cur_size = size;
}


/* clrscreen --- clear the window to background colour */

void clrscreen ()
{
   int pix[4];

   graf_mouse (M_OFF, NULL);

   /* First set the clipping rectangle */
/* pix[0] = xc;
   pix[1] = yc + hc - 1;
   pix[2] = xc + wc - 1;
   pix[3] = yc;
   vs_clip (Vdi, 1, pix);
*/
   /* Make a white background */
   pix[0] = Wx0;
   pix[1] = Wy0 + Wh0 - 1;
   pix[2] = Wx0 + Ww0 - 1;
   pix[3] = Wy0;
   vsf_color (Vdi, 0);
   v_bar (Vdi, pix);

   graf_mouse (M_ON, NULL);

   Currow = 0;
   Curcol = 0;
}


/* inslines --- insert 'n' lines on the screen at 'row' */

void inslines (row, n)
int row, n;
{
   register int i;

   for (i = Nrows - 1; i - n >= row; i--)
      memcpy (Screen_image[i], Screen_image[i - n], Ncols * sizeof (unsigned));

   for (; i >= row; i--)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));
      
   send_redraw (0, 0, Nrows - 1, Ncols - 1);
}


/* dellines --- delete 'n' lines beginning at 'row' */

void dellines (row, n)
int row, n;
{
   register int i;

   for (i = row; i + n < Nrows; i++)
      memcpy (Screen_image[i], Screen_image[i + n], Ncols * sizeof (unsigned));

   for (; i < Nrows; i++)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (unsigned));

   send_redraw (0, 0, Nrows - 1, Ncols - 1);
}


/* hwinsdel --- return YES if the terminal has hardware insert/delete */

bool hwinsdel ()
{
   if (No_hardware == YES)
      return (NO);
   else
      return (YES);
}


/* term_name --- return the name of the terminal */

uchar *term_name ()
{
   return ("ST");
}


/* readkey --- read keystrokes and map for cursor keys */

int readkey (raw)
bool raw;
{
   static keycode ktab[] = {
/*00*/NOKEY,   NOKEY,   NOKEY,   C_2,     NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*08*/NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*10*/A_Q,     A_W,     A_E,     A_R,     A_T,     A_Y,     A_U,     A_I,
/*18*/A_O,     A_P,     NOKEY,   NOKEY,   NOKEY,   NOKEY,   A_A,     A_S,
/*20*/A_D,     A_F,     A_G,     A_H,     A_J,     A_K,     A_L,     NOKEY,
/*28*/NOKEY,   C_BQT,   NOKEY,   NOKEY,   A_Z,     A_X,     A_C,     A_V,
/*30*/A_B,     A_N,     A_M,     NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*38*/NOKEY,   C_SPACE, NOKEY,   F1,      F2,      F3,      F4,      F5,
/*40*/F6,      F7,      F8,      F9,      F10,     NOKEY,   NOKEY,   CHOME,
/*48*/CUP,     NOKEY,   NOKEY,   CLEFT,   NOKEY,   CRIGHT,  NOKEY,   NOKEY,
/*50*/CDOWN,   NOKEY,   CINSERT, NOKEY,   S_F1,    S_F2,    S_F3,    S_F4,
/*58*/S_F5,    S_F6,    S_F7,    S_F8,    S_F9,    S_F10,   NOKEY,   NOKEY,
/*60*/NOKEY,   CUNDO,   CHELP,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*68*/NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,   NOKEY,
/*70*/NOKEY,   NOKEY,   NOKEY,   C_CLEFT, C_CRIGHT,NOKEY,   NOKEY,   C_CHOME,
/*78*/A_1,     A_2,     A_3,     A_4,     A_5,     A_6,     A_7,     A_8,
/*80*/A_9,     A_0,     A_DASH,  A_EQ,    NOKEY,   NOKEY,   NOKEY,   NOKEY
   };
   scancode scode;
   int ascii;
   
   /* Busy-wait for a keystroke so we can simulate a CAPS-LOCK light */
/* for (;;) {
      capslite ();
      
      if (Bconstat (BC_CON))   * Now see if there's a key pressed * 
         break;
   } */
   
   scode = event_loop ();
   ascii = scode & 0xff;
   
   if (raw)
      return (ascii);
   else if (ascii != 0x00) {
      if (ascii < ' ')
         return (-ascii);
      else if (ascii == DEL)
         return (CDELETE);
      else
         return (ascii);
   }
   else {
      scode >>= 8;
      
      if (scode < (sizeof (ktab) / sizeof (ktab[0])))
         return (ktab[scode]);
      else
         return (NOKEY);   /* Unknown scan code */
   }
}


/* capslite --- display a 'caps lock' indicator */

static void capslite ()
{
   static bool lock = NO;
   bool stat;
   
   stat = (Getshift (-1) & GS_CAPS) != 0;

   if (stat != lock) {
      msgstr (stat ? SCAPS : SNULL, CAPS_MSG);
      lock = stat;
   }
}


/* gemtext --- draw graphics text */

static void gemtext (colr, r, c, s)
int colr;
int r, c;
const char *s;
{
   static int tcolr = -1;
   int x, y;
   
   x = (c * Fontw) + Wx0;
   y = (r * Fonth) + Wy0;

   y += 13;    /* Allow for font origin at bottom of cell */
   
   if (colr != tcolr) {
      tcolr = colr;
      vst_color (Vdi, colr);
   }

   v_gtext (Vdi, x, y, s);
}


/* gemrect --- rectangle fill */

static void gemrect (colr, r1, c1, r2, c2)
int colr;
int r1, c1;
int r2, c2;
{
   int pix[4];
   int x, y, w, h;
   
   x = c1 * Fontw;
   y = r1 * Fonth;
   w = (c2 - c1) * Fontw;
   h = (r2 - r1) * Fonth;

   w += Fontw;
   h += Fonth;

   pix[0] = x + Wx0;
   pix[1] = y + h + Wy0 - 1;
   pix[2] = x + w + Wx0 - 1;
   pix[3] = y + Wy0;
   vsf_color (Vdi, colr);
   v_bar (Vdi, pix);
}


/* event_loop --- application main loop */

static unsigned int event_loop ()
{
   int x1, y1, x2, y2;
   int e;
   int msg[8];
   int mx, my, mb, mcount;
   unsigned int kstate, kcode;
   unsigned int key;
   
   move_thumb (Topln, Lastln, Toprow, Botrow);
   
   for (key = NOKEY; key == NOKEY; ) {
      /* Set up state for this time round... */
/*    if (Curfile[0] == EOS)
         Menu[MSAVE].ob_state |= DISABLED;
      else
         Menu[MSAVE].ob_state &= ~DISABLED;

      if (CurPin == NOPIN)
         Menu[MEDPIN].ob_state |= DISABLED;
      else
         Menu[MEDPIN].ob_state &= ~DISABLED;*/

      x1 = Wposx;
      y1 = Wposy;
      x2 = Wposx + Wwd;
      y2 = Wposy + Wht;
      
      mb = mcount = 0;
      
      /* Draw cursor */
      flip_rect (Curcol * Fontw, Currow * Fonth, Fontw - 1, Fonth - 1);
      
      e = evnt_multi (MU_MESAG | MU_KEYBD | MU_BUTTON,
                      2, 0x01, 0x01,      /* Mouse button         */
                      0, x1, y1, x2, y2,  /* Mouse motion 1       */
                      1, x1, y1, x2, y2,  /* Mouse motion 2       */
                      &msg[0],            /* Message buffer       */
                      0, 0,               /* Timer count H & L    */
                      &mx, &my,           /* Mouse X, Y & button  */
                      &mb,
                      &kstate, &kcode,    /* Keyboard codes       */
                      &mcount);           /* Mouse clicks         */
                      
      /* Erase cursor */
      flip_rect (Curcol * Fontw, Currow * Fonth, Fontw - 1, Fonth - 1);

      wind_update (BEG_UPDATE);
      
      if (e & MU_MESAG)
         key = msg_event (msg);
      
      if (e & MU_KEYBD)
         key = kcode;

      if (e & MU_BUTTON)
         but_event (mx, my, mb, mcount);

      if (e & (MU_M1 | MU_M2))
         mou_event (e & MU_M1);
         
      wind_update (END_UPDATE);
   }

   return (key);
}


/* msg_event --- handle message events */

static unsigned int msg_event (msg)
const int msg[8];
{
   int xc, yc;       /* Clip rectangle  */
   int wc, hc;
   int x1, y1;
   int x2, y2;
   int pix[4];
   unsigned int kcode;
   
#ifdef DB
   printf ("Got a message %d\n", msg[0]);
#endif

   kcode = NOKEY;
   
   switch (msg[0]) {
   case AC_OPEN:
      puts ("AC_OPEN: shouldn't happen");
      break;
      
   case MN_SELECTED:
      do_menu (msg[3], msg[4]);
      break;
   case WM_REDRAW:
      graf_mouse (M_OFF, NULL);

      wind_get (Win, WF_FIRSTXYWH, &xc, &yc, &wc, &hc);

      while (wc != 0 && hc != 0) {
         /* Set the clipping rectangle */
         pix[0] = xc;
         pix[1] = yc + hc - 1;
         pix[2] = xc + wc - 1;
         pix[3] = yc;
#ifdef DB
         printf ("Clip:(%d,%d) %d %d\n", xc, yc, wc, hc);
#endif   /* DB */
/*       pix[0] = Wx0;
         pix[1] = Wy0 + Wh0 - 1;
         pix[2] = Wx0 + Ww0 - 1;
         pix[3] = Wy0; */
         vs_clip (Vdi, 1, pix);

         x1 = msg[4] - Wx0;
         y1 = msg[5] - Wy0;
         x2 = x1 + msg[6] - 1;
         y2 = y1 + msg[7] - 1;
#ifdef DB
printf ("{%d,%d} %d %d={%d,%d}-{%d,%d}\n", msg[4], msg[5], msg[6], msg[7],
         y1 / Fonth, x1 / Fontw, y2 / Fonth, x2 / Fontw);
#endif   /* DB */

         redraw_rect (y1 / Fonth, x1 / Fontw, y2 / Fonth, x2 / Fontw);

         wind_get (Win, WF_NEXTXYWH, &xc, &yc, &wc, &hc);
      }

      graf_mouse (M_ON, NULL);

      break;
   case WM_TOPPED:
   case WM_NEWTOP:
      wind_set (msg[3], WF_TOP, 0, 0, 0, 0);
      break;
   case WM_CLOSED:
/*    do_quit (); */
      break;
   case WM_FULLED:
      if (Full) {
         wind_get (msg[3], WF_PREVXYWH, &xc, &yc, &wc, &hc);
         move_win (msg[3], xc, yc, wc, hc);
         Full = NO;
      }
      else {
         move_win (msg[3], Fposx, Fposy, Fwd, Fht);
         Full = YES;
      }
      
      break;
   case WM_ARROWED:
      kcode = do_arrow (msg[4]);
      break;
   case WM_HSLID:
/* 
      HSlidPos = msg[4];
      wind_set (Win, WF_HSLIDE, HSlidPos, 0, 0, 0);
 */
      break;
   case WM_VSLID:
/*    VSlidPos = msg[4]; */
      break;
   case WM_SIZED:
      Full = NO;
   case WM_MOVED:
      move_win (msg[3], msg[4], msg[5], msg[6], msg[7]);
      break;
   default:
      printf ("in switch: %d\n", msg[0]);
      break;
   }
   
   return (kcode);
}


/* but_event --- handle button events */

static void but_event (mx, my, mb, mcount)
int mx, my;
int mb, mcount;
{
   int rb, lb;
   
#ifdef DB
   printf ("but_event: (%d, %d) mb = %d, mcount = %d\n",
                        mx, my,      mb,          mcount);
#endif   /* DB */

   rb = (mb & 0x02) ? YES : NO;
   lb = (mb & 0x01) ? YES : NO;
   
/* if (lb == NO) { */
      graf_mouse (M_OFF, NULL);

      
      graf_mouse (M_ON, NULL);

      /* Double-click means edit */
      if (mcount == 2) {
      }
/* }
   else {
      puts ("drag...");
   } */
}


/* mou_event --- handle mouse events */

static void mou_event (m1)
int m1;
{
#ifdef DB
   printf ("mou_event: %s\n", m1 ? "M1": "M2");
#endif   /* DB */
}


/* move_win --- move or resize the window */

static void move_win (wh, x, y, w, h)
int wh;
int x, y;
int w, h;
{
   Wposx = x;
   Wposy = y;
   Wwd   = w;
   Wht   = h;

   wind_set (wh, WF_CURRXYWH, x, y, w, h);
   wind_calc (WC_WORK, WIN_FLAGS, x, y, w, h, &Wx0, &Wy0, &Ww0, &Wh0);
}


/* flip_rect --- invert colours inside a rectangle */

static void flip_rect (x, y, w, h)
int x, y;
int w, h;
{
   int xyarray[4];
   
   xyarray[0] = Wx0 + x;
   xyarray[1] = Wy0 + y;
   xyarray[2] = Wx0 + x + w;
   xyarray[3] = Wy0 + y + h;

   vsf_color (Vdi, 1);
   vsl_color (Vdi, 1);
   vsf_interior  (Vdi, 1);
   vsf_perimeter (Vdi, 0);
   vswr_mode (Vdi, 3);
   v_bar (Vdi, xyarray);
   vswr_mode (Vdi, 1);
}


/* redraw_rect --- redraw a rectangle of text */

static void redraw_rect (r1, c1, r2, c2)
int r1, c1;
int r2, c2;
{
   register int r, c;
   register int i;
   int col;
   uchar lin[MAXCOLS];

   if (r2 >= Nrows)
      r2 = Nrows - 1;
      
   if (c2 >= Ncols)
      c2 = Ncols - 1;
      
   for (r = r1; r <= r2; r++) {
      if (c2 >= Endcol[r]) {
         col = Endcol[r] - 1;
         gemrect (0, r, Endcol[r], r, Ncols - 1);
      }
      else
         col = c2;

      for (c = c1, i = 0; c <= col; c++, i++)
         lin[i] = Screen_image[r][c] & 0xff;

      lin[i] = EOS;
      gemtext (1, r, c1, lin);
   }
}


/* send_redraw --- send redraw message to self */

static void send_redraw (r1, c1, r2, c2)
int r1, c1;
int r2, c2;
{
   int msg[8];
   int x, y;
   int w, h;
   
   if (c2 < c1)
      c2 = c1;
      
   x = c1 * Fontw;
   y = r1 * Fonth;
   w = (c2 - c1) * Fontw;
   h = (r2 - r1) * Fonth;
   
   w += Fontw - 1;
   h += Fonth - 1;

#ifdef DB
   printf ("(%d,%d)-(%d,%d)=(%d,%d) %d %d\n", r1, c1, r2, c2, x, y, w, h);
#endif   /* DB */

   msg[0] = WM_REDRAW;
   msg[1] = Appl;
   msg[2] = 0;
   msg[3] = Win;
   msg[4] = Wx0 + x;
   msg[5] = Wy0 + y;
   msg[6] = w;
   msg[7] = h;
   
   appl_write (Appl, sizeof (msg), msg);
}


/* slidersiz --- set size of slider thumb */

static void slidersiz (obj)
int obj;
{
   int siz;
   int vis;
   
   vis = Wh0;
   
   if (vis >= obj)
      siz = 1000;
   else
      siz = ((long)vis * 1000L) / (long)obj;
      
   if (siz < 1)
      siz = 1;
   else if (siz > 1000)
      siz = 1000;

   wind_set (Win, WF_VSLSIZE, siz, 0, 0, 0);
}


/* do_arrow --- handle the arrow messages */

static unsigned int do_arrow (dir)
int dir;
{
   unsigned int kcode;
   
   switch (dir) {
   case WA_UPPAGE:   /* Page Up */
      kcode = NOKEY;
      break;
   case WA_DNPAGE:   /* Page Down */
      kcode = NOKEY;
      break;
   case WA_UPLINE:   /* Row Up */
      kcode = 0x4800;
      break;
   case WA_DNLINE:   /* Row Down */
      kcode = 0x5000;
      break;
   default:
      kcode = NOKEY;
      break;
   }
   
   return (kcode);
}


/* do_menu --- cope with commands sent by the menu bar */

static void do_menu (title, item)
int title;
int item;
{
   switch (title) {
   case MDESK:
      switch (item) {
      case MABOUT:
         do_aboutbox ();
         break;
      }

      break;
   case MFILE:
      switch (item) {
      case MQUIT:
/*       do_quit (); */
         break;
      }

      break;
   default:
      puts ("Bad menu title code!");
      break;
   }
   
   menu_tnormal (Menu, title, YES);
}


/* do_aboutbox --- draw the 'About..' box */

static void do_aboutbox ()
{
   OBJECT *abox;
   int x, y, w, h;
   
   if (rsrc_gaddr (R_TREE, ABOUTBOX, &abox) == 0) {
      puts ("Lost 'about' box");
      return;
   }

   abox[ABOUTOK].ob_state &= ~SELECTED;
   form_center (abox, &x, &y, &w, &h);
   form_dial (FMD_START, 100, 50, 100, 100, x, y, w, h);
   objc_draw (abox, ROOT, MAX_DEPTH, x, y, w, h);
   form_do (abox, 0);
   form_dial (FMD_FINISH, 100, 50, 100, 100, x, y, w, h);
}


/* move_thumb --- move and/or resize the slider bar thumb */

static void move_thumb (ftop, fbot, sctop, scbot)
int ftop, fbot, sctop, scbot;
{
   static int oldpos = -1;
   static int oldsiz = -1;
   int lines;
   int pos, siz;
   
   lines = scbot - sctop + 1;
   
   if (fbot == 0)
      siz = 1000;
   else
      siz = (((long int)lines) * 1000L) / ((long int) fbot);
      
   if (siz < 1)
      siz = 1;
   else if (siz > 1000)
      siz = 1000;
   
   if (siz != oldsiz) {
      wind_set (Win, WF_VSLSIZE, siz, 0, 0, 0);
      oldsiz = siz;
   }
      
   if (fbot == 0)
      pos = 1;
   else
      pos = (((long int)ftop) * 1000L) / ((long int) fbot);
      
   if (pos < 1)
      pos = 1;
   else if (pos > 1000)
      pos = 1000;
   
   if (pos != oldpos) {
      wind_set (Win, WF_VSLIDE, pos, 0, 0, 0);
      oldpos = pos;
   }
}
