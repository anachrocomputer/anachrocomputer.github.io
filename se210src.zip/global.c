/* global --- global command prefix parsing and execution   03/08/1987 */


#include "se.h"
#include "extern.h"

#include "cmds.h"       /* Global prefix letters */

#ifndef OLD_SCRATCH
#ifndef OLD_GLOB
static bool special_casing = NO;
#endif
#endif


/* ckglob --- if global prefix, mark lines to be affected */

int ckglob (lin, i)
uchar lin[];
int *i;
{
   int status;
   register int line, tmp;
   int usepat, usemark;
   register LINEDESC *k;
   uchar txt[MAXLINE];

   status = OK;
   usepat = EOF;
   usemark = EOF;

#ifndef OLD_SCRATCH
#ifndef OLD_GLOB
   if (    /* g/^/m0  or g/$/m0 -- special case the pathological */
      /* cases in order to save time */
      (lin[*i] == 'g' || lin[*i] == 'G')
      && (lin[*i + 1] == lin[*i + 3])
      && (lin[*i + 2] == '^' || lin[*i + 2] == '$')
      && (lin[*i + 4] == 'm' || lin[*i + 4] == 'M')
      && (lin[*i + 5] == '0' && lin[*i + 6] == NEWLINE)   )
   {
      special_casing = YES;
      msgstr (SGLOB, REMARK_MSG);
      return (OK);
   }
#endif
#endif
   if (lin[*i] == GMARK || lin[*i] == XMARK) {  /* Global markname prefix? */
      if (lin[*i] == GMARK)   /* Tag lines with the specified markname */
         usemark = YES;
      else                    /* Tag lines without the specified markname */
         usemark = NO;
            
      (*i)++;
      status = getkn (lin, i, &Savknm, Savknm);
   }

   if (status == OK) {     /* Check for a pattern prefix too */
      if (lin[*i] == GLOBAL || lin[*i] == UCGLOBAL)
         usepat = YES;

      if (lin[*i] == EXCLUDE || lin[*i] == UCEXCLUDE)
         usepat = NO;

      if (usepat != EOF) {
         (*i)++;

         if (optpat (lin, i) == ERR)
            status = ERR;
         else
            (*i)++;
      }
   }

   if (status == OK && usepat == EOF && usemark == EOF)
      status = EOF;
   else if (status == OK)
      defalt (1, Lastln);

   if (status == OK) {     /* No errors so far, safe to proceed */
      msgstr (SGLOB, REMARK_MSG);

      k = Line0;      /* unmark all lines preceeding range */
      for (line = 0; line < Line1; line++) {
         SetGlobMark (k, NO);
         k = NEXTLINE(k);
      }

      for (; line <= Line2; line++) {  /* Mark lines in range */
         if (intrpt ())
            return (ERR);

         tmp = NO;
         if (usemark == EOF ||
             (usemark == YES && GetMarkName (k) == Savknm) ||
             (usemark == NO && GetMarkName (k) != Savknm)) {
            if (usepat == EOF)      /* No global pattern to look for */
               tmp = YES;
            else {            /* There is also a pattern to look for */
               gtxt (k, txt);
               if (match (txt, Pat) == usepat)
                  tmp = YES;
            }
         }

         SetGlobMark (k, tmp);

         k = NEXTLINE(k);
      }

#ifdef OLD_SCRATCH
      /* Mark remaining lines */
      for (; k != Line0; k = k->Nextline)
         SetGlobMark (k, NO);
#else
      /* Mark remaining lines */
      for (; line <= Lastln; line++) {
         SetGlobMark (k, NO);
         k = NEXTLINE (k);
      }
#endif

      msgstr (SNULL, REMARK_MSG);
   }

   return (status);
}


/* doglob --- do command at lin[i] on all marked lines */

int doglob (lin, i, cursav)
uchar lin[];
int *i, *cursav;
{
   int status;
   register int istart, line;
   register LINEDESC *k;

#ifndef OLD_SCRATCH
#ifndef OLD_GLOB
   if (special_casing) {
/*    remark ("Warp 7, Captain!"); */
/*    not on the screen too long anyway */
      reverse (1, Lastln);
      Curln = Lastln;
      special_casing = NO;
      Buffer_changed = YES;
      First_affected = min (1, First_affected);
/*    remark (""); */
      adjust_window (Curln, Curln);
      updscreen ();
      return (OK);
   }
#endif
#endif

   status = OK;
   istart = *i;
   k = Line0;
   line = 0;

   do {
      line++;
      k = NEXTLINE(k);
      if (GetGlobMark (k)) {   /* line is marked */
         SetGlobMark (k, NO);  /* unmark the line */
         Curln = line;
         *cursav = Curln;   /* remember where we are */
         *i = istart;

         if (getlst (lin, i, &status) == OK)
            status = docmd (lin, *i, YES);

         line = 0;          /* lines may have been moved */
         k = Line0;
      }

      if (intrpt ())
         status = ERR;

   } while (line <= Lastln && status == OK);

   return (status);
}
