/* vaxtty --- Vax/VMS terminal driver                                  */

#include <iodef.h>
#include <ssdef.h>
#include <descrip.h>
#include <smgtrmptr.h>
#include <tt2def.h>
#include "keys.h"

/* Screen sizes */
#define NROWS         24
#define NCOLS_NORM    80
#define NCOLS_WIDE    132

/* Display attributes */
#define NORMAL    0
#define INVERSE   1
#define UNDERLINE 2
#define BOLD      4

#define SMG_BUFF_MAX    1024

#define TTY_STR_LEN     4096        /* Area of memory used to store TTY strings */

#define MAXBIND         256
#define MAXSEQ          20

/* system call results */
#define SUCCESS(x)      ((x)&1)
#define FAILURE(x)      (((x)&1)==0)

/* Export name of machine */
string Smachine = "VAX";

#if NO_PROTOTYPES
static void clear_to_eol ();
static void sendch ();
static void sethue ();
static char *smg_getstr ();
static void smg_puts ();
static void smg_putc ();
static void smg_flush ();
static void getdescrip ();
static void addseq ();
static int raw_read ();
static void smg_addkey ();
#else
static void clear_to_eol (int, int, int);
static void sendch (int);
static void sethue (int);
static char *smg_getstr (int);
static void smg_puts (char *);
static void smg_putc (int);
static void smg_flush (void);
static void getdescrip (void);
static void addseq (const uchar *seq, int kcode);
static int raw_read (void);
static void smg_addkey (int, int);
#endif   /* NO_PROTOTYPES */

struct Screen {
   unsigned char  ch;
   unsigned char  hue;
};

struct IOSB {
   short    status;
   short    count;
   long     info;
};

struct TERMINFO {
   char     t_class;
   char     t_type;
   short    t_width;
   long     t_mandl;
   long     t_extend;
};

static struct {
   uchar *seq;
   int   ktok;
} Keytab[MAXBIND];

/* Strings to send to the terminal to drive the display */
static char *beg_rev;
static char *end_rev;
static char *beg_bold;
static char *end_bold;
static char *beg_uline;
static char *end_uline;
static char *era_str;
static char *cls_str;
static char *ins_lin;
static char *del_lin;

/* smg buffer */
static char smg_buff[SMG_BUFF_MAX];
static int smg_buff_ind;

static unsigned int Tty_Chan;
static int Currow;      /* Vertical cursor coordinate                */
static int Curcol;      /* Horizontal cursor coordinate              */

static struct TERMINFO Orig_Tty;
static struct TERMINFO New_Tty;
static int Tty_Type;

static struct Screen Screen_image[MAXROWS][MAXCOLS];
static struct Screen Blanks[MAXCOLS];   /* Blanks for filling in lines */
static int Curhue = NORMAL;
static int Colours[20] = {
   0,
   NORMAL,             /* Text                       */
   NORMAL,             /* Bar                        */
   NORMAL,             /* Command line               */
   NORMAL,             /* Line one                   */
   NORMAL,             /* Line $                     */
   NORMAL,             /* Status line                */
   BOLD,               /* Messages on status line    */
   NORMAL,             /* Line numbers               */
   NORMAL,             /* Mark column                */
   NORMAL,             /* Current line               */
   NORMAL,             /* Help messages              */
   NORMAL,             /* Dashes in 'split-screen'   */
   NORMAL,             /* Prompts                    */
   BOLD,               /* Unprintable characters     */
   NORMAL,             /* MS-DOS shell               */
   INVERSE,            /* Source-code comments       */
   BOLD,               /* Source-code reserved words */
   NORMAL,             /* Source-code strings        */
   UNDERLINE           /* Source-code pre-proc cmds. */
};

/* mdvd_init --- initialise this module */

void mdvd_init ()
{
   int row, col; 
   int i;
   
   /* Initialise array of blanks */
   for (col = 0; col < MAXCOLS; col++) {
      Blanks[col].ch = ' ';
      Blanks[col].hue = NORMAL;
   }
      
   /* Clear virtual screen array */
   for (row = 0; row < MAXROWS; row++)
      for (col = 0; col < MAXCOLS; col++) {
         Screen_image[row][col].ch = ' ';
         Screen_image[row][col].hue = NORMAL;
      }
         
   for (i = 0; i < MAXBIND; i++) {
      Keytab[i].seq = NULL;
      Keytab[i].ktok = NOKEY;
   }
}


/* setup_smg --- do the terminal-specific setup */

static void setup_smg (tty_type)
int *tty_type;
{
   unsigned int   status;
   char           *pos_str;
   uchar          seq[2];
   int            i;
   
   /* Start up SMG */
   status = smg$init_term_table_by_type(&Orig_Tty.t_type, tty_type);
   if (FAILURE(status)) {
      sys$dassgn(Tty_Chan);
      error (NO, "Cannot find entry for terminal type");
   }
   
   /* Get some capability strings */
   beg_rev   = smg_getstr (SMG$K_BEGIN_REVERSE);
   end_rev   = smg_getstr (SMG$K_END_REVERSE);
   beg_uline = smg_getstr (SMG$K_BEGIN_UNDERSCORE);
   end_uline = smg_getstr (SMG$K_END_UNDERSCORE);
   beg_bold  = smg_getstr (SMG$K_BEGIN_BOLD);
   end_bold  = smg_getstr (SMG$K_END_BOLD);
   era_str   = smg_getstr (SMG$K_ERASE_TO_END_LINE);
   cls_str   = smg_getstr (SMG$K_ERASE_WHOLE_DISPLAY);
   pos_str   = smg_getstr (SMG$K_SET_CURSOR_ABS);
   ins_lin   = smg_getstr (SMG$K_INSERT_LINE);
   del_lin   = smg_getstr (SMG$K_DELETE_LINE);
   
   smg_buff_ind = 0;
   
   /* Define some useful key sequences */
   smg_addkey (SMG$K_KEY_F1, F1);
   smg_addkey (SMG$K_KEY_F2, F2);
   smg_addkey (SMG$K_KEY_F3, F3);
   smg_addkey (SMG$K_KEY_F4, F4);
   smg_addkey (SMG$K_KEY_F5, F5);
   smg_addkey (SMG$K_KEY_F6, F6);
   smg_addkey (SMG$K_KEY_F7, F7);
   smg_addkey (SMG$K_KEY_F8, F8);
   smg_addkey (SMG$K_KEY_F9, F9);
   smg_addkey (SMG$K_KEY_F10, F10);
   smg_addkey (SMG$K_KEY_F11, F11);
   smg_addkey (SMG$K_KEY_F12, F12);
   smg_addkey (SMG$K_KEY_F13, F13);
   smg_addkey (SMG$K_KEY_F14, F14);
   smg_addkey (SMG$K_KEY_F15, CHELP);
   smg_addkey (SMG$K_KEY_F16, F16);
   smg_addkey (SMG$K_KEY_F17, F17);
   smg_addkey (SMG$K_KEY_F18, F18);
   smg_addkey (SMG$K_KEY_F19, F19);
   smg_addkey (SMG$K_KEY_F20, F20);
   
   smg_addkey (SMG$K_KEY_PF1, F1);
   smg_addkey (SMG$K_KEY_PF2, F2);
   smg_addkey (SMG$K_KEY_PF3, F3);
   smg_addkey (SMG$K_KEY_PF4, F4);

   smg_addkey (SMG$K_KEY_BACKSPACE, CDELETE);

   smg_addkey (SMG$K_KEY_E2, CINSERT);
   smg_addkey (SMG$K_KEY_E3, ERASE);
   smg_addkey (SMG$K_KEY_E5, PUP);
   smg_addkey (SMG$K_KEY_E6, PDOWN);
   
   /* Good eh BJ ? */
   smg_addkey (SMG$K_KEY_E1, F5);
   smg_addkey (SMG$K_KEY_E4, F15);
   
   smg_addkey (SMG$K_KEY_DOWN_ARROW, CDOWN);
   smg_addkey (SMG$K_KEY_UP_ARROW, CUP);
   smg_addkey (SMG$K_KEY_LEFT_ARROW, CLEFT);
   smg_addkey (SMG$K_KEY_RIGHT_ARROW, CRIGHT);
   
   for (i = 1; i < ' '; i++) {
      seq[0] = i;
      seq[1] = EOS;
      addseq (seq, -i);    /* Relies on values of C_A .. C_Z */
   }

   seq[0] = DEL;
   seq[1] = EOS;
   addseq (seq, CDELETE);
}


/* set_term --- initialise terminal parameters and actual capabilities */

int set_term (type, hwinsdel, pr, pc)
const uchar *type;
bool *hwinsdel;
int  *pr, *pc;
{
   unsigned int   status;
   struct IOSB    io;
   $DESCRIPTOR(tty_name, "TT");
   
   /* Allocate the TTY channel */
   status = sys$assign (&tty_name, &Tty_Chan, NULL, NULL);
   if (FAILURE(status))
      error (NO, "Cannot open channel to terminal");

   /* Remember the original Tty state */
   status = sys$qiow(1, Tty_Chan,  IO$_SENSEMODE, &io, 0, 0,
                        &Orig_Tty, sizeof (Orig_Tty), 0, 0, 0, 0);
                        
   if (FAILURE(status) || FAILURE(io.status)) {
      sys$dassgn(Tty_Chan);
      error (NO, "Unable to obtain Tty characteristics");
   }
      
   /* Say hello to SMG */
   setup_smg (&Tty_Type);
   
   /* Modify the Tty characteristics a bit */
   New_Tty = Orig_Tty;
   New_Tty.t_extend |= TT2$M_PASTHRU;
   
   status = sys$qiow (1, Tty_Chan, IO$_SETMODE, &io, 0, 0,
                           &New_Tty, sizeof (New_Tty), 0, 0, 0, 0);
                           
   if (FAILURE(status) || FAILURE(io.status)) {
      sys$dassgn(Tty_Chan);
      error (NO, "Cannot modify Tty characteristics");
   }
   
   /* Initialise screen size */
   *pr = NROWS;
   *pc = Orig_Tty.t_width;
   *hwinsdel = (del_lin != NULL) && (ins_lin != NULL);
   
   return (OK);
}


void term_init ()
{
}

void term_exit ()
{
}

/* ttyedit --- set up TTY for 'se' */

void ttyedit ()
{
}


/* ttynormal --- return terminal to normal */

void ttynormal ()
{
   unsigned int   status;
   struct IOSB    io;
   
   smg_flush ();
   
   status = sys$qiow (1, Tty_Chan,  IO$_SETMODE, &io, 0, 0, 
                           &Orig_Tty, sizeof (Orig_Tty), 0, 0, 0, 0);
                           
   sys$dassgn (Tty_Chan);
}


/* setcolr --- set the colour of a screen zone */

void setcolr (zone, fg, bg)
int zone;
int fg, bg;
{
}


/* shellcolr --- fix colour of screen for DOS shell */

void shellcolr ()
{
}


/* mvinch --- read a character back from the screen image */

int mvinch (r, c)
int r, c;
{
   return (Screen_image[r][c].ch);
}


/* cprow --- copy from one row to another for append */

void cprow (from, to)
register int from, to;
{
   register int col;

   for (col = 0; col < Ncols; col++)
      load (Screen_image[from][col].ch, to, col, TEXT_ZONE);
}


/* load --- load a character onto the screen at given coordinates */

void load (chr, row, col, zone)
register int chr;
register int row, col;
int zone;
{
   struct Screen ch;

   if (chr < ' ') {
      ch.ch  = Unprintable;
      ch.hue = Colours[UPRT_ZONE];
   }
   else {
      ch.ch  = chr;
      ch.hue = Colours[zone];
   }

   if (row >= 0 && row < Nrows && col >= 0 && col < Ncols &&
          ( Screen_image[row][col].ch != ch.ch || 
            Screen_image[row][col].hue != ch.hue)) {
      Screen_image[row][col] = ch;

      position_cursor (row, col);
      sethue (ch.hue);
      sendch (ch.ch);
   }
}


/* loadstr --- load a string into a field of the screen */

void loadstr (str, row, stcol, endcol, zone)
register const uchar *str;
int row, stcol, endcol;
int zone;
{
   struct Screen ch;
   register int p, c, limit;

   if (row >= 0 && row < Nrows && stcol >= 0) {
      for (p = 0, c = stcol; str[p] != EOS && c < Ncols; p++, c++) {

         if (str[p] < ' ') {
            ch.ch  = Unprintable;
            ch.hue = Colours[UPRT_ZONE];
         }
         else {
            ch.ch  = str[p];
            ch.hue = Colours[zone];
         }
         
         if (Screen_image[row][c].ch != ch.ch || 
                     Screen_image[row][c].hue != ch.hue) {
            Screen_image[row][c] = ch;
            position_cursor (row, c);
            sethue (ch.hue);
            sendch (ch.ch);
         }
      }

      ch.ch  = ' ';
      ch.hue = Colours[zone];
      
      if (endcol >= Ncols - 1 && c < Ncols - 1)
         clear_to_eol (row, c, zone);
      else {
         limit = (endcol < Ncols - 1) ? endcol : Ncols - 1;
         for (; c <= limit; c++)
            if (Screen_image[row][c].ch != ch.ch ||
                        Screen_image[row][c].hue != ch.hue) {
               Screen_image[row][c] = ch;
               position_cursor (row, c);
               sethue (ch.hue);
               sendch (ch.ch);
            }
      }
   }
}


/* tflush --- clear out the terminal output buffer */

void tflush ()
{
   smg_flush();
}


/* restore_screen --- screen has been garbaged; fix it */

void restore_screen ()
{
   register int row, col;

   clrscreen ();

   for (row = 0; row < Nrows && ! intrpt (); row++)
      for (col = 0; col < Ncols; col++) {
         position_cursor (row, col);
         sethue (Screen_image[row][col].hue);
         sendch (Screen_image[row][col].ch);
      }

   msgstr (SNULL, REMARK_MSG);   /* get rid of 'type control-q....' */
}


/* ringbell --- generate loud beeping noises */

void ringbell (type)
int type;               /* Different noises for different errors */
{
   if (!Quiet)
      smg_putc('\007');
}


/* clear_to_eol --- clear from current cursor position to end of line */

static void clear_to_eol (row, col, zone)
int row, col;
int zone;
{
   register int c;
   bool flag;
   struct Screen space;
   char *scr;

   flag = NO;

   space.ch  = ' ';
   space.hue = Colours[zone];
   
   for (c = col; c < Ncols; c++)
      if (Screen_image[row][c].ch != space.ch ||
                  Screen_image[row][c].hue != space.hue) {
         Screen_image[row][c] = space;
         flag = YES;
      }

   if (flag) {
      position_cursor (row, col); 
      smg_puts(era_str);
   }
}


/* position_cursor --- move the cursor to (r, c) */

void position_cursor (r, c)
int r, c;                  /* Row and col to move to */
{
   char           buffer[32];
   int            rlen;
   unsigned int   status;
   static int     cap = SMG$K_SET_CURSOR_ABS;
   static int     len = sizeof (buffer);
   static int     args[3] = {2, 0, 0};
   
   if (!((Currow == r) && (Curcol == c))) {
      Currow = r;
      Curcol = c;
      
      args[1] = r+1;
      args[2] = c+1;
      
      /* Build the sequence */
      status = smg$get_term_data (&Tty_Type, &cap, &len, &rlen, buffer, args);   
      if (SUCCESS(status)) {
         buffer[rlen] = EOS;
         smg_puts(buffer);
      }
      else
         smg_puts("POO");
   }
}


/* clrscreen --- clear the physical screen */

void clrscreen ()
{
   char *scr;

   position_cursor (0, 0);
   smg_puts(cls_str);
}


/* inslines --- insert 'n' lines on the screen at 'row' */

void inslines (row, n)
int row, n;
{
   register int i;
   char *scr;

   position_cursor (row, 0);
   
   for (i=0; i<n; i++)
      smg_puts (ins_lin);

   for (i = Nrows - 1; i - n >= row; i--)
      memcpy (Screen_image[i], Screen_image[i - n], Ncols * sizeof (struct Screen));

   for (; i >= row; i--)     
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (struct Screen));               
}


/* dellines --- delete 'n' lines beginning at 'row' */

void dellines (row, n)
int row, n;
{
   register int i;
   char *scr;

   position_cursor (row, 0);
   
   for (i=0; i<n; i++)
      smg_puts (del_lin);

   for (i = row; i + n < Nrows; i++)
      memcpy (Screen_image[i], Screen_image[i + n], Ncols * sizeof (struct Screen));

   for (; i < Nrows; i++)
      memcpy (Screen_image[i], Blanks, Ncols * sizeof (struct Screen));
}


/* term_name --- return the name of the terminal */

uchar *term_name ()
{
   return ("A terminal");
}


/* shape_cursor --- set cursor size or style */

void shape_cursor (size)
int size;
{
}

/* sethue --- set video attributes on or off */

static void sethue (hue)
int hue;
{
   if (Curhue != hue) {
      /* Set inverse video... */
      if ((Curhue & INVERSE) != (hue & INVERSE)) {
         if (hue & INVERSE)
            smg_puts (beg_rev);
         else
            smg_puts (end_rev);
      }

      /* Set underlining... */
      if ((Curhue & UNDERLINE) != (hue & UNDERLINE)) {
         if (hue & UNDERLINE)
            smg_puts (beg_uline);
         else
            smg_puts (end_uline);
      }
         
      /* Set bold... */
      if ((Curhue & BOLD) != (hue & BOLD)) {
         if (hue & BOLD)
            smg_puts (beg_bold);
         else
            smg_puts (end_bold);
      }
         
      Curhue = hue;
   }
}


/* sendch --- write a character to the screen image */

static void sendch (ch)
int ch;
{
   Curcol++;
   smg_putc (ch);
}     


/* smg_getstr --- obtain an smg capability string */

static char *smg_getstr(cap)
int cap;
{
   char        *result;
   int         rlen, status;
   static char seq[TTY_STR_LEN];
   static char *buffer = seq;
   static int  len = sizeof(seq);
   static int  arg[2] = { 1, 1 };

   /* Get sequence with one parameter */
   status = smg$get_term_data (&Tty_Type, &cap, &len, &rlen, buffer, arg);
   if (FAILURE(status)) {
      /* Try again with zero parameters */
      status = smg$get_term_data (&Tty_Type, &cap, &len, &rlen, buffer);
      if (FAILURE(status))
         return NULL;
   }

   /* Check for empty result */
   if (rlen == 0)
      return NULL;
   
   /* Save current position so we can return it to caller */
   result = buffer;
   buffer[rlen++] = '\0';
   buffer += rlen;

   /* Return capability to user */
   return result;
}


/* smg_puts --- queue a string for output */

static void smg_puts (str)
char *str;
{
   if (str != NULL)
      while (*str)
         smg_putc ((int) *str++);
}


/* smg_putc --- queue a single character for output */

static void smg_putc (ch)
int ch;
{
   if (smg_buff_ind >= SMG_BUFF_MAX)
      smg_flush ();
      
   smg_buff[smg_buff_ind] = ch;
   smg_buff_ind++;
}


/* smg_flush --- flush output to the TTY */

static void smg_flush ()
{
   if (smg_buff_ind > 0) {
      sys$qio(0, Tty_Chan,  IO$_WRITELBLK | IO$M_NOFORMAT, 0, 0, 0,
                     smg_buff, smg_buff_ind, 0, 0, 0, 0);
                     
      smg_buff_ind = 0;
   }
}

/* raw_read --- read one byte from the terminal stream */

static int raw_read ()
{
   char           ch;
   unsigned int   status;
   struct IOSB    io;
   int            rdfn = IO$_READLBLK | IO$M_NOECHO;
   
   /* Get a character */
   status = sys$qiow(1, Tty_Chan, rdfn, &io, 0, 0, &ch, 1, 2, 0, 0, 0);
   if (FAILURE(status) || FAILURE(io.status))
      ch = EOS;         /* Assume Timeout - may be dangerous */
      
   return ch;
}


/* smg_addkey --- obtain a key sequence and add it to the table */

static void smg_addkey (key, code)
int key;
int code;
{
   char  *seq = smg_getstr(key);
   
   if (seq == NULL)
      return;
      
   addseq(seq, code);
}


/* addseq --- add an escape sequence to 'Keytab' */

static void addseq (seq, kcode)
const uchar *seq;
int kcode;
{
   static int freeseq = 0;
   
   if (freeseq < MAXBIND) {
      Keytab[freeseq].seq = (uchar *)malloc (strlen (seq) + 1);
      
      if (Keytab[freeseq].seq != NULL) {
         strucpy (Keytab[freeseq].seq, seq);
         Keytab[freeseq].ktok = kcode;
         freeseq++;
      }
   }
   /* else
         run out of room in the table */
}  

/* readkey --- read a single keystroke */

int readkey (israw)
bool israw;
{
   int key;
   int i, j;
   uchar seq[MAXSEQ];
   
   smg_flush ();

   if (israw) {
      key = raw_read ();
   }
   else {
      i = j = 0;
      seq[i] = raw_read ();
      
      if (seq[i] >= ' ' && seq[i] < DEL) {
         return (seq[i]);
      }
      
      for (;;) {
         for ( ; Keytab[j].seq != NULL; j++)
            if (Keytab[j].seq[i] == seq[i]) {
               if (Keytab[j].seq[++i] == EOS)
                  return (Keytab[j].ktok);
               else
                  break;
            }
               
         if (Keytab[j].seq == NULL)
            return (NOKEY);
#if 0
         seq[++i] = EOS;
         
         /* Look for complete sequence */
         for (j = 0; Keytab[j].seq != NULL; j++)
            if (strucmp (Keytab[j].seq, seq) == 0)
               return (Keytab[j].ktok);

         /* Look for initial substring */
         for (j = 0; Keytab[j].seq != NULL; j++)
            if (struncmp (Keytab[j].seq, seq, i) == 0)
               break;
               
         /* Bomb out if the sequence doesn't match */
         if (Keytab[j].seq == NULL)
            return (NOKEY);

#endif
         seq[i] = raw_read ();
      }
   }
   
   return (key);
}

