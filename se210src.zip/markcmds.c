#ifdef RCS_ID
static char RCSid[] = "$Header: markcmds.c,v 2.0 87/07/30 14:08:00 BJ Exp $";
#endif

/*
 * $Log:   markcmds.c,v $        
 * Revision 2.0  87/07/30  14:08:00  BJ
 * Initial revision after separating code from 'docmd.c'
 *
 */


#include "se.h"
#include "extern.h"


/* uniquely_name --- mark-name line; make sure no other line has same name */

int uniquely_name (kname)
int kname;
{
   register int line;
   register LINEDESC *k;

   defalt (Curln, Curln);

   if (Line1 <= 0) {
      Errcode = EORANGE;
      return (ERR);
   }

   line = 0;
   k = Line0;

   do {
      line++;
      k = NEXTLINE(k);

      if (line == Line2)
         SetMarkName (k, kname);
      else if (GetMarkName (k) == kname)
         SetMarkName (k, DEFAULTNAME);

   } while (line < Lastln);

   return (OK);
}


/* domark --- name lines Line1 through Line2 as kname */

int domark (kname)
int kname;
{
   int line;
   int ret;
   register LINEDESC *k;

   defalt (Curln, Curln);
   
   if (Line1 <= 0) {
      Errcode = EORANGE;
      ret = ERR;
   }
   else {
      k = getind (Line1);

      for (line = Line1; line <= Line2; line++) {
         if (intrpt ())
            return (ERR);

         SetMarkName (k, kname);
         k = NEXTLINE(k);
      }

      ret = OK;
   }

   return (ret);
}


/* knscan --- scan for a line with a given mark name */

int knscan (way, num)
int way;
Lnum *num;
{
   LINEDESC *k;

   *num = Curln;
   k = getind (*num);
   do {
      bump (num, &k, way);

      if (GetMarkName (k) == Savknm)
         return (OK);

   } while (*num != Curln && ! intrpt ());

   if (Errcode == EEGARB)
      Errcode = EKNOTFND;

   return (ERR);
}
