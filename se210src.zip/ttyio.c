/* ttyio --- low-level terminal I/O routines                07/02/1992 */
/* Copyright (c) 1992 BJ, Froods Software Development                  */

#include "se.h"
#include "extern.h"

#if ISERVER
#include <iocntrl.h>    /* Prototypes for 'write' & 'getkey' */
#endif

#define MAXTOBUF        512   /* Terminal output buffer                */

static char Tobuf[MAXTOBUF];  /* Buffer for collecting terminal output */
static char *Tobp = Tobuf;    /* Pointer to next available char in buf */
static int Nchars = 0;        /* Number of characters in buffer        */

#if UNIX | MINIX | LINUX

#ifdef sun
#include <termio.h>

#define GET_TTY_INFO TCGETS
#define SET_TTY_INFO TCSETSF

typedef struct termios ttybuf;   /* Suns use this structure */
#else
#include <sgtty.h>

#define GET_TTY_INFO TIOCGETP
#define SET_TTY_INFO TIOCSETP

typedef struct sgttyb ttybuf;    /* Apollo and HP systems need this */
#endif   /* sun */

static bool Tty_stat_saved = NO;
static ttybuf old_stat;
#endif   /* UNIX | MINIX | LINUX */


/* ttyedit --- set terminal up for 'se' */

void ttyedit ()
{
#if UNIX | MINIX | LINUX
   ttybuf new_stat;
   
   /* Save the old TTY state... */
   if (Tty_stat_saved != YES) {
      ioctl (0, GET_TTY_INFO, &old_stat);
      Tty_stat_saved = YES;
   }

   /* Set up a new state in 'new_stat' */
   ioctl (0, GET_TTY_INFO, &new_stat);
   
#ifdef sun
   new_stat.c_iflag = IGNBRK;    /* Input modes  */
   new_stat.c_oflag = 0;         /* Output modes */
   new_stat.c_lflag = 0;         /* Local modes  */
   new_stat.c_cc[VMIN] = 1;
   new_stat.c_cc[VTIME] = 0;
#else
   new_stat.sg_flags |= RAW;     /* We need the terminal in raw mode */ 
   new_stat.sg_flags &= ~(ECHO|CRMOD);
#endif   /* sun */

   ioctl (0, SET_TTY_INFO, &new_stat);
#endif   /* UNIX | MINIX | LINUX */

#if VMS
#endif   /* VMS */
}


/* ttynormal --- return terminal to normal state */

void ttynormal ()
{
   /* Make sure it's really sent to the terminal */
   tflush ();
   
#if UNIX | MINIX | LINUX
   if (Tty_stat_saved == YES)
      ioctl (0, SET_TTY_INFO, &old_stat);
#endif   /* UNIX | MINIX | LINUX */

#if VMS
#endif   /* VMS */
}


/* tflush --- clear out the terminal output buffer */

void tflush ()
{
   if (Nchars > 0) {
#if UNIX | MINIX | LINUX
      write (1, Tobuf, Nchars);
#endif

#if VMS
#endif   /* VMS */

      Tobp = Tobuf;
      Nchars = 0;
   }
}


/* t1ou --- send a single character to the terminal */

#if NO_PROTOTYPES
int t1ou (ch)
char ch;
#else
int t1ou (char ch)   /* Must be prototyped exactly like this for Solaris */
#endif
{
   if (Nchars >= MAXTOBUF)
      tflush ();

   *Tobp++ = ch;
   Nchars++;
   
   return (ch);   /* Must return the character for Terminfo */
}


/* t1in --- read a single character from the terminal */

int t1in ()
{
   char c;

#if UNIX | MINIX | LINUX
   in_read (YES);

   if (read (0, &c, 1) == -1) {
      sigread ();
      c = DEL;
   }

   in_read (NO);
#endif   /* UNIX | MINIX | LINUX */

#if MSDOS
   c = getch ();
#endif

#if VMS | MSWIN32
   c = 42;
#endif   /* VMS */

#if ISERVER
   c = getkey ();
#endif

   return (c & 0xff);    /* Code returned is ASCII */
}
